# AI Space v0.0.7 Style Delta
Base: v0.0.6. Extract with `tar -xJf AI_Space_v0.0.7_StyleDelta.tar.xz --strip-components=1 -C <project-root>`.
