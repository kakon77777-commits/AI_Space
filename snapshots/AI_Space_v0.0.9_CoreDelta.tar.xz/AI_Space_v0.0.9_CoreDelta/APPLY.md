# AI Space v0.0.9 CoreDelta

Base: v0.0.8.

Apply from the parent directory of the project root:

`tar -xJf AI_Space_v0.0.9_CoreDelta.tar.xz --strip-components=1 -C <project-root>`

All canonical v0.0.9 deltas are required. Develop from the reconstructed project only after verifying checksums.
