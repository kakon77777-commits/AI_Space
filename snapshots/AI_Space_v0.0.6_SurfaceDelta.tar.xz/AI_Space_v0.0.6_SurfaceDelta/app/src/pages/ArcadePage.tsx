import { useState } from 'react'
import type { ExternalResource, GameSession } from '../core/types.ts'

function formatTimestamp(value: string): string {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString()
}

function ReflectionForm({ session, onReflect }: { session: GameSession; onReflect: (session: GameSession, input: { title: string; body: string }) => void }) {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [error, setError] = useState('')

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    try {
      onReflect(session, { title, body })
      setTitle('')
      setBody('')
      setError('')
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not save reflection.')
    }
  }

  return (
    <form className="reflection-form" onSubmit={submit}>
      <input value={title} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setTitle(event.target.value)} placeholder="Reflection title" required />
      <textarea value={body} onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => setBody(event.target.value)} placeholder="What did this session teach us?" rows={4} required />
      {error ? <div className="form-error" role="alert">{error}</div> : null}
      <button className="secondary-button" type="submit">Save to Board</button>
    </form>
  )
}

export function ArcadePage({
  games,
  sessions,
  onOpen,
  onStart,
  onEnd,
  onReflect,
  onGoExplore,
}: {
  games: ExternalResource[]
  sessions: GameSession[]
  onOpen: (resource: ExternalResource) => void
  onStart: (resource: ExternalResource) => void
  onEnd: (session: GameSession) => void
  onReflect: (session: GameSession, input: { title: string; body: string }) => void
  onGoExplore: () => void
}) {
  const resourceById = new Map(games.map((game) => [game.id, game]))
  const activeByResource = new Map(sessions.filter((session) => session.status === 'active').map((session) => [session.resourceId, session]))
  const completed = sessions.filter((session) => session.status === 'completed' && resourceById.has(session.resourceId))

  return (
    <section className="section-block">
      <div className="surface-panel arcade-banner">
        <span className="eyebrow">Experience layer · v0.0.2</span>
        <h2>Play externally. Keep the experience internally.</h2>
        <p>External games still open outside the AI Space trust boundary. AI Space now keeps an explicit local session lifecycle and can distill a completed session into a Board reflection.</p>
      </div>

      <div className="section-heading">
        <div><span className="eyebrow">Game resources</span><h2>Arcade catalog</h2></div>
        <button className="primary-button" type="button" onClick={onGoExplore}>Add game link</button>
      </div>

      {games.length === 0 ? (
        <div className="empty-state large-empty">No game links yet. Add one in Explore and it will appear here automatically.</div>
      ) : (
        <div className="resource-grid">
          {games.map((game) => {
            const active = activeByResource.get(game.id)
            return (
              <article className="resource-card" key={game.id}>
                <div className="resource-type">game</div>
                <h3>{game.title}</h3>
                <p>{game.url}</p>
                <div className="button-row">
                  <button className="secondary-button" type="button" onClick={() => onOpen(game)}>Open external ↗</button>
                  {active ? (
                    <button className="primary-button" type="button" onClick={() => onEnd(active)}>End session</button>
                  ) : (
                    <button className="primary-button" type="button" onClick={() => onStart(game)}>Start session</button>
                  )}
                </div>
                {active ? <div className="session-status">Active since {formatTimestamp(active.startedAt)}</div> : null}
              </article>
            )
          })}
        </div>
      )}

      <div className="section-heading session-heading">
        <div><span className="eyebrow">Experience history</span><h2>Completed sessions</h2></div>
        <span className="muted">{completed.length} completed</span>
      </div>

      {completed.length === 0 ? <div className="empty-state">End a game session to create an experience checkpoint.</div> : (
        <div className="session-list">
          {completed.map((session) => {
            const game = resourceById.get(session.resourceId)!
            return (
              <article className="surface-panel session-card" key={session.id}>
                <div className="event-meta"><span>{game.title}</span><span>{session.endedAt ? formatTimestamp(session.endedAt) : ''}</span></div>
                <strong>{session.id}</strong>
                <p>Started {formatTimestamp(session.startedAt)}.</p>
                {session.contextSessionId ? <div className="event-foot"><code>ctx:{session.contextSessionId.slice(0, 12)}</code></div> : null}
                {session.reflectionPostId ? (
                  <div className="linked-reflection">Reflection linked: <code>{session.reflectionPostId.slice(0, 8)}</code></div>
                ) : (
                  <ReflectionForm session={session} onReflect={onReflect} />
                )}
              </article>
            )
          })}
        </div>
      )}
    </section>
  )
}
