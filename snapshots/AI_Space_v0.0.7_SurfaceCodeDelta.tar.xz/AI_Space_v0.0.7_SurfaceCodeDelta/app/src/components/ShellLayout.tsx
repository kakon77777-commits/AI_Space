import type { Capability, ContextSession, Principal, Projection } from '../core/types.ts'
import { StatusBadge } from './StatusBadge.tsx'

export function ShellLayout({
  capabilities,
  activeCapability,
  onNavigate,
  activePrincipal,
  activeContextSession,
  activeProjection,
  children,
}: {
  capabilities: Capability[]
  activeCapability?: Capability
  onNavigate: (capability: Capability) => void
  activePrincipal: Principal
  activeContextSession?: ContextSession
  activeProjection?: Projection
  children: React.ReactNode
}) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-block">
          <div className="brand-mark">AS</div>
          <div>
            <strong>AI Space</strong>
            <span>Persistent Activity Shell</span>
          </div>
        </div>

        <nav className="main-nav" aria-label="AI Space navigation">
          {capabilities.map((capability) => (
            <button
              className={activeCapability?.id === capability.id ? 'nav-item nav-item-active' : 'nav-item'}
              key={capability.id}
              onClick={() => onNavigate(capability)}
              type="button"
            >
              <span>{capability.label}</span>
              {capability.status === 'placeholder' ? <span className="nav-pulse" title="Placeholder capability" /> : null}
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="principal-card">
            <span className="eyebrow">Active principal</span>
            <strong>{activePrincipal.displayName}</strong>
            <code>{activePrincipal.id}</code>
            {activeProjection ? <span className="projection-context">Projection · {activeProjection.spaceId} · root {activeProjection.rootPrincipalId}</span> : null}
            {activeContextSession ? <span className="principal-context">{activeContextSession.label}</span> : <span className="principal-context muted-context">No active context</span>}
          </div>
        </div>
      </aside>

      <main className="main-column">
        <header className="topbar">
          <div>
            <span className="eyebrow">Single-site runtime</span>
            <h1>{activeCapability?.label ?? 'AI Space'}</h1>
          </div>
          {activeCapability ? <StatusBadge status={activeCapability.status} mode={activeCapability.mode} /> : null}
        </header>
        <div className="page-content">{children}</div>
      </main>
    </div>
  )
}
