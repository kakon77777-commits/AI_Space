# Apply v0.0.8 StyleDelta
Base: AI Space v0.0.7 plus earlier v0.0.8 deltas.
Extract with `tar -xJf AI_Space_v0.0.8_StyleDelta.tar.xz --strip-components=1 -C <project-root>`.
