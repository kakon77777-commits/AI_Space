Extract with --strip-components=1, then from project root:
patch --batch -p0 < patches/core.patch
