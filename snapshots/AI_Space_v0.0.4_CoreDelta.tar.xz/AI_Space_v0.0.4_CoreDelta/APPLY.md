# AI Space v0.0.4 CoreDelta

This is one part of the v0.0.4 runtime delta.
Base: v0.0.3. Target: v0.0.4.
Overlay both v0.0.4 CoreDelta and UIDelta onto a reconstructed v0.0.3 base.
No paths are deleted. The separately delivered FULL ZIP is canonical.
