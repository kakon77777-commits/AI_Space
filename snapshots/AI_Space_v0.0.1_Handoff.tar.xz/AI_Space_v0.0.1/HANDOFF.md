# AI Space v0.0.1 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/ARCHITECTURE.md`
4. `docs/CAPABILITY_MODEL.md`
5. `docs/reference/AI_Space_技術白皮書_MSSP_RDR_Capability與Agent_Projection架構_v0.2.md`
6. `app/src/data/capabilities.ts`
7. `app/src/core/*`
8. `app/src/App.tsx`

## Current architectural state

The project has **one browser shell and no backend**. The Capability Registry is the authoritative local list of available surfaces for v0.0.1. Domain stores depend on a `StorageAdapter`, so localStorage is replaceable later.

## Do not accidentally expand v0.0.1 scope

Not implemented yet:

- real AI Board adapter;
- Agent Projection runtime;
- login/OAuth/OIDC;
- external agent identity;
- browser automation/isolated browser workers;
- server event store;
- native game runtime;
- memory compiler.

## Recommended next snapshot

`v0.0.2` should connect one real existing capability through an adapter, preferably AI Board, **without moving its implementation into the mother repo**. The acceptance test is that the Shell can discover/open it and receive cross-capability events while the child project keeps an independent lifecycle.

## Development policy

GitHub is a control/handoff plane. Make code changes in a local/conversation workspace, produce a new versioned ZIP, verify it, then update the GitHub snapshot index.
