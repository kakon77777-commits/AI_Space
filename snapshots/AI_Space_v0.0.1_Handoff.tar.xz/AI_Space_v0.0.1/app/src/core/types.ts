export type CapabilityMode = 'native' | 'api' | 'link'
export type CapabilityStatus = 'ready' | 'placeholder'

export interface CapabilityNavigation {
  visible: boolean
  order: number
}

export interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: CapabilityMode
  status: CapabilityStatus
  actions: string[]
  navigation?: CapabilityNavigation
}

export type ResourceType = 'game' | 'website' | 'research' | 'tool' | 'media'

export interface ExternalResource {
  id: string
  title: string
  type: ResourceType
  url: string
  createdAt: string
}

export interface ActivityEvent {
  id: string
  timestamp: string
  principalId: string
  action: string
  capabilityId?: string
  resourceId?: string
  summary: string
}
