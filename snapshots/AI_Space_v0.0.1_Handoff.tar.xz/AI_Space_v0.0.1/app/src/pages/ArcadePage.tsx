import type { ExternalResource } from '../core/types.ts'
import { ResourceCard } from '../components/ResourceCard.tsx'

export function ArcadePage({ games, onOpen, onGoExplore }: { games: ExternalResource[]; onOpen: (resource: ExternalResource) => void; onGoExplore: () => void }) {
  return (
    <section className="section-block">
      <div className="surface-panel arcade-banner">
        <span className="eyebrow">Experience layer</span>
        <h2>External games first. Deconstruction later.</h2>
        <p>
          Add a browser game as an external resource, launch it from here, and keep the session entry in shared activity history.
          v0.0.1 does not embed or automate third-party games.
        </p>
      </div>

      <div className="section-heading">
        <div><span className="eyebrow">Game resources</span><h2>Arcade catalog</h2></div>
        <button className="primary-button" type="button" onClick={onGoExplore}>Add game link</button>
      </div>

      {games.length === 0 ? (
        <div className="empty-state large-empty">No game links yet. Add one in Explore and it will appear here automatically.</div>
      ) : (
        <div className="resource-grid">{games.map((game) => <ResourceCard key={game.id} resource={game} onOpen={onOpen} />)}</div>
      )}
    </section>
  )
}
