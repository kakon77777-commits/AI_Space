import type { ActivityEvent, Capability, ExternalResource } from '../core/types.ts'
import { CapabilityCard } from '../components/CapabilityCard.tsx'
import { EventList } from '../components/EventList.tsx'

export function HomePage({
  capabilities,
  events,
  resources,
  onOpenCapability,
}: {
  capabilities: Capability[]
  events: ActivityEvent[]
  resources: ExternalResource[]
  onOpenCapability: (capability: Capability) => void
}) {
  const readyCount = capabilities.filter((capability) => capability.status === 'ready').length

  return (
    <>
      <section className="hero-panel">
        <div>
          <span className="eyebrow">v0.0.1 · snapshot-first</span>
          <h2>One persistent web shell. Capabilities stay modular.</h2>
          <p>
            This first snapshot proves the mother architecture: registry-driven surfaces, external resources,
            and a shared local activity history. No backend and no direct GitHub development are required.
          </p>
        </div>
        <div className="hero-metrics">
          <div><strong>{readyCount}</strong><span>ready capabilities</span></div>
          <div><strong>{resources.length}</strong><span>local resources</span></div>
          <div><strong>{events.length}</strong><span>recorded events</span></div>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <span className="eyebrow">Capability registry</span>
            <h2>Surfaces</h2>
          </div>
          <span className="muted">Navigation comes from the registry, not hard-coded page ownership.</span>
        </div>
        <div className="capability-grid">
          {capabilities.filter((capability) => capability.id !== 'home').map((capability) => (
            <CapabilityCard capability={capability} key={capability.id} onOpen={onOpenCapability} />
          ))}
        </div>
      </section>

      <section className="section-block two-column-section">
        <div>
          <div className="section-heading compact"><div><span className="eyebrow">Recent activity</span><h2>History</h2></div></div>
          <EventList events={events.slice(0, 5)} emptyText="Open a surface or add an external resource to begin the activity history." />
        </div>
        <aside className="principles-card">
          <span className="eyebrow">v0.0.1 boundary</span>
          <h3>Intentionally small</h3>
          <ul>
            <li>No OAuth or external agent federation.</li>
            <li>No browser automation or embedded third-party pages.</li>
            <li>No AI Board API adapter yet.</li>
            <li>No Projection runtime yet.</li>
          </ul>
        </aside>
      </section>
    </>
  )
}
