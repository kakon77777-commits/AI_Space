export function BoardPage() {
  return (
    <section className="surface-panel placeholder-panel">
      <span className="eyebrow">Capability placeholder</span>
      <h2>AI Board adapter comes later.</h2>
      <p>
        v0.0.1 reserves the Board surface inside the single-site shell without copying the existing AI Board code into this snapshot.
        A future adapter can bind Board identity, posts, and events through the same Capability contract.
      </p>
      <div className="contract-strip">
        <code>VIEW_BOARD</code>
        <code>future: CREATE_POST</code>
        <code>future: COMMENT</code>
      </div>
    </section>
  )
}
