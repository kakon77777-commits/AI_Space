# AI Space — Foundation Shell v0.0.1

AI Space is a **single-site persistent web shell** whose capabilities can remain independently managed. This snapshot is intentionally small: it proves the mother architecture before connecting real Board APIs, agent projection, OAuth, browser automation, or a backend database.

## What works in this snapshot

- Registry-driven `Home / Board / Arcade / Explore / History` surfaces.
- External HTTP(S) resource catalog stored in browser `localStorage`.
- Game resources automatically appear in Arcade.
- External link launches are recorded as activity events.
- Capability opens, resource creation, and external launches share one History view.
- AI Board is represented as a placeholder capability rather than copied into this repository.

## Architecture

```text
Single React Shell
    ↓
Capability Registry
    ↓
Route / Action
    ↓
Local Domain Core
    ├─ ResourceStore
    └─ EventStore
    ↓
Browser localStorage
```

The reusable domain core is plain TypeScript. React is only the current UI projection.

## Run locally

Vite currently requires Node.js `20.19+` or `22.12+`; this package declares `^20.19.0 || >=22.12.0`.

```bash
cd app
npm install
npm run dev
```

Then open the local Vite URL (normally `http://localhost:5173`).

## Verify after dependencies are installed

```bash
npm test
npm run typecheck
npm run build
```

## Offline verification already performed in the build environment

Because the build container cannot resolve the npm registry, dependency installation and the actual Vite production build could not be executed there. The snapshot was still verified with:

- TDD RED runs proving missing core modules caused the expected initial failures.
- Node 22 TypeScript strip-mode core tests: **9/9 passing**.
- TypeScript static verification of `src/` using an offline React declaration shim.
- Snapshot checksum and file manifest validation.

See `validation/` for raw evidence. Do not treat the offline shim as a substitute for running `npm run build` on a machine with npm access.

## Snapshot workflow

Development is intentionally **not** performed file-by-file on GitHub.

```text
Download snapshot ZIP
→ develop/test locally or in a conversation workspace
→ create a new immutable ZIP snapshot
→ GitHub stores README + snapshot index + ZIP
```

The ZIP is the canonical handoff artifact for this version.

## References

- `docs/reference/AI_Space_從工具介面到網路原生持久互動空間_公開版_v0.1.md`
- `docs/reference/AI_Space_技術白皮書_MSSP_RDR_Capability與Agent_Projection架構_v0.2.md`
