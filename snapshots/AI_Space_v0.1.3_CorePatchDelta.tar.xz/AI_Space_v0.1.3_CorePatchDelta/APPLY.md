Extract with --strip-components=1, then from project root run: patch --batch -p0 < patches/core.patch
