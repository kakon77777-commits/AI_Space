Overlay with --strip-components=1 into project root.
