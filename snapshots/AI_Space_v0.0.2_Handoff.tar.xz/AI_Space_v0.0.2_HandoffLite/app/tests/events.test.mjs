import test from 'node:test'
import assert from 'node:assert/strict'
import { MemoryStorageAdapter } from '../src/storage/storage.ts'
import { EventStore } from '../src/core/events.ts'

test('EventStore appends events and lists newest first', () => {
  const storage = new MemoryStorageAdapter()
  const store = new EventStore(storage, () => '2026-08-18T10:00:00.000Z', () => 'event-1')
  store.append({ principalId: 'agent:test', action: 'CAPABILITY_OPENED', capabilityId: 'home', summary: 'Opened Home' })

  const second = new EventStore(storage, () => '2026-08-18T10:01:00.000Z', () => 'event-2')
  second.append({ principalId: 'agent:test', action: 'CAPABILITY_OPENED', capabilityId: 'arcade', summary: 'Opened Arcade' })

  assert.deepEqual(second.list().map((event) => event.id), ['event-2', 'event-1'])
})

test('EventStore persists through the storage adapter and can clear', () => {
  const storage = new MemoryStorageAdapter()
  new EventStore(storage, () => '2026-08-18T10:00:00.000Z', () => 'event-1').append({ principalId: 'agent:test', action: 'RESOURCE_ADDED', resourceId: 'resource-1', summary: 'Added resource' })
  const reloaded = new EventStore(storage)
  assert.equal(reloaded.list().length, 1)
  reloaded.clear()
  assert.equal(reloaded.list().length, 0)
})
