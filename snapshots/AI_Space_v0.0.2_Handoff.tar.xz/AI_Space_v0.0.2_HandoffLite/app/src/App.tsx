import { useEffect, useMemo, useState } from 'react'
import { capabilities } from './data/capabilities.ts'
import { getNavigationCapabilities, resolveCapability } from './core/registry.ts'
import { getPageModel } from './core/shell.ts'
import { EventStore } from './core/events.ts'
import { ResourceStore, selectGameResources } from './core/resources.ts'
import { PostStore } from './core/posts.ts'
import { SessionStore } from './core/sessions.ts'
import type { ActivityEvent, BoardPost, Capability, ExternalResource, GameSession, ResourceType } from './core/types.ts'
import { BrowserStorageAdapter } from './storage/storage.ts'
import { ShellLayout } from './components/ShellLayout.tsx'
import { HomePage } from './pages/HomePage.tsx'
import { BoardPage } from './pages/BoardPage.tsx'
import { ArcadePage } from './pages/ArcadePage.tsx'
import { ExplorePage } from './pages/ExplorePage.tsx'
import { HistoryPage } from './pages/HistoryPage.tsx'
import { NotFoundPage } from './pages/NotFoundPage.tsx'

const PRINCIPAL_ID = 'agent:local-demo'

function currentRoute(): string {
  const hash = window.location.hash.replace(/^#/, '')
  return hash || '/'
}

function externalOpen(resource: ExternalResource): void {
  const opened = window.open(resource.url, '_blank', 'noopener,noreferrer')
  if (opened) opened.opener = null
}

export function App() {
  const storage = useMemo(() => new BrowserStorageAdapter(window.localStorage), [])
  const eventStore = useMemo(() => new EventStore(storage), [storage])
  const resourceStore = useMemo(() => new ResourceStore(storage), [storage])
  const postStore = useMemo(() => new PostStore(storage), [storage])
  const sessionStore = useMemo(() => new SessionStore(storage), [storage])
  const navigation = useMemo(() => getNavigationCapabilities(capabilities), [])

  const [route, setRoute] = useState(currentRoute)
  const [events, setEvents] = useState<ActivityEvent[]>(() => eventStore.list())
  const [resources, setResources] = useState<ExternalResource[]>(() => resourceStore.list())
  const [posts, setPosts] = useState<BoardPost[]>(() => postStore.list())
  const [sessions, setSessions] = useState<GameSession[]>(() => sessionStore.list())

  useEffect(() => {
    const onHashChange = () => setRoute(currentRoute())
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  const page = getPageModel(capabilities, route)
  const activeCapability = page.kind === 'capability' ? capabilities.find((capability) => capability.id === page.capabilityId) : undefined

  function refreshEvents() { setEvents(eventStore.list()) }
  function refreshResources() { setResources(resourceStore.list()) }
  function refreshPosts() { setPosts(postStore.list()) }
  function refreshSessions() { setSessions(sessionStore.list()) }

  function navigate(capability: Capability) {
    eventStore.append({ principalId: PRINCIPAL_ID, action: 'CAPABILITY_OPENED', capabilityId: capability.id, summary: `Opened ${capability.label}` })
    refreshEvents()
    window.location.hash = capability.route === '/' ? '#/' : `#${capability.route}`
  }

  function addResource(input: { title: string; type: ResourceType; url: string }) {
    const resource = resourceStore.add(input)
    eventStore.append({ principalId: PRINCIPAL_ID, action: 'RESOURCE_ADDED', capabilityId: 'explore', resourceId: resource.id, summary: `Added ${resource.type}: ${resource.title}` })
    refreshResources()
    refreshEvents()
  }

  function openResource(resource: ExternalResource) {
    eventStore.append({ principalId: PRINCIPAL_ID, action: resource.type === 'game' ? 'GAME_LINK_OPENED' : 'EXTERNAL_OPENED', capabilityId: resource.type === 'game' ? 'arcade' : 'explore', resourceId: resource.id, summary: `Opened external ${resource.type}: ${resource.title}` })
    refreshEvents()
    externalOpen(resource)
  }

  function createBoardPost(input: { title: string; body: string }) {
    const post = postStore.create({ principalId: PRINCIPAL_ID, ...input })
    eventStore.append({ principalId: PRINCIPAL_ID, action: 'BOARD_POST_CREATED', capabilityId: 'board', summary: `Created Board post: ${post.title}` })
    refreshPosts()
    refreshEvents()
  }

  function startGameSession(resource: ExternalResource) {
    const session = sessionStore.start({ principalId: PRINCIPAL_ID, resourceId: resource.id })
    eventStore.append({ principalId: PRINCIPAL_ID, action: 'GAME_SESSION_STARTED', capabilityId: 'arcade', resourceId: resource.id, sessionId: session.id, summary: `Started game session: ${resource.title}` })
    refreshSessions()
    refreshEvents()
  }

  function endGameSession(session: GameSession) {
    const completed = sessionStore.complete(session.id)
    const resource = resources.find((item) => item.id === completed.resourceId)
    eventStore.append({ principalId: PRINCIPAL_ID, action: 'GAME_SESSION_ENDED', capabilityId: 'arcade', resourceId: completed.resourceId, sessionId: completed.id, summary: `Ended game session: ${resource?.title ?? completed.resourceId}` })
    refreshSessions()
    refreshEvents()
  }

  function createGameReflection(session: GameSession, input: { title: string; body: string }) {
    const post = postStore.create({ principalId: PRINCIPAL_ID, ...input, sourceSessionId: session.id, sourceResourceId: session.resourceId })
    sessionStore.linkReflection(session.id, post.id)
    const resource = resources.find((item) => item.id === session.resourceId)
    eventStore.append({ principalId: PRINCIPAL_ID, action: 'GAME_REFLECTION_CREATED', capabilityId: 'arcade', resourceId: session.resourceId, sessionId: session.id, summary: `Saved game reflection: ${resource?.title ?? session.resourceId}` })
    refreshPosts()
    refreshSessions()
    refreshEvents()
  }

  function clearEvents() {
    eventStore.clear()
    refreshEvents()
  }

  let content: React.ReactNode
  if (page.kind === 'not-found') {
    content = <NotFoundPage onHome={() => navigate(capabilities[0])} />
  } else {
    switch (page.capabilityId) {
      case 'home':
        content = <HomePage capabilities={capabilities} events={events} resources={resources} posts={posts} sessions={sessions} onOpenCapability={navigate} />
        break
      case 'board':
        content = <BoardPage posts={posts} onCreate={createBoardPost} />
        break
      case 'arcade':
        content = <ArcadePage games={selectGameResources(resources)} sessions={sessions} onOpen={openResource} onStart={startGameSession} onEnd={endGameSession} onReflect={createGameReflection} onGoExplore={() => navigate(resolveCapability(capabilities, '/explore')!)} />
        break
      case 'explore':
        content = <ExplorePage resources={resources} onAdd={addResource} onOpen={openResource} />
        break
      case 'history':
        content = <HistoryPage events={events} onClear={clearEvents} />
        break
      default:
        content = <NotFoundPage onHome={() => navigate(capabilities[0])} />
    }
  }

  return (
    <ShellLayout capabilities={navigation} activeCapability={activeCapability} onNavigate={navigate}>
      {content}
    </ShellLayout>
  )
}
