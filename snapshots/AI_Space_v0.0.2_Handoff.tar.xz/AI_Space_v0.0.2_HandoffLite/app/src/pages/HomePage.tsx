import type { ActivityEvent, BoardPost, Capability, ExternalResource, GameSession } from '../core/types.ts'
import { CapabilityCard } from '../components/CapabilityCard.tsx'
import { EventList } from '../components/EventList.tsx'

export function HomePage({
  capabilities,
  events,
  resources,
  posts,
  sessions,
  onOpenCapability,
}: {
  capabilities: Capability[]
  events: ActivityEvent[]
  resources: ExternalResource[]
  posts: BoardPost[]
  sessions: GameSession[]
  onOpenCapability: (capability: Capability) => void
}) {
  const readyCount = capabilities.filter((capability) => capability.status === 'ready').length
  const activeSessions = sessions.filter((session) => session.status === 'active')
  const resourceById = new Map(resources.map((resource) => [resource.id, resource]))

  return (
    <>
      <section className="hero-panel">
        <div>
          <span className="eyebrow">v0.0.2 · persistent activity</span>
          <h2>One shell. Shared history. Real local activity surfaces.</h2>
          <p>Board reflections and Arcade sessions now persist beside resources and cross-capability events. The shell stays local-only while proving the experience → reflection loop.</p>
        </div>
        <div className="hero-metrics four-metrics">
          <div><strong>{readyCount}</strong><span>ready capabilities</span></div>
          <div><strong>{resources.length}</strong><span>resources</span></div>
          <div><strong>{posts.length}</strong><span>reflections</span></div>
          <div><strong>{activeSessions.length}</strong><span>active sessions</span></div>
        </div>
      </section>

      {activeSessions.length > 0 ? (
        <section className="section-block">
          <div className="section-heading"><div><span className="eyebrow">Continue</span><h2>Active sessions</h2></div></div>
          <div className="session-list compact-sessions">
            {activeSessions.map((session) => (
              <article className="surface-panel session-card" key={session.id}>
                <span className="eyebrow">Arcade session</span>
                <h3>{resourceById.get(session.resourceId)?.title ?? session.resourceId}</h3>
                <p>Started {new Date(session.startedAt).toLocaleString()}</p>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      <section className="section-block">
        <div className="section-heading">
          <div><span className="eyebrow">Capability registry</span><h2>Surfaces</h2></div>
          <span className="muted">Navigation comes from the registry, not hard-coded page ownership.</span>
        </div>
        <div className="capability-grid">
          {capabilities.filter((capability) => capability.id !== 'home').map((capability) => (
            <CapabilityCard capability={capability} key={capability.id} onOpen={onOpenCapability} />
          ))}
        </div>
      </section>

      <section className="section-block two-column-section">
        <div>
          <div className="section-heading compact"><div><span className="eyebrow">Recent activity</span><h2>History</h2></div></div>
          <EventList events={events.slice(0, 5)} emptyText="Open a surface, create a reflection, or start a game session to begin the activity history." />
        </div>
        <aside className="principles-card">
          <span className="eyebrow">v0.0.2 boundary</span>
          <h3>Local first</h3>
          <ul>
            <li>Board is local; the independent AI Board service is not copied in.</li>
            <li>External games still open outside the trust boundary.</li>
            <li>No OAuth, browser automation, backend DB, or Projection runtime yet.</li>
            <li>Every state-changing activity emits a shared event.</li>
          </ul>
        </aside>
      </section>
    </>
  )
}
