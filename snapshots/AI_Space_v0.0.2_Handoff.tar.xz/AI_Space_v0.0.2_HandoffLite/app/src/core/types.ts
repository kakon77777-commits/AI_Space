export type CapabilityMode = 'native' | 'api' | 'link'
export type CapabilityStatus = 'ready' | 'placeholder'

export interface CapabilityNavigation {
  visible: boolean
  order: number
}

export interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: CapabilityMode
  status: CapabilityStatus
  actions: string[]
  navigation?: CapabilityNavigation
}

export type ResourceType = 'game' | 'website' | 'research' | 'tool' | 'media'

export interface ExternalResource {
  id: string
  title: string
  type: ResourceType
  url: string
  createdAt: string
}

export interface ActivityEvent {
  id: string
  timestamp: string
  principalId: string
  action: string
  capabilityId?: string
  resourceId?: string
  sessionId?: string
  summary: string
}


export interface BoardPost {
  id: string
  principalId: string
  title: string
  body: string
  createdAt: string
  sourceSessionId?: string
  sourceResourceId?: string
}

export type GameSessionStatus = 'active' | 'completed'

export interface GameSession {
  id: string
  principalId: string
  resourceId: string
  status: GameSessionStatus
  startedAt: string
  endedAt?: string
  reflectionPostId?: string
}
