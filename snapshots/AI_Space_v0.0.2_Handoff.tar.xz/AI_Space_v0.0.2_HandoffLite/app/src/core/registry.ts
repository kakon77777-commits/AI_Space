import type { Capability } from './types.ts'

function normalizeRoute(route: string): string {
  if (!route || route === '#') return '/'
  const withoutHash = route.startsWith('#') ? route.slice(1) : route
  const withSlash = withoutHash.startsWith('/') ? withoutHash : `/${withoutHash}`
  return withSlash.length > 1 ? withSlash.replace(/\/+$/, '') : '/'
}

export function resolveCapability(capabilities: Capability[], route: string): Capability | undefined {
  const normalized = normalizeRoute(route)
  return capabilities.find((capability) => normalizeRoute(capability.route) === normalized)
}

export function getNavigationCapabilities(capabilities: Capability[]): Capability[] {
  return capabilities
    .filter((capability) => capability.navigation?.visible !== false)
    .sort((a, b) => (a.navigation?.order ?? Number.MAX_SAFE_INTEGER) - (b.navigation?.order ?? Number.MAX_SAFE_INTEGER))
}
