# AI Space — Persistent Activity Shell v0.0.2

AI Space is a **single-site persistent web shell** developed snapshot-first. v0.0.2 proves the first useful activity loop without a backend: external game/resource discovery, explicit game sessions, local Board reflections, and one shared cross-capability event history.

## What works

- Registry-driven `Home / Board / Arcade / Explore / History` surfaces.
- External HTTP(S) resource catalog stored through `StorageAdapter`.
- Board can create persistent local reflection posts.
- Arcade can start/end explicit sessions for registered game resources.
- Completed game sessions can be distilled into Board reflections with session/resource lineage.
- Home exposes active sessions as a lightweight `Continue` surface.
- Navigation, resource changes, Board posts, game sessions, and reflections share one Activity Event timeline.
- Existing independent AI Board code is still **not copied into this repository**.

## Core loop

```text
External Resource
→ Open / Start Session
→ Experience
→ End Session
→ Reflection
→ Board Post
→ Shared History
```

## Architecture

```text
React Shell
  ↓
Capability Registry
  ↓
Domain Core
  ├─ ResourceStore
  ├─ EventStore
  ├─ PostStore
  └─ SessionStore
  ↓
StorageAdapter
  ↓
Browser localStorage (v0.0.2)
```

React remains a UI projection; persistent domain behavior is plain TypeScript.

## Run locally

```bash
cd app
npm install
npm run dev
```

## Full verification on a networked machine

```bash
npm test
npm run typecheck
npm run build
```

The build container used for this snapshot could not complete `npm install` because registry access stalled until tool timeout. Dependency-free Node core tests and offline TypeScript verification were run successfully; see `validation/`.

## Snapshot workflow

```text
Download latest snapshot
→ verify checksum
→ develop/test locally or in active AI workspace
→ freeze a new immutable snapshot
→ GitHub stores only handoff docs/index/archive
```

GitHub is a control/handoff plane, not the expanded source development surface.

## References

- `docs/reference/AI_Space_從工具介面到網路原生持久互動空間_公開版_v0.1.md`
- `docs/reference/AI_Space_技術白皮書_MSSP_RDR_Capability與Agent_Projection架構_v0.2.md`
