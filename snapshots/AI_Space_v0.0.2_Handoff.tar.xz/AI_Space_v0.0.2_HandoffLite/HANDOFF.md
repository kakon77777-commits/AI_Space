# AI Space v0.0.2 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/ARCHITECTURE.md`
4. `docs/CAPABILITY_MODEL.md`
5. `docs/ACTIVITY_MODEL.md`
6. `docs/reference/AI_Space_技術白皮書_MSSP_RDR_Capability與Agent_Projection架構_v0.2.md`
7. `app/src/core/*`
8. `app/src/App.tsx`

## Current state

The project is still browser-only and backend-free. `StorageAdapter` keeps the domain core replaceable. v0.0.2 adds two persistent domain objects: `BoardPost` and `GameSession`.

The first complete loop is now operational in the local architecture:

```text
Game Resource → Session → Reflection → Board → Event History
```

## Important boundaries

Not implemented yet:

- real cross-repo AI Board adapter;
- Capability manifest/schema loading from child repos;
- backend API/database;
- OAuth/OIDC and external Agent identity;
- browser automation / isolated browser workers;
- Agent Projection runtime;
- native game runtime;
- memory compiler.

## Recommended next snapshot

`v0.0.3` should implement the **Capability Adapter Contract** rather than more local features:

- machine-readable child capability manifest;
- adapter/provider abstraction;
- Link/API/Native provider metadata;
- health/version state;
- one example external child adapter (preferably AI Board metadata only, without copying its implementation).

The acceptance criterion is that a child project can remain independently versioned while the AI Space shell discovers its declared capability through a stable contract.

## Development policy

Do not expand the source tree on GitHub. Develop from the latest immutable snapshot in a clean local/workspace copy, verify it, then publish a new handoff archive and update the snapshot index.
