# AI Space v0.0.6 CoreDelta

Base: AI Space v0.0.5 FULL app tree.

Overlay this archive at the AI Space project root, preserving the `app/` paths. All v0.0.6 CoreDelta, AppDelta, and SurfaceDelta archives are required to reconstruct the runnable v0.0.6 app.
