# Apply v0.0.8 CoreDelta
Base: AI Space v0.0.7.
Extract with `tar -xJf AI_Space_v0.0.8_CoreDelta.tar.xz --strip-components=1 -C <project-root>`.
