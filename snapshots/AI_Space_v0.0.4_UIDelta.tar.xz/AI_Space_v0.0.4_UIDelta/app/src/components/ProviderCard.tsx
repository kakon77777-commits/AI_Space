import type { CapabilityProvider } from '../core/types.ts'

export function ProviderCard({ provider }: { provider: CapabilityProvider }) {
  const { manifest, health } = provider
  return (
    <article className="provider-card">
      <div className="provider-card-topline">
        <div>
          <span className="capability-kicker">{manifest.id}</span>
          <h3>{manifest.name}</h3>
        </div>
        <div className="provider-badges">
          <span className={`provider-badge provider-health-${health}`}>{health}</span>
          <span className="provider-badge">{manifest.mode}</span>
        </div>
      </div>
      <p>{manifest.description}</p>
      <dl className="provider-meta">
        <div><dt>Version</dt><dd>{manifest.version}</dd></div>
        <div><dt>Lifecycle</dt><dd>{manifest.lifecycle}</dd></div>
        <div><dt>Source</dt><dd><code>{manifest.source.repository}</code></dd></div>
        <div><dt>Actions</dt><dd>{manifest.actions.length}</dd></div>
      </dl>
      {manifest.mode === 'api' && !manifest.runtime?.baseUrl ? (
        <p className="provider-note">Declared contract only · runtime endpoint intentionally not configured.</p>
      ) : manifest.mode === 'api' && manifest.runtime?.baseUrl ? (
        <p className="provider-note">Runtime: <code>{manifest.runtime.baseUrl}</code></p>
      ) : null}
    </article>
  )
}
