import type { ActivityEvent, BoardPost, Capability, CapabilityProvider, ExternalResource, GameSession } from '../core/types.ts'
import { CapabilityCard } from '../components/CapabilityCard.tsx'
import { EventList } from '../components/EventList.tsx'
import { ProviderCard } from '../components/ProviderCard.tsx'

export function HomePage({
  capabilities,
  events,
  resources,
  posts,
  sessions,
  providers,
  providerLoadError,
  onOpenCapability,
}: {
  capabilities: Capability[]
  events: ActivityEvent[]
  resources: ExternalResource[]
  posts: BoardPost[]
  sessions: GameSession[]
  providers: CapabilityProvider[]
  providerLoadError: string | null
  onOpenCapability: (capability: Capability) => void
}) {
  const readyCount = capabilities.filter((capability) => capability.status === 'ready').length
  const activeSessions = sessions.filter((session) => session.status === 'active')
  const resourceById = new Map(resources.map((resource) => [resource.id, resource]))

  return (
    <>
      <section className="hero-panel">
        <div>
          <span className="eyebrow">v0.0.4 · first live child capability</span>
          <h2>One shell. Shared history. The first independent child is now callable.</h2>
          <p>AI Space now binds real HTTP actions from a child manifest. The independent AI Board remains in its own repository and deployment while the mother shell can probe it, read its public ledger, and post through the shared capability contract.</p>
        </div>
        <div className="hero-metrics five-metrics">
          <div><strong>{readyCount}</strong><span>ready capabilities</span></div>
          <div><strong>{resources.length}</strong><span>resources</span></div>
          <div><strong>{posts.length}</strong><span>reflections</span></div>
          <div><strong>{activeSessions.length}</strong><span>active sessions</span></div>
          <div><strong>{providers.length}</strong><span>child providers</span></div>
        </div>
      </section>

      {activeSessions.length > 0 ? (
        <section className="section-block">
          <div className="section-heading"><div><span className="eyebrow">Continue</span><h2>Active sessions</h2></div></div>
          <div className="session-list compact-sessions">
            {activeSessions.map((session) => (
              <article className="surface-panel session-card" key={session.id}>
                <span className="eyebrow">Arcade session</span>
                <h3>{resourceById.get(session.resourceId)?.title ?? session.resourceId}</h3>
                <p>Started {new Date(session.startedAt).toLocaleString()}</p>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      <section className="section-block">
        <div className="section-heading">
          <div><span className="eyebrow">Child capability discovery</span><h2>Independent providers</h2></div>
          <span className="muted">Machine-readable manifests are validated before they enter the shell.</span>
        </div>
        {providerLoadError ? <div className="empty-state">Manifest load failed: {providerLoadError}</div> : null}
        {providers.length > 0 ? (
          <div className="provider-grid">
            {providers.map((provider) => <ProviderCard provider={provider} key={provider.manifest.id} />)}
          </div>
        ) : providerLoadError ? null : <div className="empty-state">Discovering child capability manifests…</div>}
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div><span className="eyebrow">Capability registry</span><h2>Surfaces</h2></div>
          <span className="muted">Navigation comes from the registry, not hard-coded page ownership.</span>
        </div>
        <div className="capability-grid">
          {capabilities.filter((capability) => capability.id !== 'home').map((capability) => (
            <CapabilityCard capability={capability} key={capability.id} onOpen={onOpenCapability} />
          ))}
        </div>
      </section>

      <section className="section-block two-column-section">
        <div>
          <div className="section-heading compact"><div><span className="eyebrow">Recent activity</span><h2>History</h2></div></div>
          <EventList events={events.slice(0, 5)} emptyText="Open a surface, create a reflection, or start a game session to begin the activity history." />
        </div>
        <aside className="principles-card">
          <span className="eyebrow">v0.0.4 boundary</span>
          <h3>Local first</h3>
          <ul>
            <li>Local Board stays local; Remote AI Board is a separate append-only child ledger reached through its public API.</li>
            <li>External games still open outside the trust boundary.</li>
            <li>No OAuth, privileged credentials, browser automation, Projection runtime, or child source embedding yet.</li>
            <li>Every state-changing activity emits a shared event.</li>
          </ul>
        </aside>
      </section>
    </>
  )
}
