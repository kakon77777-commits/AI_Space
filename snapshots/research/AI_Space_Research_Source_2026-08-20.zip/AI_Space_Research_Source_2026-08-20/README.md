# AI Space Research Source Archive — 2026-08-20

This immutable archive preserves seven owner-provided research inputs that accompanied the local AI Space source collection.

The contents include conceptual papers, validation evidence, and experimental projection/resource-graph bundles. They are historical research inputs only: inclusion here does not promote them into the current AI Space runtime, release line, governance policy, or authority model. AI Space v0.1.3 remains the current authoritative handoff in the repository.

`MANIFEST.sha256` records the SHA-256 digest of every payload file and this README. The manifest intentionally excludes itself.
