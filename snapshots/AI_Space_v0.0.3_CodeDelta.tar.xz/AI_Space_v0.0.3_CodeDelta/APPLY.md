# AI Space v0.0.3 Code Delta

Base: GitHub snapshot `AI_Space_v0.0.2_Handoff.tar.xz`.
Overlay this archive onto the extracted base project. This delta contains only changed runnable app/test files. Version notes and full evidence live in GitHub `SNAPSHOTS.md` and the separately delivered `AI_Space_v0.0.3.zip`.
