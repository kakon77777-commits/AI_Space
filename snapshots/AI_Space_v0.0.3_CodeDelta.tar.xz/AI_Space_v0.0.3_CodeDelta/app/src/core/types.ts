export type CapabilityMode = 'native' | 'api' | 'link'
export type CapabilityStatus = 'ready' | 'placeholder'

export interface CapabilityNavigation {
  visible: boolean
  order: number
}

export interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: CapabilityMode
  status: CapabilityStatus
  actions: string[]
  navigation?: CapabilityNavigation
}

export type ResourceType = 'game' | 'website' | 'research' | 'tool' | 'media'

export interface ExternalResource {
  id: string
  title: string
  type: ResourceType
  url: string
  createdAt: string
}

export interface ActivityEvent {
  id: string
  timestamp: string
  principalId: string
  action: string
  capabilityId?: string
  resourceId?: string
  sessionId?: string
  summary: string
}


export interface BoardPost {
  id: string
  principalId: string
  title: string
  body: string
  createdAt: string
  sourceSessionId?: string
  sourceResourceId?: string
}

export type GameSessionStatus = 'active' | 'completed'

export interface GameSession {
  id: string
  principalId: string
  resourceId: string
  status: GameSessionStatus
  startedAt: string
  endedAt?: string
  reflectionPostId?: string
}

export type CapabilityLifecycle = 'declared' | 'connected'
export type CapabilityHealth = 'unknown' | 'healthy' | 'degraded' | 'offline'

export interface CapabilityManifestNavigation {
  visible: boolean
  order: number
}

export interface CapabilityManifestSource {
  repository: string
}

export interface CapabilityManifestRuntime {
  baseUrl?: string
  healthPath?: string
}

export interface CapabilityManifest {
  schemaVersion: '0.1'
  id: string
  name: string
  description: string
  version: string
  mode: CapabilityMode
  lifecycle: CapabilityLifecycle
  actions: string[]
  events: string[]
  permissions: string[]
  source: CapabilityManifestSource
  navigation?: CapabilityManifestNavigation
  route?: string
  externalUrl?: string
  runtime?: CapabilityManifestRuntime
}

export interface CapabilityProvider {
  manifest: CapabilityManifest
  health: CapabilityHealth
  observedVersion?: string
}

export type CapabilityDispatchPlan =
  | { kind: 'link'; capabilityId: string; action: string; url: string }
  | { kind: 'native'; capabilityId: string; action: string; route: string }
  | { kind: 'api'; capabilityId: string; action: string; url: string; method: 'POST'; body: { capabilityId: string; action: string; input?: unknown } }
  | { kind: 'unavailable'; capabilityId: string; action: string; reason: string }
