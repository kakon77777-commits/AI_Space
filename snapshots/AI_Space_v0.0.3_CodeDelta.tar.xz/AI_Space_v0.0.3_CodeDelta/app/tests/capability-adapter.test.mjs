import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'
import {
  createDispatchPlan,
  manifestToProvider,
  loadCapabilityManifest,
  validateCapabilityManifest,
} from '../src/core/capabilityAdapter.ts'

const validApiManifest = {
  schemaVersion: '0.1',
  id: 'child:research-service',
  name: 'Research Service',
  description: 'Independent API capability.',
  version: '1.2.3',
  mode: 'api',
  lifecycle: 'declared',
  actions: ['RUN_RESEARCH'],
  events: ['RESEARCH_COMPLETED'],
  permissions: ['research:run'],
  source: { repository: 'example/research-service' },
  runtime: {},
  navigation: { visible: false, order: 50 },
}

test('validateCapabilityManifest accepts a declared API manifest and preserves independent version metadata', () => {
  const manifest = validateCapabilityManifest(validApiManifest)
  assert.equal(manifest.id, 'child:research-service')
  assert.equal(manifest.version, '1.2.3')
  assert.equal(manifest.mode, 'api')
})

test('validateCapabilityManifest rejects unsupported schema versions', () => {
  assert.throws(
    () => validateCapabilityManifest({ ...validApiManifest, schemaVersion: '9.9' }),
    /schemaVersion.*0\.1/i,
  )
})

test('validateCapabilityManifest enforces integration-mode requirements and action names', () => {
  assert.throws(
    () => validateCapabilityManifest({ ...validApiManifest, mode: 'link', externalUrl: undefined }),
    /link.*externalUrl/i,
  )
  assert.throws(
    () => validateCapabilityManifest({ ...validApiManifest, mode: 'native', route: undefined }),
    /native.*route/i,
  )
  assert.throws(
    () => validateCapabilityManifest({ ...validApiManifest, actions: ['bad action'] }),
    /action.*uppercase/i,
  )
})

test('manifestToProvider defaults observed health to unknown without claiming connectivity', () => {
  const provider = manifestToProvider(validateCapabilityManifest(validApiManifest))
  assert.equal(provider.health, 'unknown')
  assert.equal(provider.manifest.lifecycle, 'declared')
})

test('createDispatchPlan creates deterministic link and native plans', () => {
  const link = validateCapabilityManifest({
    ...validApiManifest,
    id: 'child:docs',
    name: 'Docs',
    mode: 'link',
    actions: ['OPEN'],
    externalUrl: 'https://example.com/docs',
  })
  const native = validateCapabilityManifest({
    ...validApiManifest,
    id: 'child:local-tool',
    name: 'Local Tool',
    mode: 'native',
    actions: ['OPEN'],
    route: '/local-tool',
  })

  assert.deepEqual(createDispatchPlan(link, 'OPEN'), {
    kind: 'link',
    capabilityId: 'child:docs',
    action: 'OPEN',
    url: 'https://example.com/docs',
  })
  assert.deepEqual(createDispatchPlan(native, 'OPEN'), {
    kind: 'native',
    capabilityId: 'child:local-tool',
    action: 'OPEN',
    route: '/local-tool',
  })
})

test('createDispatchPlan creates configured API plan and explicit unavailable plan when endpoint is undeclared', () => {
  const configured = validateCapabilityManifest({
    ...validApiManifest,
    lifecycle: 'connected',
    runtime: { baseUrl: 'https://service.example/api' },
  })
  const declared = validateCapabilityManifest(validApiManifest)

  assert.deepEqual(createDispatchPlan(configured, 'RUN_RESEARCH', { q: 'test' }), {
    kind: 'api',
    capabilityId: 'child:research-service',
    action: 'RUN_RESEARCH',
    url: 'https://service.example/api/invoke',
    method: 'POST',
    body: { capabilityId: 'child:research-service', action: 'RUN_RESEARCH', input: { q: 'test' } },
  })
  assert.deepEqual(createDispatchPlan(declared, 'RUN_RESEARCH'), {
    kind: 'unavailable',
    capabilityId: 'child:research-service',
    action: 'RUN_RESEARCH',
    reason: 'API capability is declared but has no runtime baseUrl',
  })
})

test('createDispatchPlan rejects actions not declared by the child manifest', () => {
  const manifest = validateCapabilityManifest(validApiManifest)
  assert.throws(() => createDispatchPlan(manifest, 'DELETE_WORLD'), /not declared/i)
})

test('shipped AI Board child manifest is machine-readable and valid', async () => {
  const here = dirname(fileURLToPath(import.meta.url))
  const raw = await readFile(resolve(here, '../public/manifests/ai-board.capability.json'), 'utf8')
  const manifest = validateCapabilityManifest(JSON.parse(raw))
  assert.equal(manifest.id, 'child:ai-board')
  assert.equal(manifest.mode, 'api')
  assert.equal(manifest.source.repository, 'kakon77777-commits/AI_Board')
})


test('loadCapabilityManifest validates fetched JSON and rejects HTTP failures', async () => {
  const fetched = await loadCapabilityManifest('/manifest.json', async () => ({
    ok: true,
    status: 200,
    async json() { return validApiManifest },
  }))
  assert.equal(fetched.id, 'child:research-service')

  await assert.rejects(
    () => loadCapabilityManifest('/missing.json', async () => ({ ok: false, status: 404, async json() { return {} } })),
    /HTTP 404/i,
  )
})
