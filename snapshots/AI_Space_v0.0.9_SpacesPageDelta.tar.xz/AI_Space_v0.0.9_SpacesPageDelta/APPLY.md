# AI Space v0.0.9 GitHub delta
Base: v0.0.8
Extract into the project root with:
`tar -xJf <archive>.tar.xz --strip-components=1 -C <project-root>`
Apply all canonical v0.0.9 deltas before use.
