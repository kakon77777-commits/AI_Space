# AI Space v0.0.5 CoreDelta

Base: reconstructed AI Space v0.0.4.

Overlay this archive at the project root. Then overlay the matching v0.0.5 UIDelta. Together they reconstruct the v0.0.5 runnable app changes.
