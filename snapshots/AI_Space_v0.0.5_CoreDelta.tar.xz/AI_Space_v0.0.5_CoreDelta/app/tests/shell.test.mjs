import test from 'node:test'
import assert from 'node:assert/strict'
import { getPageModel } from '../src/core/shell.ts'

const capabilities = [
  { id: 'home', label: 'Home', description: 'Home page', route: '/', mode: 'native', status: 'ready', actions: [] },
  { id: 'board', label: 'Board', description: 'Board page', route: '/board', mode: 'native', status: 'placeholder', actions: [] },
]

test('getPageModel resolves known capabilities', () => {
  assert.deepEqual(getPageModel(capabilities, '/board'), {
    kind: 'capability',
    capabilityId: 'board',
    title: 'Board',
  })
})

test('getPageModel returns not-found for unknown routes', () => {
  assert.deepEqual(getPageModel(capabilities, '/nope'), {
    kind: 'not-found',
    title: 'Not Found',
  })
})

test('shipped registry exposes the capability runtime manager as a native route', async () => {
  const { capabilities: shippedCapabilities } = await import('../src/data/capabilities.ts')
  assert.deepEqual(getPageModel(shippedCapabilities, '/capabilities'), {
    kind: 'capability',
    capabilityId: 'capabilities',
    title: 'Capabilities',
  })
})
