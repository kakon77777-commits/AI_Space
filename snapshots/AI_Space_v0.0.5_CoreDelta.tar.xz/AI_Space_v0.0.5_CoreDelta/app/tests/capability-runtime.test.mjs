import test from 'node:test'
import assert from 'node:assert/strict'
import { MemoryStorageAdapter } from '../src/storage/storage.ts'
import { validateCapabilityManifest, manifestToProvider } from '../src/core/capabilityAdapter.ts'
import { CapabilityRuntimeManager } from '../src/core/capabilityRuntime.ts'

function provider() {
  return manifestToProvider(validateCapabilityManifest({
    schemaVersion: '0.1',
    id: 'child:test-service',
    name: 'Test Service',
    description: 'Runtime manager test provider.',
    version: '1.0.0',
    mode: 'api',
    lifecycle: 'connected',
    actions: ['LIST_ITEMS', 'CREATE_ITEM'],
    events: ['ITEMS_READ', 'ITEM_CREATED'],
    permissions: ['items:read', 'items:write'],
    source: { repository: 'example/test-service' },
    runtime: {
      baseUrl: 'https://service.example',
      healthPath: '/health',
      actions: {
        LIST_ITEMS: { method: 'GET', path: '/api/items', input: 'query' },
        CREATE_ITEM: { method: 'POST', path: '/api/items', input: 'json' },
      },
    },
    navigation: { visible: false, order: 50 },
  }))
}

function clock(isoValues, msValues = []) {
  let i = 0
  let j = 0
  return {
    now: () => isoValues[Math.min(i++, isoValues.length - 1)],
    nowMs: () => msValues[Math.min(j++, msValues.length - 1)] ?? 0,
  }
}

test('register restores persisted operational state without mutating desired manifest lifecycle', () => {
  const storage = new MemoryStorageAdapter()
  const manager1 = new CapabilityRuntimeManager(storage)
  manager1.register(provider())
  manager1.setEnabled('child:test-service', false)

  const manager2 = new CapabilityRuntimeManager(storage)
  const snapshot = manager2.register(provider())
  assert.equal(snapshot.state.enabled, false)
  assert.equal(snapshot.provider.manifest.lifecycle, 'connected')
})

test('setEnabled persists runtime enablement independently from the child manifest', () => {
  const storage = new MemoryStorageAdapter()
  const manager = new CapabilityRuntimeManager(storage)
  manager.register(provider())

  assert.equal(manager.get('child:test-service').state.enabled, true)
  manager.setEnabled('child:test-service', false)
  assert.equal(manager.get('child:test-service').state.enabled, false)
  assert.equal(manager.get('child:test-service').provider.manifest.lifecycle, 'connected')
})

test('probe records health, timestamp, latency, and clears an old error', async () => {
  const storage = new MemoryStorageAdapter()
  const times = clock(['2026-08-19T09:00:00.000Z'], [100, 142])
  const manager = new CapabilityRuntimeManager(storage, {
    now: times.now,
    nowMs: times.nowMs,
    fetcher: async (url) => {
      assert.equal(url, 'https://service.example/health')
      return { ok: true, status: 200, async json() { return { ok: true } } }
    },
  })
  manager.register(provider())

  const snapshot = await manager.probe('child:test-service')
  assert.equal(snapshot.state.health, 'healthy')
  assert.equal(snapshot.state.lastProbeAt, '2026-08-19T09:00:00.000Z')
  assert.equal(snapshot.state.lastLatencyMs, 42)
  assert.equal(snapshot.state.lastError, undefined)
})

test('probe records offline state and error when the provider cannot be reached', async () => {
  const storage = new MemoryStorageAdapter()
  const manager = new CapabilityRuntimeManager(storage, {
    now: () => '2026-08-19T09:01:00.000Z',
    nowMs: (() => { let n = 0; return () => n++ === 0 ? 10 : 25 })(),
    fetcher: async () => { throw new Error('network unreachable') },
  })
  manager.register(provider())

  const snapshot = await manager.probe('child:test-service')
  assert.equal(snapshot.state.health, 'offline')
  assert.match(snapshot.state.lastError, /network unreachable/i)
  assert.equal(snapshot.state.lastLatencyMs, 15)
})

test('preview is side-effect free and does not call the network fetcher', () => {
  const storage = new MemoryStorageAdapter()
  let calls = 0
  const manager = new CapabilityRuntimeManager(storage, {
    fetcher: async () => { calls += 1; throw new Error('must not fetch') },
  })
  manager.register(provider())

  const plan = manager.preview('child:test-service', 'LIST_ITEMS', { limit: 2 })
  assert.deepEqual(plan, {
    kind: 'api',
    capabilityId: 'child:test-service',
    action: 'LIST_ITEMS',
    url: 'https://service.example/api/items?limit=2',
    method: 'GET',
  })
  assert.equal(calls, 0)
})

test('invoke rejects disabled providers before dispatch', async () => {
  const storage = new MemoryStorageAdapter()
  let calls = 0
  const manager = new CapabilityRuntimeManager(storage, {
    fetcher: async () => { calls += 1; throw new Error('must not fetch') },
  })
  manager.register(provider())
  manager.setEnabled('child:test-service', false)

  await assert.rejects(() => manager.invoke('child:test-service', 'LIST_ITEMS'), /disabled/i)
  assert.equal(calls, 0)
})

test('invoke executes an enabled API capability and records last success', async () => {
  const storage = new MemoryStorageAdapter()
  const manager = new CapabilityRuntimeManager(storage, {
    now: () => '2026-08-19T09:02:00.000Z',
    fetcher: async (url, init) => {
      assert.equal(url, 'https://service.example/api/items')
      assert.equal(init.method, 'POST')
      return { ok: true, status: 201, async json() { return { id: 'item-1' } } }
    },
  })
  manager.register(provider())

  const result = await manager.invoke('child:test-service', 'CREATE_ITEM', { title: 'Hello' })
  assert.deepEqual(result, { status: 201, data: { id: 'item-1' } })
  const state = manager.get('child:test-service').state
  assert.equal(state.lastSuccessAt, '2026-08-19T09:02:00.000Z')
  assert.equal(state.lastError, undefined)
})

test('invoke records the child error and rethrows it', async () => {
  const storage = new MemoryStorageAdapter()
  const manager = new CapabilityRuntimeManager(storage, {
    now: () => '2026-08-19T09:03:00.000Z',
    fetcher: async () => ({ ok: false, status: 503, async json() { return { error: 'maintenance' } } }),
  })
  manager.register(provider())

  await assert.rejects(() => manager.invoke('child:test-service', 'LIST_ITEMS'), /503.*maintenance/i)
  assert.match(manager.get('child:test-service').state.lastError, /503.*maintenance/i)
})
