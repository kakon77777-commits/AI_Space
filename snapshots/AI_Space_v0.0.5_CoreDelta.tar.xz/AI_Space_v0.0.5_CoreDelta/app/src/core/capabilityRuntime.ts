import type {
  CapabilityDispatchPlan,
  CapabilityHealth,
  CapabilityProvider,
  CapabilityRuntimeSnapshot,
  CapabilityRuntimeState,
} from './types.ts'
import {
  createDispatchPlan,
  executeApiDispatch,
  type JsonFetcher,
} from './capabilityAdapter.ts'
import type { StorageAdapter } from '../storage/storage.ts'

const DEFAULT_KEY = 'ai-space.capability-runtime.v1'

interface RuntimeOptions {
  now?: () => string
  nowMs?: () => number
  fetcher?: JsonFetcher
  key?: string
}

function defaultFetcher(input: string, init?: { method?: string; headers?: Record<string, string>; body?: string }) {
  return fetch(input, init) as unknown as ReturnType<JsonFetcher>
}

function isHealth(value: unknown): value is CapabilityHealth {
  return value === 'unknown' || value === 'healthy' || value === 'degraded' || value === 'offline'
}

function optionalString(value: unknown): string | undefined {
  return typeof value === 'string' && value ? value : undefined
}

function optionalNumber(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function parseState(value: unknown): CapabilityRuntimeState | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
  const record = value as Record<string, unknown>
  if (typeof record.capabilityId !== 'string' || !record.capabilityId) return undefined
  if (typeof record.enabled !== 'boolean' || !isHealth(record.health)) return undefined
  return {
    capabilityId: record.capabilityId,
    enabled: record.enabled,
    health: record.health,
    ...(optionalString(record.lastProbeAt) ? { lastProbeAt: optionalString(record.lastProbeAt) } : {}),
    ...(optionalString(record.lastInvokeAt) ? { lastInvokeAt: optionalString(record.lastInvokeAt) } : {}),
    ...(optionalNumber(record.lastLatencyMs) !== undefined ? { lastLatencyMs: optionalNumber(record.lastLatencyMs) } : {}),
    ...(optionalString(record.lastSuccessAt) ? { lastSuccessAt: optionalString(record.lastSuccessAt) } : {}),
    ...(optionalString(record.lastError) ? { lastError: optionalString(record.lastError) } : {}),
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

export class CapabilityRuntimeManager {
  private readonly storage: StorageAdapter
  private readonly now: () => string
  private readonly nowMs: () => number
  private readonly fetcher: JsonFetcher
  private readonly key: string
  private readonly providers = new Map<string, CapabilityProvider>()
  private readonly states = new Map<string, CapabilityRuntimeState>()

  constructor(storage: StorageAdapter, options: RuntimeOptions = {}) {
    this.storage = storage
    this.now = options.now ?? (() => new Date().toISOString())
    this.nowMs = options.nowMs ?? (() => Date.now())
    this.fetcher = options.fetcher ?? (defaultFetcher as JsonFetcher)
    this.key = options.key ?? DEFAULT_KEY
    this.restore()
  }

  register(provider: CapabilityProvider): CapabilityRuntimeSnapshot {
    const id = provider.manifest.id
    this.providers.set(id, provider)
    const existing = this.states.get(id)
    if (!existing) {
      this.states.set(id, {
        capabilityId: id,
        enabled: true,
        health: provider.health,
      })
      this.persist()
    }
    return this.get(id)
  }

  list(): CapabilityRuntimeSnapshot[] {
    return [...this.providers.keys()].sort().map((id) => this.get(id))
  }

  get(capabilityId: string): CapabilityRuntimeSnapshot {
    const provider = this.providers.get(capabilityId)
    const state = this.states.get(capabilityId)
    if (!provider || !state) throw new Error(`Capability provider ${capabilityId} is not registered`)
    return {
      provider: { ...provider, health: state.health },
      state: { ...state },
    }
  }

  setEnabled(capabilityId: string, enabled: boolean): CapabilityRuntimeSnapshot {
    const current = this.requireState(capabilityId)
    this.states.set(capabilityId, { ...current, enabled })
    this.persist()
    return this.get(capabilityId)
  }

  preview(capabilityId: string, action: string, input?: unknown): CapabilityDispatchPlan {
    return createDispatchPlan(this.requireProvider(capabilityId).manifest, action, input)
  }

  async probe(capabilityId: string): Promise<CapabilityRuntimeSnapshot> {
    const provider = this.requireProvider(capabilityId)
    const current = this.requireState(capabilityId)
    const started = this.nowMs()
    const lastProbeAt = this.now()
    const runtime = provider.manifest.runtime
    if (!runtime?.baseUrl || !runtime.healthPath) {
      this.states.set(capabilityId, {
        ...current,
        health: 'unknown',
        lastProbeAt,
        lastLatencyMs: Math.max(0, this.nowMs() - started),
        lastError: 'Health endpoint is not configured',
      })
      this.persist()
      return this.get(capabilityId)
    }

    try {
      const response = await this.fetcher(`${runtime.baseUrl}${runtime.healthPath}`, { method: 'GET' })
      const latency = Math.max(0, this.nowMs() - started)
      const next: CapabilityRuntimeState = response.ok
        ? { ...current, health: 'healthy', lastProbeAt, lastLatencyMs: latency, lastError: undefined }
        : { ...current, health: 'degraded', lastProbeAt, lastLatencyMs: latency, lastError: `Health probe failed with HTTP ${response.status}` }
      this.states.set(capabilityId, next)
    } catch (error) {
      this.states.set(capabilityId, {
        ...current,
        health: 'offline',
        lastProbeAt,
        lastLatencyMs: Math.max(0, this.nowMs() - started),
        lastError: errorMessage(error),
      })
    }
    this.persist()
    return this.get(capabilityId)
  }

  async invoke(capabilityId: string, action: string, input?: unknown): Promise<{ status: number; data: unknown }> {
    const current = this.requireState(capabilityId)
    if (!current.enabled) throw new Error(`Capability provider ${capabilityId} is disabled`)
    const lastInvokeAt = this.now()
    const plan = this.preview(capabilityId, action, input)
    if (plan.kind !== 'api') throw new Error(`Capability runtime manager can invoke API plans only in v0.0.5 (received ${plan.kind})`)
    try {
      const result = await executeApiDispatch(plan, this.fetcher)
      this.states.set(capabilityId, {
        ...current,
        health: 'healthy',
        lastInvokeAt,
        lastSuccessAt: lastInvokeAt,
        lastError: undefined,
      })
      this.persist()
      return result
    } catch (error) {
      const message = errorMessage(error)
      this.states.set(capabilityId, {
        ...current,
        health: /HTTP \d+/i.test(message) ? 'degraded' : 'offline',
        lastInvokeAt,
        lastError: message,
      })
      this.persist()
      throw error
    }
  }

  private requireProvider(capabilityId: string): CapabilityProvider {
    const provider = this.providers.get(capabilityId)
    if (!provider) throw new Error(`Capability provider ${capabilityId} is not registered`)
    return provider
  }

  private requireState(capabilityId: string): CapabilityRuntimeState {
    const state = this.states.get(capabilityId)
    if (!state) throw new Error(`Capability provider ${capabilityId} is not registered`)
    return state
  }

  private restore(): void {
    const raw = this.storage.getItem(this.key)
    if (!raw) return
    try {
      const parsed = JSON.parse(raw)
      if (!Array.isArray(parsed)) return
      for (const value of parsed) {
        const state = parseState(value)
        if (state) this.states.set(state.capabilityId, state)
      }
    } catch {
      // Invalid local runtime metadata is ignored; manifests remain authoritative.
    }
  }

  private persist(): void {
    this.storage.setItem(this.key, JSON.stringify([...this.states.values()]))
  }
}
