# AI Space v0.0.5 UIDelta

Base: reconstructed AI Space v0.0.4 plus v0.0.5 CoreDelta.

Overlay this archive at the project root after CoreDelta. Together the two deltas reconstruct the v0.0.5 runnable app changes.
