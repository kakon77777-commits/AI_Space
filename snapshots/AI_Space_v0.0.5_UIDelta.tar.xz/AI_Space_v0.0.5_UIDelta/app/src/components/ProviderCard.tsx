import type { CapabilityProvider, CapabilityRuntimeState } from '../core/types.ts'

function readableTime(value?: string): string {
  return value ? new Date(value).toLocaleString() : '—'
}

export function ProviderCard({
  provider,
  runtime,
  onProbe,
  onToggle,
  busy = false,
}: {
  provider: CapabilityProvider
  runtime?: CapabilityRuntimeState
  onProbe?: () => void
  onToggle?: () => void
  busy?: boolean
}) {
  const { manifest, health } = provider
  const observedHealth = runtime?.health ?? health
  return (
    <article className="provider-card">
      <div className="provider-card-topline">
        <div>
          <span className="capability-kicker">{manifest.id}</span>
          <h3>{manifest.name}</h3>
        </div>
        <div className="provider-badges">
          <span className={`provider-badge provider-health-${observedHealth}`}>{observedHealth}</span>
          <span className="provider-badge">{manifest.mode}</span>
          {runtime ? <span className={`provider-badge ${runtime.enabled ? 'provider-enabled' : 'provider-disabled'}`}>{runtime.enabled ? 'enabled' : 'disabled'}</span> : null}
        </div>
      </div>
      <p>{manifest.description}</p>
      <dl className="provider-meta">
        <div><dt>Version</dt><dd>{manifest.version}</dd></div>
        <div><dt>Lifecycle</dt><dd>{manifest.lifecycle}</dd></div>
        <div><dt>Source</dt><dd><code>{manifest.source.repository}</code></dd></div>
        <div><dt>Actions</dt><dd>{manifest.actions.length}</dd></div>
        {runtime ? <><div><dt>Last probe</dt><dd>{readableTime(runtime.lastProbeAt)}</dd></div><div><dt>Latency</dt><dd>{runtime.lastLatencyMs === undefined ? '—' : `${runtime.lastLatencyMs} ms`}</dd></div><div><dt>Last success</dt><dd>{readableTime(runtime.lastSuccessAt)}</dd></div><div><dt>Last invoke</dt><dd>{readableTime(runtime.lastInvokeAt)}</dd></div></> : null}
      </dl>
      {runtime?.lastError ? <p className="provider-error">Last error: {runtime.lastError}</p> : null}
      {manifest.mode === 'api' && !manifest.runtime?.baseUrl ? (
        <p className="provider-note">Declared contract only · runtime endpoint intentionally not configured.</p>
      ) : manifest.mode === 'api' && manifest.runtime?.baseUrl ? (
        <p className="provider-note">Runtime: <code>{manifest.runtime.baseUrl}</code></p>
      ) : null}
      {runtime && onProbe && onToggle ? (
        <div className="button-row">
          <button className="secondary-button" type="button" disabled={busy} onClick={onProbe}>{busy ? 'Probing…' : 'Probe'}</button>
          <button className={runtime.enabled ? 'danger-button' : 'primary-button'} type="button" disabled={busy} onClick={onToggle}>{runtime.enabled ? 'Disable' : 'Enable'}</button>
        </div>
      ) : null}
    </article>
  )
}
