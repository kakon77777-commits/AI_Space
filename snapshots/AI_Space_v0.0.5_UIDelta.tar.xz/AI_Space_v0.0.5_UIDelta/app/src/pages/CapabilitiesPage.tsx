import { useState } from 'react'
import type { CapabilityDispatchPlan, CapabilityRuntimeSnapshot } from '../core/types.ts'
import { ProviderCard } from '../components/ProviderCard.tsx'

function parseJsonInput(value: string): unknown {
  const trimmed = value.trim()
  return trimmed ? JSON.parse(trimmed) : undefined
}

export function CapabilitiesPage({
  snapshots,
  providerLoadError,
  onProbe,
  onToggle,
  onPreview,
  onInvoke,
}: {
  snapshots: CapabilityRuntimeSnapshot[]
  providerLoadError: string | null
  onProbe: (capabilityId: string) => Promise<void>
  onToggle: (capabilityId: string, enabled: boolean) => void
  onPreview: (capabilityId: string, action: string, input?: unknown) => CapabilityDispatchPlan
  onInvoke: (capabilityId: string, action: string, input?: unknown) => Promise<{ status: number; data: unknown }>
}) {
  const [selectedActions, setSelectedActions] = useState<Record<string, string>>({})
  const [inputs, setInputs] = useState<Record<string, string>>({})
  const [outputs, setOutputs] = useState<Record<string, string>>({})
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState<Record<string, boolean>>({})

  function actionFor(snapshot: CapabilityRuntimeSnapshot): string {
    return selectedActions[snapshot.provider.manifest.id] ?? snapshot.provider.manifest.actions[0] ?? ''
  }

  function setError(id: string, message: string) {
    setErrors((current) => ({ ...current, [id]: message }))
  }

  function setOutput(id: string, value: unknown) {
    setOutputs((current) => ({ ...current, [id]: JSON.stringify(value, null, 2) }))
    setError(id, '')
  }

  async function probe(id: string) {
    setBusy((current) => ({ ...current, [id]: true }))
    try {
      await onProbe(id)
      setError(id, '')
    } catch (error) {
      setError(id, error instanceof Error ? error.message : 'Probe failed')
    } finally {
      setBusy((current) => ({ ...current, [id]: false }))
    }
  }

  function preview(snapshot: CapabilityRuntimeSnapshot) {
    const id = snapshot.provider.manifest.id
    try {
      setOutput(id, onPreview(id, actionFor(snapshot), parseJsonInput(inputs[id] ?? '')))
    } catch (error) {
      setError(id, error instanceof Error ? error.message : 'Preview failed')
    }
  }

  async function invoke(snapshot: CapabilityRuntimeSnapshot) {
    const id = snapshot.provider.manifest.id
    setBusy((current) => ({ ...current, [id]: true }))
    try {
      setOutput(id, await onInvoke(id, actionFor(snapshot), parseJsonInput(inputs[id] ?? '')))
    } catch (error) {
      setError(id, error instanceof Error ? error.message : 'Invocation failed')
    } finally {
      setBusy((current) => ({ ...current, [id]: false }))
    }
  }

  return (
    <>
      <section className="surface-panel arcade-banner">
        <span className="eyebrow">v0.0.5 · capability runtime manager</span>
        <h2>Mother runtime control plane</h2>
        <p>Manifests remain the desired contract. This page manages only local operational state: enablement, health observations, dispatch previews, invocations, latency, and the latest runtime error.</p>
      </section>

      {providerLoadError ? <div className="empty-state">Manifest load failed: {providerLoadError}</div> : null}
      {snapshots.length === 0 && !providerLoadError ? <div className="empty-state">Discovering child capability manifests…</div> : null}

      <div className="runtime-provider-list">
        {snapshots.map((snapshot) => {
          const id = snapshot.provider.manifest.id
          const action = actionFor(snapshot)
          return (
            <section className="runtime-provider-block" key={id}>
              <ProviderCard
                provider={snapshot.provider}
                runtime={snapshot.state}
                onProbe={() => probe(id)}
                onToggle={() => onToggle(id, !snapshot.state.enabled)}
                busy={busy[id] === true}
              />
              <div className="surface-panel runtime-console">
                <div className="section-heading compact">
                  <div><span className="eyebrow">Dispatch console</span><h2>{snapshot.provider.manifest.name}</h2></div>
                  <span className="muted">Preview never sends a request.</span>
                </div>
                <div className="runtime-console-grid">
                  <label>Action
                    <select value={action} onChange={(event: React.ChangeEvent<HTMLSelectElement>) => setSelectedActions((current) => ({ ...current, [id]: event.target.value }))}>
                      {snapshot.provider.manifest.actions.map((item) => <option key={item} value={item}>{item}</option>)}
                    </select>
                  </label>
                  <label>Input JSON
                    <textarea rows={7} value={inputs[id] ?? ''} onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => setInputs((current) => ({ ...current, [id]: event.target.value }))} placeholder={'{"limit": 5}'} />
                  </label>
                </div>
                <div className="button-row">
                  <button className="secondary-button" type="button" onClick={() => preview(snapshot)}>Preview</button>
                  <button className="primary-button" type="button" disabled={!snapshot.state.enabled || busy[id]} onClick={() => invoke(snapshot)}>{busy[id] ? 'Working…' : 'Invoke'}</button>
                </div>
                {errors[id] ? <p className="form-error">{errors[id]}</p> : null}
                {outputs[id] ? <pre className="runtime-output">{outputs[id]}</pre> : null}
              </div>
            </section>
          )
        })}
      </div>
    </>
  )
}
