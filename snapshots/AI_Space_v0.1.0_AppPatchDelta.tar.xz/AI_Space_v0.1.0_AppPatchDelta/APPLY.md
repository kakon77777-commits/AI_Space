# AI Space v0.1.0 AppPatchDelta

Base: v0.0.9 after earlier v0.1.0 CoreRuntime/CoreTests overlays.
Apply from project root:

```bash
patch -p0 < patches/App.tsx.patch
```

This patch changes only `app/src/App.tsx`.
