Base: AI Space v0.1.1. Extract with --strip-components=1, then from project root run: patch --batch -p0 < patches/types.patch
