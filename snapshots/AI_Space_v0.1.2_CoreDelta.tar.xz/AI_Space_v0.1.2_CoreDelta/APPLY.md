Base: AI Space v0.1.1. Extract with --strip-components=1 into the project root.
