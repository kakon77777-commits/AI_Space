import type { StorageAdapter } from '../storage/storage.ts'
import type { AiSpaceStateBundle } from './types.ts'

export const AI_SPACE_STATE_KEYS = [
  'ai-space.principals.v1',
  'ai-space.active-principal.v1',
  'ai-space.context-sessions.v1',
  'ai-space.projections.v1',
  'ai-space.projection-checkpoints.v1',
  'ai-space.projection-merge-candidates.v1',
  'ai-space.spaces.v1',
  'ai-space.space-memberships.v1',
  'ai-space.space-presences.v1',
  'ai-space.space-resource-refs.v1',
  'ai-space.resources.v1',
  'ai-space.events.v1',
  'ai-space.posts.v1',
  'ai-space.game-sessions.v1',
  'ai-space.browser-sessions.v1',
  'ai-space.experience-records.v1',
  'ai-space.experience-reflection-candidates.v1',
  'ai-space.mvp-journeys.v1',
  'ai-space.capability-runtime.v1',
] as const

export type AiSpaceStateKey = typeof AI_SPACE_STATE_KEYS[number]

interface ExportOptions {
  appVersion: string
  createdAt?: string
}

function canonicalEntries(entries: Record<string, string | null>): Record<string, string | null> {
  const ordered: Record<string, string | null> = {}
  for (const key of AI_SPACE_STATE_KEYS) ordered[key] = entries[key] ?? null
  return ordered
}

function canonicalChecksumInput(bundle: Pick<AiSpaceStateBundle, 'schemaVersion' | 'appVersion' | 'createdAt' | 'checksumAlgorithm' | 'entries'>): string {
  return JSON.stringify({
    schemaVersion: bundle.schemaVersion,
    appVersion: bundle.appVersion,
    createdAt: bundle.createdAt,
    checksumAlgorithm: bundle.checksumAlgorithm,
    entries: canonicalEntries(bundle.entries),
  })
}

function fnv1a32(input: string): string {
  const bytes = new TextEncoder().encode(input)
  let hash = 0x811c9dc5
  for (const byte of bytes) {
    hash ^= byte
    hash = Math.imul(hash, 0x01000193) >>> 0
  }
  return hash.toString(16).padStart(8, '0')
}

export function exportAiSpaceStateBundle(storage: StorageAdapter, options: ExportOptions): AiSpaceStateBundle {
  const entries: Record<string, string | null> = {}
  for (const key of AI_SPACE_STATE_KEYS) entries[key] = storage.getItem(key)
  const base = {
    schemaVersion: '1.0' as const,
    appVersion: options.appVersion.trim(),
    createdAt: options.createdAt ?? new Date().toISOString(),
    checksumAlgorithm: 'fnv1a32' as const,
    entries,
  }
  if (!base.appVersion) throw new Error('App version is required')
  return { ...base, checksum: fnv1a32(canonicalChecksumInput(base)) }
}

export function validateAiSpaceStateBundle(input: unknown): AiSpaceStateBundle {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('State bundle must be an object')
  const candidate = input as Record<string, unknown>
  if (candidate.schemaVersion !== '1.0') throw new Error(`Unsupported state bundle schema version: ${String(candidate.schemaVersion)}`)
  if (candidate.checksumAlgorithm !== 'fnv1a32') throw new Error(`Unsupported checksum algorithm: ${String(candidate.checksumAlgorithm)}`)
  if (typeof candidate.appVersion !== 'string' || !candidate.appVersion.trim()) throw new Error('State bundle appVersion is required')
  if (typeof candidate.createdAt !== 'string' || !candidate.createdAt.trim()) throw new Error('State bundle createdAt is required')
  if (typeof candidate.checksum !== 'string' || !/^[0-9a-f]{8}$/.test(candidate.checksum)) throw new Error('State bundle checksum is invalid')
  if (!candidate.entries || typeof candidate.entries !== 'object' || Array.isArray(candidate.entries)) throw new Error('State bundle entries must be an object')

  const entries = candidate.entries as Record<string, unknown>
  const actualKeys = Object.keys(entries)
  if (actualKeys.length !== AI_SPACE_STATE_KEYS.length || AI_SPACE_STATE_KEYS.some((key) => !Object.hasOwn(entries, key)) || actualKeys.some((key) => !(AI_SPACE_STATE_KEYS as readonly string[]).includes(key))) {
    throw new Error('State bundle entry keys do not match the supported AI Space allowlist')
  }
  for (const key of AI_SPACE_STATE_KEYS) {
    const value = entries[key]
    if (value !== null && typeof value !== 'string') throw new Error(`State bundle entry ${key} must be string or null`)
  }

  const bundle: AiSpaceStateBundle = {
    schemaVersion: '1.0',
    appVersion: candidate.appVersion,
    createdAt: candidate.createdAt,
    checksumAlgorithm: 'fnv1a32',
    checksum: candidate.checksum,
    entries: canonicalEntries(entries as Record<string, string | null>),
  }
  const expected = fnv1a32(canonicalChecksumInput(bundle))
  if (bundle.checksum !== expected) throw new Error('State bundle checksum mismatch')
  return bundle
}

export function parseAiSpaceStateBundle(text: string): AiSpaceStateBundle {
  if (!text.trim()) throw new Error('State bundle JSON is empty')
  let parsed: unknown
  try {
    parsed = JSON.parse(text)
  } catch {
    throw new Error('State bundle JSON is invalid')
  }
  return validateAiSpaceStateBundle(parsed)
}

import { MemoryStorageAdapter } from '../storage/storage.ts'
import { PrincipalStore } from './principals.ts'
import { ContextSessionStore } from './contextSessions.ts'
import { ProjectionStore } from './projections.ts'
import { SpaceStore } from './spaces.ts'
import { ResourceStore } from './resources.ts'
import { BrowserSessionStore } from './browserSessions.ts'
import { PostStore } from './posts.ts'
import { MvpJourneyStore } from './mvpJourneys.ts'
import { auditAiSpaceState } from './hardening.ts'
import type {
  AiSpaceStateRestorePreview,
  AiSpaceStateRestoreResult,
  AiSpaceStateRestoreValidation,
  Capability,
} from './types.ts'

export interface AiSpaceStateRestoreOptions {
  capabilities: Capability[]
}

const ACTIVE_PRINCIPAL_KEY = 'ai-space.active-principal.v1'
const JSON_STATE_KEYS = AI_SPACE_STATE_KEYS.filter((key) => key !== ACTIVE_PRINCIPAL_KEY)

function validateSerializedEntries(bundle: AiSpaceStateBundle): void {
  for (const key of JSON_STATE_KEYS) {
    const raw = bundle.entries[key]
    if (raw === null) continue
    try {
      JSON.parse(raw)
    } catch {
      throw new Error(`State bundle entry ${key} contains invalid JSON`)
    }
  }
}

function writeBundleEntries(storage: StorageAdapter, bundle: AiSpaceStateBundle): void {
  for (const key of AI_SPACE_STATE_KEYS) {
    const value = bundle.entries[key]
    if (value === null) storage.removeItem(key)
    else storage.setItem(key, value)
  }
}

function stageBundle(bundle: AiSpaceStateBundle): MemoryStorageAdapter {
  const staged = new MemoryStorageAdapter()
  writeBundleEntries(staged, bundle)
  return staged
}

function auditStagedState(storage: StorageAdapter, capabilities: Capability[]) {
  const principals = new PrincipalStore(storage)
  const contexts = new ContextSessionStore(storage)
  const projections = new ProjectionStore(storage, principals)
  const spaces = new SpaceStore(storage, principals)
  const resources = new ResourceStore(storage)
  const browsers = new BrowserSessionStore(storage)
  const posts = new PostStore(storage)
  const journeys = new MvpJourneyStore(storage)
  return auditAiSpaceState({
    principals: principals.list(),
    contextSessions: contexts.list(),
    projections: projections.list(),
    spaces: spaces.list(),
    memberships: spaces.allMemberships(),
    presences: spaces.presences(),
    resourceRefs: spaces.resourceRefs(),
    capabilities,
    resources: resources.list(),
    browserSessions: browsers.sessions(),
    experiences: browsers.experiences(),
    reflectionCandidates: browsers.reflectionCandidates(),
    posts: posts.list(),
    journeys: journeys.list(),
    activePrincipalId: storage.getItem(ACTIVE_PRINCIPAL_KEY) ?? '',
  })
}

export function previewAiSpaceStateRestore(input: unknown, target: StorageAdapter): AiSpaceStateRestorePreview {
  const bundle = validateAiSpaceStateBundle(input)
  let created = 0
  let changed = 0
  let cleared = 0
  let unchanged = 0
  for (const key of AI_SPACE_STATE_KEYS) {
    const current = target.getItem(key)
    const incoming = bundle.entries[key]
    if (current === incoming) unchanged++
    else if (current === null && incoming !== null) created++
    else if (current !== null && incoming === null) cleared++
    else changed++
  }
  return { created, changed, cleared, unchanged }
}

export function validateAiSpaceStateRestore(input: unknown, options: AiSpaceStateRestoreOptions): AiSpaceStateRestoreValidation {
  const bundle = validateAiSpaceStateBundle(input)
  validateSerializedEntries(bundle)
  const audit = auditStagedState(stageBundle(bundle), options.capabilities)
  if (audit.errorCount > 0) {
    const codes = audit.findings.filter((item) => item.severity === 'error').map((item) => item.code)
    throw new Error(`Staged state audit failed: ${codes.join(', ')}`)
  }
  return { audit }
}

export function restoreAiSpaceStateBundle(input: unknown, target: StorageAdapter, options: AiSpaceStateRestoreOptions): AiSpaceStateRestoreResult {
  const bundle = validateAiSpaceStateBundle(input)
  const preview = previewAiSpaceStateRestore(bundle, target)
  const validation = validateAiSpaceStateRestore(bundle, options)
  const before: Record<string, string | null> = {}
  for (const key of AI_SPACE_STATE_KEYS) before[key] = target.getItem(key)
  try {
    writeBundleEntries(target, bundle)
  } catch (error) {
    for (const key of AI_SPACE_STATE_KEYS) {
      const value = before[key]
      if (value === null) target.removeItem(key)
      else target.setItem(key, value)
    }
    throw error
  }
  return { preview, audit: validation.audit }
}
