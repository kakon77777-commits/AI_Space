Overlay from the project root with --strip-components=1.
