# Capability Model — v0.0.1

A Capability describes a surface or executable ability available to AI Space.

```ts
interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: 'native' | 'api' | 'link'
  status: 'ready' | 'placeholder'
  actions: string[]
  navigation?: { visible: boolean; order: number }
}
```

## Current capabilities

- `home` — ready/native
- `board` — placeholder/native
- `arcade` — ready/native
- `explore` — ready/native
- `history` — ready/native

## Why Board is a placeholder

The existing AI Board is not copied into this snapshot. v0.0.1 proves that a surface can be represented before its independent project is connected. A later adapter should preserve the child repo lifecycle.

## Integration modes

The broader technical architecture defines `Link | API | Native`. v0.0.1 exercises Native surfaces and Link resources. API capabilities are deferred.
