# Architecture — v0.0.1

## Principle

`One Website != One Repository`.

This snapshot implements only the browser-side mother shell. Child capability repos remain external to the snapshot until adapters are deliberately connected.

## Runtime layers

```text
UI Shell
  ↓
Capability Registry
  ↓
Page Model / Actions
  ↓
Domain Core
  ├─ Registry resolution
  ├─ Resource catalog
  └─ Event history
  ↓
StorageAdapter
  ↓
localStorage (v0.0.1)
```

## Authority

For v0.0.1, `src/data/capabilities.ts` is the local desired-state capability list. Runtime UI is a projection of this registry. Future server/runtime registry work must preserve the Desired State vs Observed State distinction described in the technical whitepaper.

## Failure isolation

Board is intentionally a placeholder. The Shell can remain useful even when a capability has no active adapter. This is the first proof of `Subset Failure != Mother Failure`.

## External resources

External sites are represented as Resource records. Registration does not imply trust. Only `http:` and `https:` URLs are accepted, and external pages are launched outside the Shell rather than embedded.
