# Changelog

## v0.0.1 — 2026-08-18

### Added
- First AI Space Foundation Shell.
- Capability Registry with Home, Board, Arcade, Explore, and History.
- Framework-independent TypeScript registry, event, resource, and storage core.
- HTTP(S)-only external resource validation.
- localStorage event/resource persistence.
- Registry-driven navigation and custom lightweight hash routing.
- External game resources projected into Arcade.
- Local cross-capability activity history.
- Snapshot-first GitHub workflow documentation.
- Public paper and technical whitepaper copied into reference docs.

### Deliberately deferred
- Backend/API.
- OAuth/OIDC.
- AI Board adapter.
- Agent Projection runtime.
- Browser agent/isolation runtime.
