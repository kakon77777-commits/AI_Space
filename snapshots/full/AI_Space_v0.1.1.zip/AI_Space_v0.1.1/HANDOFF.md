# AI Space v0.1.1 Handoff

Base: v0.1.0 First Coherent AI Space MVP.

v0.1.1 is a hardening release. It adds no new horizontal product subsystem.

Key files:
- `app/src/core/hardening.ts` — pure invariant auditor.
- `app/src/core/spaces.ts` — deterministic derived-state cleanup.
- `app/src/core/projections.ts` — shared Projection runtime access guard.
- `app/src/core/mvpJourneys.ts` — Journey recovery service.
- `app/tests/hardening-*.test.mjs`, `mvp-recovery.test.mjs`, `projection-runtime-guard.test.mjs` — regression/acceptance gates.

Do not auto-delete authoritative domain records during recovery. Only backfill unique lineage-proven references; otherwise keep the issue visible or explicitly abandon the active Journey.
