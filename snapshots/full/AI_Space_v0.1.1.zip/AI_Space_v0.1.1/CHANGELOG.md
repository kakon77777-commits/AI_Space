# Changelog

## 0.1.1 — 2026-08-20

- Added pure AI Space runtime invariant auditor.
- Added idempotent cleanup for stale Space presences and missing-resource refs.
- Consolidated Projection active/permission/Space-presence runtime guard.
- Added reload-safe MVP Journey reference reconciliation/resume/broken-abandon recovery.
- Added deliberate-corruption hardening acceptance test.
- Preserved v0.1.0 product boundaries and snapshot-first GitHub policy.
