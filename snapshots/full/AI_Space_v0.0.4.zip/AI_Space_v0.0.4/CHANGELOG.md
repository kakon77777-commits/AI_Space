# Changelog

## v0.0.4 — 2026-08-19

### Added
- Backward-compatible per-action HTTP bindings in `CapabilityManifest.runtime.actions`.
- `GET | POST` binding methods and `query | json | none` input modes.
- Deterministic query serialization for bound GET actions.
- Generic `executeApiDispatch` HTTP executor with non-2xx failure propagation.
- Generic provider health probe using `runtime.healthPath`.
- `aiBoard.ts` typed child adapter.
- AI Board manifest configured as `connected`, version `1.0.0-rc.1`, source `kakon77777-commits/ai-board`.
- AI Board public Worker action bindings for message read/create/comment.
- Remote AI Board UI inside the existing Board surface.
- Explicit self-declared identity form for remote append.
- Successful remote read/write events in AI Space History.
- Post-success refresh isolation: a refresh failure no longer falsely converts a successful append into a failed append.
- `docs/LIVE_CHILD_PROVIDER.md`.
- 9 additional dependency-free tests; full suite is now 36 tests.

### Verification environment
- Live AI Board probe attempted; build container failed DNS resolution before HTTP.
- `npm install --no-audit --no-fund` attempted; timed out after 25 seconds.
- Networked Vitest/Vite production build remains required before deployment.

### Still deferred
- Provider catalog persistence / enable-disable governance.
- OAuth/OIDC.
- Remote MCP/A2A transports.
- Browser automation and Projection runtime.

## v0.0.3 — 2026-08-19

### Added
- Machine-readable child `CapabilityManifest` contract (`schemaVersion: 0.1`).
- Strict dependency-free manifest validation.
- `link | api | native` integration-mode requirements.
- Independent provider version, source repository, actions, events, permissions, navigation, lifecycle, and runtime metadata.
- Conservative provider health state (`unknown` by default).
- Deterministic Link / Native / API / unavailable dispatch plans.
- Fail-closed capability ID and normalized route collision checks.
- Static AI Board child manifest as metadata only; no child source copied and no live endpoint claimed.
- Home provider diagnostics.
- 11 additional/expanded adapter-registry tests; full dependency-free suite is now 27 tests.

## v0.0.2 — 2026-08-18

### Added
- Persistent local Board posts via `PostStore`.
- Explicit Arcade game sessions via `SessionStore`.
- Start/end session lifecycle and duplicate-active-session protection.
- Completed-session reflection flow into Board posts.
- Session/resource lineage on game reflections.
- `GAME_SESSION_STARTED`, `GAME_SESSION_ENDED`, `GAME_REFLECTION_CREATED`, and `BOARD_POST_CREATED` event actions.
- Home `Continue` projection for active sessions.
- `docs/ACTIVITY_MODEL.md`.
- 7 new domain tests; full dependency-free suite is now 16 tests.

## v0.0.1 — 2026-08-18

### Added
- First AI Space Foundation Shell.
- Capability Registry with Home, Board, Arcade, Explore, and History.
- Framework-independent TypeScript registry, event, resource, and storage core.
- HTTP(S)-only external resource validation.
- localStorage event/resource persistence.
- Registry-driven navigation and custom lightweight hash routing.
- External game resources projected into Arcade.
- Local cross-capability activity history.
- Snapshot-first GitHub workflow documentation.
