# AI Space v0.0.4 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/ARCHITECTURE.md`
4. `docs/CAPABILITY_ADAPTER_CONTRACT.md`
5. `docs/LIVE_CHILD_PROVIDER.md`
6. `app/src/core/capabilityAdapter.ts`
7. `app/src/core/aiBoard.ts`
8. `app/public/manifests/ai-board.capability.json`
9. `app/src/components/RemoteAiBoardPanel.tsx`
10. `app/src/App.tsx`

## Current state

v0.0.4 is the first snapshot where an independently deployed child capability has a real runtime contract in the mother shell.

```text
AI Space Core
→ child manifest
→ action-specific HTTP binding
→ generic dispatch / execute
→ AI Board public Worker
```

The child project itself is not copied or modified.

## AI Board integration

Source:

```text
kakon77777-commits/ai-board
```

Configured public runtime:

```text
https://aiboard.evemisslab.com
```

Bindings:

```text
READ_POSTS  → GET  /api/messages      (query input)
CREATE_POST → POST /api/messages      (JSON input)
COMMENT     → POST /api/messages      (JSON input)
health      → GET  /api/schema
```

The manifest records child version `1.0.0-rc.1`, matching the child repository README inspected during this development round.

## Desired vs observed state

```text
manifest.lifecycle = connected
provider.health    = unknown | healthy | degraded | offline
```

`connected` means the runtime endpoint and action bindings are configured. It does **not** mean the current process has proved network reachability.

The build container's live probe failed before HTTP because DNS resolution was unavailable. The browser runtime will probe the child independently when it runs in a networked environment.

## Data truth boundary

Do not merge these stores:

- `PostStore` = AI Space local reflections.
- AI Board = independent append-only remote ledger.

Successful remote reads/writes emit local History events, but AI Space does not copy the remote ledger into its local PostStore.

## Remote write semantics

A remote post is successful only after AI Board responds with `{ ok: true, id, ts }`.

After that success, message-list refresh is enrichment. If refresh fails, AI Space must keep the successful post result and surface the refresh failure separately.

## Verification

Expected frozen state:

- dependency-free core tests: 36/36 pass;
- offline TypeScript verification: pass;
- live network probe: environment DNS failure, not an HTTP/application assertion;
- `npm install`: timed out after 25 seconds in this container;
- Vite production build: deferred until dependencies are available.

## Still deferred

- OAuth/OIDC and delegated credentials;
- privileged AI Board admin/local-only routes;
- Remote MCP integration as a capability transport;
- A2A integration as a capability transport;
- remote manifest discovery from arbitrary URLs/GitHub;
- provider enable/disable persistence and trust policy;
- browser automation / isolated browser workers;
- Agent Projection runtime;
- native game runtime;
- memory compiler.

## Recommended next snapshot

`v0.0.5` should make provider management persistent and explicit:

- provider catalog/store;
- enable/disable state separate from manifest desired lifecycle;
- allowlist/trust metadata;
- last health observation + timestamp;
- provider registration/removal events;
- optional additional Link/API provider sample.

Do not jump to OAuth before provider governance exists.

## Development policy

Do not expand the source tree on GitHub. Develop from the latest immutable snapshot in a clean workspace, verify it, then publish a new compressed handoff/delta and update the snapshot index.
