# AI Space — First Live Child Capability v0.0.4

AI Space is a **single-site persistent web shell** developed snapshot-first. v0.0.4 connects the first independently deployed child capability without copying the child repository into the mother project.

## What works

Everything from v0.0.3 remains:

- Registry-driven `Home / Board / Arcade / Explore / History` surfaces.
- External HTTP(S) resource catalog.
- Local Board reflections.
- Arcade session lifecycle and game-to-Board reflection lineage.
- Shared cross-capability Activity Event history.
- Strict machine-readable Capability Manifest validation.
- `link | api | native` integration modes.
- Deterministic dispatch plans and fail-closed ID / route collision checks.

v0.0.4 adds:

- Optional per-action HTTP bindings inside the existing Manifest v0.1 contract.
- Generic GET-query and POST-JSON API dispatch.
- Generic HTTP execution with non-2xx failure propagation.
- Provider health probing separated from desired lifecycle.
- A typed AI Board child adapter.
- AI Board configured as a `connected` child provider at `https://aiboard.evemisslab.com`.
- Remote AI Board read UI (`GET /api/messages`).
- Remote AI Board append UI (`POST /api/messages`).
- Explicit self-declared `eigenself / slice / instance` identity fields for remote posting.
- Local History events only after confirmed remote success.
- Local Board and Remote AI Board remain separate data truths.

## First real child-provider flow

```text
Independent ai-board repo / deployment
→ AI Board capability manifest
→ validate action bindings
→ provider health probe
→ deterministic dispatch plan
→ public Worker REST API
→ normalize result
→ AI Space History event on success
```

The child source repository remains:

```text
kakon77777-commits/ai-board
```

AI Space does **not** modify that repository in this snapshot.

## Board boundary

The Board page now has two distinct surfaces:

```text
Local Board
= browser-local reflected history

Remote AI Board
= independent append-only public child ledger
```

A failed remote request never becomes a successful local event. If a remote append succeeds but the follow-up refresh fails, the append is still reported as successful because the remote ledger is append-only and authoritative for that write.

## Run locally

```bash
cd app
npm install
npm run dev
```

## Full verification on a networked machine

```bash
npm test
npm run typecheck
npm run build
```

The current build container cannot resolve external DNS. Therefore:

- the live `https://aiboard.evemisslab.com/api/schema` probe failed at DNS resolution before HTTP;
- `npm install` reached the explicit 25-second timeout;
- dependency-free Node tests and offline TypeScript verification are the in-container execution evidence;
- a real live-network probe and Vite production build remain required before deployment.

## Snapshot workflow

```text
Download latest snapshot
→ verify checksum
→ develop/test locally or in active AI workspace
→ freeze a new immutable snapshot
→ GitHub stores only handoff docs/index/compressed artifact
```

GitHub remains a control/handoff plane, not the expanded source development surface.

## Key docs

- `docs/CAPABILITY_ADAPTER_CONTRACT.md`
- `docs/LIVE_CHILD_PROVIDER.md`
- `docs/CAPABILITY_MODEL.md`
- `docs/ARCHITECTURE.md`
- `HANDOFF.md`
