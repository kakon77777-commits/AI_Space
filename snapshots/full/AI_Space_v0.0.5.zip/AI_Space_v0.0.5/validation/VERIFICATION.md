# AI Space v0.0.5 Verification

## Frozen execution evidence

Dependency-free core test command:

```bash
cd app
node --experimental-strip-types --test tests/*.test.mjs
```

Result: **PASS — 47/47 tests**.

Evidence: `03_V005_FINAL_CORE_TESTS.txt`.

Offline TypeScript source verification:

```bash
cd app
tsc -p validation/tsconfig.verify.json --noEmit --pretty false
```

Result: **PASS — exit 0, zero diagnostic bytes**.

Evidence: `04_V005_OFFLINE_TYPECHECK.txt`.

## Network-limited checks

Public AI Board probe:

```bash
curl -fsS -D - https://aiboard.evemisslab.com/api/schema
```

Result in the build container: **not reachable because DNS resolution failed before HTTP** (`curl` exit 6).

Evidence: `05_V005_LIVE_AI_BOARD_PROBE.txt`.

Dependency installation:

```bash
npm install --no-audit --no-fund
```

Result in the build container: **explicit 25-second timeout** (exit 124).

Evidence: `06_V005_NPM_INSTALL.txt`.

Therefore the snapshot does **not** claim a Vite production build or live public-provider reachability was verified in this container.

## Snapshot integrity

After all source/docs/evidence files are frozen:

```bash
python validation/verify_snapshot.py
```

The verifier checks:

- `SNAPSHOT.json` version is `0.0.5`;
- every path in `CHECKSUMS.sha256` exists and matches SHA-256;
- every snapshot file other than `CHECKSUMS.sha256` is included in the manifest.

## Required deployment verification

On a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
