# AI Space — Capability Runtime Manager v0.0.5

AI Space is a **single-site persistent Web shell** developed snapshot-first. v0.0.5 turns the v0.0.3/v0.0.4 capability registry and adapter stack into an operational mother-runtime control plane.

## What works

Everything from v0.0.4 remains:

- Registry-driven `Home / Board / Arcade / Explore / History` surfaces.
- External HTTP(S) resource catalog.
- Local Board reflections.
- Arcade session lifecycle and game-to-Board reflection lineage.
- Shared cross-capability Activity Event history.
- Strict machine-readable `CapabilityManifest` validation.
- `link | api | native` integration modes.
- Deterministic dispatch plans and fail-closed ID / route collision checks.
- The AI Board child adapter using `GET/POST /api/messages` and `GET /api/schema`.
- Local Board and Remote AI Board remain separate data authorities.

v0.0.5 adds:

- `CapabilityRuntimeManager` as the mother operational control plane.
- Persistent per-provider runtime state using the existing `StorageAdapter`.
- Runtime `enabled` state separate from `manifest.lifecycle`.
- Health probe observations with timestamp, latency, health and last error.
- Side-effect-free deterministic dispatch preview.
- Managed API invocation through a single enable/disable gate.
- Success/failure runtime observations after invocation.
- A first-class `/capabilities` management surface.
- Shared `PROVIDER_PROBED / ENABLED / DISABLED / INVOKED / INVOKE_FAILED` history events.
- Remote AI Board reads/writes delegated through the runtime manager so the Board page cannot bypass a disabled child provider.

## Core model

```text
Desired state
CapabilityManifest
        |
        v
register provider
        |
        v
Capability Runtime Manager
  |       |       |
probe   toggle   preview
                  |
                  v
             managed invoke
                  |
                  v
Observed runtime state
+ Shared Event History
```

The important state split is:

```text
manifest.lifecycle
= desired/configuration state

runtime.enabled
= local operational gate

runtime.health / timestamps / latency / lastError
= observed runtime state
```

A health observation never silently rewrites the manifest.

## `/capabilities`

The management surface shows, per child provider:

- manifest version and lifecycle;
- source repository and runtime endpoint;
- enabled/disabled state;
- health;
- last probe time and latency;
- last invoke / last success;
- last error;
- available actions;
- deterministic Preview;
- managed Invoke.

`Preview` has no network side effect. `Invoke` is rejected before network access when a provider is disabled.

## AI Board boundary

The Board page still has two distinct data truths:

```text
Local Board
= browser-local reflection store

Remote AI Board
= independent append-only child ledger
```

The remote surface now uses:

```text
Board UI
→ CapabilityRuntimeManager.invoke('child:ai-board', ...)
→ AI Board REST adapter
```

So provider governance is real rather than decorative.

## Run locally

```bash
cd app
npm install
npm run dev
```

## Verification

Dependency-free core verification:

```bash
cd app
node --experimental-strip-types --test tests/*.test.mjs
```

Offline source typecheck uses the snapshot validation TypeScript config:

```bash
tsc -p validation/tsconfig.verify.json --noEmit --pretty false
```

On a normal networked machine, also run:

```bash
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```

The build container used for this round could not resolve the public AI Board hostname and the explicit `npm install` attempt timed out, so production-network reachability and the Vite production build are not claimed as verified in that container.

## Snapshot workflow

```text
Download latest reconstructible snapshot
→ verify checksums
→ develop/test locally or in active AI workspace
→ freeze a new immutable FULL snapshot
→ GitHub stores only compact verified handoff/deltas + index
```

GitHub remains a control/handoff plane, not the expanded source development surface.

## Key docs

- `docs/CAPABILITY_RUNTIME_MANAGER.md`
- `docs/CAPABILITY_ADAPTER_CONTRACT.md`
- `docs/LIVE_CHILD_PROVIDER.md`
- `docs/CAPABILITY_MODEL.md`
- `docs/ARCHITECTURE.md`
- `HANDOFF.md`
