import test from 'node:test'
import assert from 'node:assert/strict'
import { getPageModel } from '../src/core/shell.ts'

const capabilities = [
  { id: 'home', label: 'Home', description: 'Home page', route: '/', mode: 'native', status: 'ready', actions: [] },
  { id: 'board', label: 'Board', description: 'Board page', route: '/board', mode: 'native', status: 'placeholder', actions: [] },
  { id: 'capabilities', label: 'Capabilities', description: 'Runtime manager', route: '/capabilities', mode: 'native', status: 'ready', actions: [] },
]

test('getPageModel resolves known capabilities', () => {
  assert.deepEqual(getPageModel(capabilities, '/board'), {
    kind: 'capability',
    capabilityId: 'board',
    title: 'Board',
  })
})

test('getPageModel returns not-found for unknown routes', () => {
  assert.deepEqual(getPageModel(capabilities, '/nope'), {
    kind: 'not-found',
    title: 'Not Found',
  })
})

test('getPageModel resolves the capability runtime manager route', () => {
  assert.deepEqual(getPageModel(capabilities, '/capabilities'), { kind: 'capability', capabilityId: 'capabilities', title: 'Capabilities' })
})
