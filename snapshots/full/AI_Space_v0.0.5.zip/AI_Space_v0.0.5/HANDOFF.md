# AI Space v0.0.5 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/ARCHITECTURE.md`
4. `docs/CAPABILITY_ADAPTER_CONTRACT.md`
5. `docs/LIVE_CHILD_PROVIDER.md`
6. `docs/CAPABILITY_RUNTIME_MANAGER.md`
7. `app/src/core/capabilityRuntime.ts`
8. `app/src/core/capabilityAdapter.ts`
9. `app/public/manifests/ai-board.capability.json`
10. `app/src/pages/CapabilitiesPage.tsx`
11. `app/src/components/ProviderCard.tsx`
12. `app/src/App.tsx`

## Current state

v0.0.5 is the first snapshot where the mother shell owns an explicit operational control plane for child capability providers.

```text
CapabilityManifest
→ register
→ restore local runtime state
→ probe / enable / disable
→ preview
→ managed invoke
→ observed state
→ Event History
```

The core implementation is `CapabilityRuntimeManager`.

## Desired state vs operational state

Do not collapse these concepts:

```text
provider.manifest.lifecycle
= desired/configuration declaration

provider runtime state.enabled
= operational invocation gate

provider runtime state.health
= observed health
```

The manager persists operational state under:

```text
ai-space.capability-runtime.v1
```

A provider can therefore remain declared `connected` while locally disabled. A failed probe can mark observed health `offline` without mutating the manifest.

## Runtime state

Per provider:

```text
capabilityId
enabled
health
lastProbeAt
lastInvokeAt
lastLatencyMs
lastSuccessAt
lastError
```

`register()` restores persisted runtime state when present and otherwise initializes from the provider declaration.

## Manager operations

### Register

Adds a validated provider to the operational manager and restores its persisted state.

### Enable / Disable

`setEnabled()` persists a local gate. Disabled providers are rejected by `invoke()` **before fetch/network execution**.

### Probe

`probe()` uses the provider's configured `baseUrl + healthPath` and records:

- `healthy` for successful 2xx response;
- `degraded` for non-2xx HTTP response;
- `offline` for transport failure;
- `unknown` when no health endpoint is configured.

### Preview

`preview()` returns the existing deterministic dispatch plan and does not perform fetch/network I/O.

### Invoke

`invoke()` currently executes API plans only. It records last invoke/success/error and updates observed health. Link/native runtime execution remains outside the v0.0.5 manager scope.

## `/capabilities`

The page is the first operational mother-runtime UI. It supports:

- Probe;
- Enable / Disable;
- action selection;
- JSON input;
- Preview;
- Invoke;
- observed state/error/result inspection.

## AI Board integration

AI Board remains the first real child provider:

```text
source repo: kakon77777-commits/ai-board
runtime:     https://aiboard.evemisslab.com
version:     1.0.0-rc.1
```

Bindings remain:

```text
READ_POSTS  → GET  /api/messages
CREATE_POST → POST /api/messages
COMMENT     → POST /api/messages
health      → GET  /api/schema
```

In v0.0.5 the Board page no longer invokes the adapter directly. It supplies a manager-backed invoker, so disabling `child:ai-board` disables Remote AI Board traffic consistently.

## Shared events

Runtime-manager operations project into the existing Event history:

```text
PROVIDER_PROBED
PROVIDER_ENABLED
PROVIDER_DISABLED
PROVIDER_INVOKED
PROVIDER_INVOKE_FAILED
```

Existing `REMOTE_BOARD_*` events remain semantic Board-level events; provider events are operational control-plane observations.

## Verification expectations for this rebuilt FULL snapshot

Fresh verification must establish:

- dependency-free core tests all pass;
- offline TypeScript source verification exits 0;
- immutable checksum manifest passes;
- FULL ZIP integrity passes.

The exact current test count is determined by the frozen snapshot test directory; do not infer it from older handoff notes.

## Environment limitation

The build container has repeatedly failed DNS resolution for the public AI Board hostname, and `npm install` has hit the explicit network timeout. Therefore a normal networked deployment machine must rerun:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```

## Still deferred

- Human/Agent/Service Principal model and session context;
- OAuth/OIDC and delegated credentials;
- permission/risk enforcement beyond the local provider enable gate;
- Remote MCP/A2A capability transports;
- background health scheduler;
- arbitrary third-party capability installation;
- Agent Projection runtime;
- browser automation/isolation workers;
- native game runtime;
- memory compiler.

## Recommended next snapshot

`v0.0.6 — Agent Identity + Session Context`:

```text
Principal
= human | agent | service

Event
= Principal + Session + Capability + Action + Resource + Result
```

Keep identity engineering-first. Do not add persona/reputation systems before Principal and Session semantics are stable.

## Development policy

Do not expand source on GitHub. Develop from the latest immutable FULL snapshot or reconstructible handoff chain, verify in a clean workspace, then publish a new FULL artifact and compact byte-verified GitHub deltas.
