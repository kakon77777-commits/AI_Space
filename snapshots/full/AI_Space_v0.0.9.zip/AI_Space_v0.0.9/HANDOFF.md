# AI Space v0.0.9 Handoff

## Current state

v0.0.9 is the first AI Space snapshot where Space is an authoritative runtime object instead of a free-form Projection/Event label.

```text
Principal
→ Space membership / Projection binding
→ Space presence
→ Capability / Resource action
→ global Event lineage
→ Space-local projection
```

## Important invariants

1. Space owner is always a non-Projection Principal.
2. `private` Space is owner-only; `shared` Space allows registered local root members.
3. Projection membership is never duplicated into membership rows; Root membership + Projection binding is the authority.
4. One Principal has at most one active Space presence.
5. Projection Enter creates presence; Return/Suspend/Archive clears it.
6. New Projection binding requires an existing active Space and Root membership.
7. `SpaceResourceRef` never copies the Resource body.
8. Space history never creates a second event ledger.
9. Managed Projection child invoke and tracked Browser Session require active bound-Space presence in addition to Projection permission.
10. `shared` has no remote/federated meaning in v0.0.9.

## Stores

- `ai-space.spaces.v1`
- `ai-space.space-memberships.v1`
- `ai-space.space-presences.v1`
- `ai-space.space-resource-refs.v1`

## Next likely step

`v0.1.0 — First Coherent AI Space MVP`: consolidate the current Principal → ContextSession → Projection → Space → Capability → Experience → Reflection loop into one acceptance/demo flow before adding more horizontal product surfaces.

Do not jump directly to public federation, realtime collaboration, or autonomous browser control before the v0.1.0 coherence gate.

## Deployment gate

On a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
