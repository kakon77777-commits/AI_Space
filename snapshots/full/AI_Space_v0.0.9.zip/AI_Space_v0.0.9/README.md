# AI Space v0.0.9 — Shared Space Context

AI Space is developed snapshot-first: source is implemented and verified in the active workspace, delivered as an immutable FULL ZIP, and handed to GitHub only as compact byte-verified deltas.

v0.0.9 promotes `spaceId` from a lineage string into a persistent Mother Runtime object:

```text
Root Principal membership
→ Space
→ active Principal / Projection presence
→ Capability / Resource interaction
→ global ActivityEvent with Space lineage
→ Space-local history projection
```

## New in v0.0.9

- persistent `SpaceStore` with `active | archived` lifecycle.
- `private | shared` local visibility semantics.
- stable built-ins: `research`, `arcade`, `board`, `library`.
- owner/member governance for root Principals.
- one active Space presence per Principal.
- Projection presence inherited from Root membership + Projection binding.
- owner archive clears active presences.
- `SpaceResourceRef` links to canonical `ResourceStore` objects without copying them.
- Space history is filtered from the global Activity Event Store.
- `/spaces` native management surface.
- new Projection creation selects only eligible active member Spaces.
- Projection Enter/Return/Suspend/Archive updates Space presence.
- tracked Browser Session and managed child invoke require Projection Space presence.
- Shell sidebar shows active Space context.

## Boundary statement

`shared` means shared among registered **local** root Principals in this browser-local runtime. It does not mean public, federated, remotely synchronized, cryptographically authenticated, or realtime multi-user.

Space does not become a second truth store:

```text
Space resource = ResourceRef -> ResourceStore
Space history  = filter(ActivityEvent, spaceId)
```

See `docs/SHARED_SPACE_CONTEXT.md`.

## Run on a normal networked machine

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
```

The build container used for this snapshot is also probed for live AI Board reachability and npm availability. Any unavailable checks are recorded explicitly rather than inferred as successful.
