# AI Space v0.0.9 Verification

## Frozen execution evidence

Dependency-free core tests: **PASS — 96/96**.

Offline TypeScript source verification: **PASS — exit 0, zero diagnostics**.

Evidence:
- `v0.0.9-final-core.log`
- `v0.0.9-final-typecheck.log`

## TDD evidence

- `v0.0.9_spaces_red1.txt` (round-level external evidence): `spaces.ts` missing while the v0.0.8 baseline remained green.
- `v0.0.9_spaces_red2.txt`: presence/resource/history exports absent before implementation.
- `v0.0.9_member_presence_red.txt`: membership removal initially left stale presence; regression test forced the invariant.
- `v0.0.9_spaces_route_red.txt`: shipped `/spaces` route absent before capability registration.
- final core evidence: 96/96 after Space Runtime + UI integration.

The larger RED transcripts are kept outside the immutable snapshot to avoid bloating the canonical package; this file records their role and the final snapshot contains the resulting tests.

## Network-limited checks

- `v0.0.9-live-probe.log` + `.exit`: public AI Board DNS resolution unavailable (`curl` exit 6).
- `v0.0.9-npm-install.log` + `.exit`: explicit 25-second npm install timeout (`exit 124`).

Therefore this snapshot does not claim production-network reachability, network-installed Vitest, or a Vite production build in this container.

## Shared Space semantic boundary

- `shared` means registered local root Principals only.
- no remote federation or realtime synchronization.
- Space history is a view of global Activity Events.
- Space resources are references to canonical ResourceStore objects.

## Snapshot integrity

`CHECKSUMS.sha256` is generated after this file and `SNAPSHOT.json` are finalized. `python validation/verify_snapshot.py` must pass before packaging.
