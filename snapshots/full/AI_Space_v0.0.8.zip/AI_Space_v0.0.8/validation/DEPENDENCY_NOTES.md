# Dependency / Network Notes

The build container cannot currently resolve external DNS. This affects both npm registry access and direct probing of `https://aiboard.evemisslab.com`.

This limitation is separated from application correctness:

- dependency-free Node tests exercise the Capability Adapter and AI Board transport using injected fake HTTP responses;
- offline TypeScript verification checks the React/TypeScript source with the repository shim;
- live endpoint reachability and the production Vite build remain deployment-environment verification items.
