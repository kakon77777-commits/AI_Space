# AI Space v0.0.8 Handoff

## Current state

v0.0.8 is the first AI Space snapshot with a Projection-scoped tracked external browser boundary.

Core lineage:

```text
Principal
→ Projection
→ Space
→ BrowserSession
→ ExperienceRecord
→ ReflectionCandidate
```

## Important invariants

1. A tracked Browser Session requires an active Projection Principal.
2. The Projection must allow `arcade:START_BROWSER_SESSION`.
3. `trust=untrusted-external` is literal.
4. `isolation=noopener-noreferrer-only` is literal; do not describe it as a sandbox.
5. Completion requires an explicit summary; AI Space does not infer external browser state.
6. Popup-blocked launch is abandoned.
7. Experience Reflection promotion is optional and local; no automatic Merge/Reintegration.
8. Existing GameSession data remains backward compatible.

## Next likely step

The next major runtime step should add either a real Browser Agent adapter or Shared Space Context, but only after a concrete browser-control/isolation provider is selected. Do not silently reinterpret v0.0.8 as having browser automation.

## Deployment gate

On a normal networked machine run:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
