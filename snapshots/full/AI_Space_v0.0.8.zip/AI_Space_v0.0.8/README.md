# AI Space v0.0.8 — AI Arcade + Browser Session Boundary

AI Space is developed snapshot-first: source is implemented and verified in the active workspace, delivered as an immutable FULL ZIP, and handed to GitHub only as compact verified deltas.

v0.0.8 turns an external Arcade link into a first-class Projection-scoped experience boundary:

```text
Root Principal
→ Projection Principal
→ Arcade Space
→ tracked external Browser Session
→ explicit Complete / Abandon
→ Experience Record
→ pending Reflection Candidate
→ optional local Board reflection
```

## New in v0.0.8

- `BrowserSessionStore` persistence.
- active/completed/abandoned Browser Session lifecycle.
- `arcade:START_BROWSER_SESSION` Projection permission gate before browser I/O.
- explicit browser trust metadata: `untrusted-external`.
- explicit isolation claim: `noopener-noreferrer-only`.
- popup-blocked launch becomes abandoned, never falsely successful.
- explicit Experience Records and reviewable Reflection Candidates.
- Projection/root/Space/context/resource event lineage.
- Arcade UI retains legacy GameSession history while adding tracked external sessions.

## Security statement

Tracked does **not** mean observed. AI Space v0.0.8 opens an external tab with `noopener,noreferrer`, records the boundary, and requires an explicit completion summary. It does not claim sandboxed browser isolation, DOM observation, autonomous browsing, credential isolation, or prompt-injection immunity.

See `docs/BROWSER_SESSION_BOUNDARY.md`.

## Run on a normal networked machine

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
```

The build container used for this snapshot could not resolve the public AI Board hostname and the networked npm install hit the explicit timeout, so production reachability and Vite production build are not claimed as verified there.
