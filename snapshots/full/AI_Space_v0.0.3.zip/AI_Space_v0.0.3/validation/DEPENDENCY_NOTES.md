# Dependency Notes — 2026-08-19

Package lines carried forward from the v0.0.2 snapshot:

- React `19.2.8`
- React DOM `19.2.8`
- Vite `8.2.0`
- `@vitejs/plugin-react` `6.0.5`
- Vitest `4.1.10`
- TypeScript package target `7.0.2`

The execution container has Node `22.16.0` and global TypeScript `5.8.3`. `npm install --no-audit --no-fund` was attempted on 2026-08-19 with a 25-second timeout and did not complete (`exit 124`). No partial `node_modules` or lockfile is included.

Core tests use Node TypeScript strip mode. Offline source checking uses an explicit temporary React type shim outside the snapshot. A real networked `npm install && npm test && npm run typecheck && npm run build` remains required before deployment.
