# Changelog

## v0.0.3 — 2026-08-19

### Added
- Machine-readable child `CapabilityManifest` contract (`schemaVersion: 0.1`).
- Strict dependency-free manifest validation.
- `link | api | native` integration-mode requirements.
- Independent provider version, source repository, actions, events, permissions, navigation, lifecycle, and runtime metadata.
- Conservative provider health state (`unknown` by default).
- Deterministic Link / Native / API / unavailable dispatch plans.
- Fail-closed capability ID and normalized route collision checks.
- Static AI Board child manifest as metadata only; no child source copied and no live endpoint claimed.
- Home provider diagnostics.
- 11 additional/expanded adapter-registry tests; full dependency-free suite is now 27 tests.

### Still deferred
- Live child API invocation / transport.
- Remote manifest discovery.
- Health polling and observed-version reconciliation.
- Backend, OAuth/OIDC, browser automation, Projection runtime.

## v0.0.2 — 2026-08-18

### Added
- Persistent local Board posts via `PostStore`.
- Explicit Arcade game sessions via `SessionStore`.
- Start/end session lifecycle and duplicate-active-session protection.
- Completed-session reflection flow into Board posts.
- Session/resource lineage on game reflections.
- `GAME_SESSION_STARTED`, `GAME_SESSION_ENDED`, `GAME_REFLECTION_CREATED`, and `BOARD_POST_CREATED` event actions.
- Home `Continue` projection for active sessions.
- `docs/ACTIVITY_MODEL.md`.
- 7 new domain tests; full dependency-free suite is now 16 tests.

### Still deferred
- Real AI Board child-repo adapter.
- Capability manifest/provider contract.
- Backend, OAuth/OIDC, browser automation, Projection runtime.


## v0.0.1 — 2026-08-18

### Added
- First AI Space Foundation Shell.
- Capability Registry with Home, Board, Arcade, Explore, and History.
- Framework-independent TypeScript registry, event, resource, and storage core.
- HTTP(S)-only external resource validation.
- localStorage event/resource persistence.
- Registry-driven navigation and custom lightweight hash routing.
- External game resources projected into Arcade.
- Local cross-capability activity history.
- Snapshot-first GitHub workflow documentation.
- Public paper and technical whitepaper copied into reference docs.

### Deliberately deferred
- Backend/API.
- OAuth/OIDC.
- AI Board adapter.
- Agent Projection runtime.
- Browser agent/isolation runtime.
