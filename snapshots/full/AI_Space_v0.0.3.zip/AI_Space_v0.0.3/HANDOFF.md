# AI Space v0.0.3 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/ARCHITECTURE.md`
4. `docs/CAPABILITY_ADAPTER_CONTRACT.md`
5. `docs/CAPABILITY_MODEL.md`
6. `docs/ACTIVITY_MODEL.md`
7. `app/src/core/capabilityAdapter.ts`
8. `app/public/manifests/ai-board.capability.json`
9. `app/src/App.tsx`

## Current state

The project remains browser-only and backend-free. v0.0.3 introduces a stable child capability contract while preserving all v0.0.2 activity features.

The first cross-repository handoff model is now represented as:

```text
Independent Child Project
→ machine-readable manifest
→ strict validation
→ provider record
→ deterministic dispatch plan
→ shell diagnostics
```

## What the AI Board manifest means

`app/public/manifests/ai-board.capability.json` is **metadata only**.

It declares:

- child project ID;
- independent version string;
- API integration mode;
- declared actions/events/permissions;
- source repository ownership.

It deliberately does not declare a live `runtime.baseUrl`, so its lifecycle is `declared`, provider health is `unknown`, and API dispatch returns an explicit unavailable plan.

The existing local Board surface remains active.

## Important boundaries

Not implemented yet:

- live AI Board API adapter;
- remote child manifest discovery from GitHub/network URLs;
- live health/version polling;
- backend API/database;
- OAuth/OIDC and external Agent identity;
- browser automation / isolated browser workers;
- Agent Projection runtime;
- native game runtime;
- memory compiler.

## Recommended next snapshot

`v0.0.4` should implement a **real child-provider adapter boundary** without adding OAuth yet:

- generic provider catalog/store;
- ability to enable/disable validated manifests;
- one connected local/mock API provider using an injected transport;
- provider health observation separated from desired manifest state;
- events for provider registration / availability transitions.

Acceptance: the same manifest contract drives both a declared provider and a connected test provider without changing the shell or core capability model.

## Development policy

Do not expand the source tree on GitHub. Develop from the latest immutable snapshot in a clean workspace, verify it, then publish a new handoff archive and update the snapshot index.
