# Capability Adapter Contract — v0.0.3

## Purpose

A child project must be independently versionable while AI Space can understand what it provides without reading or copying the child source tree.

The contract is:

```text
Manifest → Validate → Provider → Dispatch Plan
```

## Manifest v0.1

```ts
interface CapabilityManifest {
  schemaVersion: '0.1'
  id: string
  name: string
  description: string
  version: string
  mode: 'link' | 'api' | 'native'
  lifecycle: 'declared' | 'connected'
  actions: string[]
  events: string[]
  permissions: string[]
  source: { repository: string }
  navigation?: { visible: boolean; order: number }
  route?: string
  externalUrl?: string
  runtime?: { baseUrl?: string; healthPath?: string }
}
```

## Mode rules

### Link

Requires HTTP(S) `externalUrl`.

Dispatch returns an external URL plan.

### Native

Requires `route` beginning with `/`.

Dispatch returns a native route plan.

### API

A provider may be `declared` without `runtime.baseUrl`.

In that state, dispatch returns:

```text
kind: unavailable
reason: API capability is declared but has no runtime baseUrl
```

A `connected` API manifest must provide an HTTP(S) `runtime.baseUrl`.

## Authority

The manifest is **desired declaration**. Runtime health is **observed state**.

They must not be collapsed into one field.

```text
manifest.lifecycle = declared | connected
provider.health    = unknown | healthy | degraded | offline
```

v0.0.3 does not poll health, so child providers default to `unknown`.

## Collision policy

Core IDs/routes cannot be shadowed by child providers.

```text
Duplicate ID    → reject
Normalized route collision → reject
```

This keeps the mother registry authoritative.

## Dispatch is deterministic

The dispatcher validates that an action was declared in the manifest before building a plan. LLM output cannot bypass this contract.

## AI Board example

`app/public/manifests/ai-board.capability.json` demonstrates an independent child project declaration. It intentionally has no live API base URL in this snapshot.
