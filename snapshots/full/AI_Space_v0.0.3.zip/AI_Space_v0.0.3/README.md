# AI Space — Capability Adapter Contract v0.0.3

AI Space is a **single-site persistent web shell** developed snapshot-first. v0.0.3 adds the first real boundary between the mother site and independently versioned child projects: a machine-readable **Capability Adapter Contract**.

## What works

Everything from v0.0.2 still works:

- Registry-driven `Home / Board / Arcade / Explore / History` surfaces.
- External HTTP(S) resource catalog.
- Local Board reflections.
- Arcade session lifecycle and game-to-Board reflection lineage.
- Shared cross-capability Activity Event history.

v0.0.3 adds:

- `CapabilityManifest` schema version `0.1` implemented as a strict dependency-free validator.
- Child integration modes: `link | api | native`.
- Independent child version/source/action/event/permission metadata.
- Provider runtime state with conservative default health `unknown`.
- Deterministic dispatch planning for Link, Native, connected API, and declared-but-unconfigured API providers.
- Fail-closed capability ID and route collision detection.
- Static machine-readable `AI Board` child manifest as metadata only.
- Home diagnostics for discovered child providers.

## Important boundary

The AI Board child manifest declares an independent repository and contract. It does **not** copy AI Board source, call a live API, or replace the local Board surface in v0.0.3.

```text
Child Repo / Manifest
→ Validate
→ Provider Record
→ Dispatch Contract
→ AI Space Discovery
```

## Architecture

```text
React Shell
  ↓
Core Capability Registry ───────────────┐
  ↓                                    │
Local Domain Core                      │
  ├─ ResourceStore                     │
  ├─ EventStore                        │
  ├─ PostStore                         │
  └─ SessionStore                      │
                                       │
Child Manifest                         │
  ↓                                    │
Capability Adapter Validator           │
  ↓                                    │
Provider / Dispatch Plan ──────────────┘
```

Core capabilities remain desired-state authority. Discovered child providers cannot silently shadow a core capability or normalized route.

## Run locally

```bash
cd app
npm install
npm run dev
```

## Full verification on a networked machine

```bash
npm test
npm run typecheck
npm run build
```

The current build container again could not complete `npm install`; the command reached the explicit 25-second timeout. Dependency-free Node core tests and an offline TypeScript source check were run successfully. A real dependency install and Vite production build remain required before deployment.

## Snapshot workflow

```text
Download latest snapshot
→ verify checksum
→ develop/test locally or in active AI workspace
→ freeze a new immutable snapshot
→ GitHub stores only handoff docs/index/archive
```

GitHub remains a control/handoff plane, not the expanded source development surface.

## Key docs

- `docs/CAPABILITY_ADAPTER_CONTRACT.md`
- `docs/CAPABILITY_MODEL.md`
- `docs/ARCHITECTURE.md`
- `HANDOFF.md`
