# AI Space — Projection Runtime v0.0.7

AI Space is a **single-site persistent Web runtime** developed snapshot-first. v0.0.7 adds bounded Projection Principals on top of v0.0.6 Principal + ContextSession semantics.

## What works

Everything from v0.0.6 remains, including:

- Registry-driven Home / Board / Arcade / Explore / History / Agents / Capabilities surfaces.
- Local Board reflections and Arcade domain-session lineage.
- Shared Activity Event history.
- CapabilityManifest + Capability Runtime Manager.
- Remote AI Board REST child adapter behind the managed invoke gate.
- `human | agent | service` root Principals.
- Cross-capability ContextSessions and active-Principal Arcade isolation.

v0.0.7 adds:

- `projection` as a first-class engineering Principal type.
- `ProjectionStore` with explicit `rootPrincipalId`, `principalId`, `spaceId`, role and lifecycle.
- `/projections` native management surface.
- Permission scopes such as `child:ai-board:LIST_MESSAGES`, `child:ai-board:*`, and `*:*`.
- Permission denial **before managed child-provider transport executes**.
- Declared `memoryScope` metadata without automatic raw-memory copying.
- `active -> suspended -> active` and `active|suspended -> archived` lifecycle; archive is terminal.
- Projection checkpoints and pending merge candidates.
- Projection/root/Space lineage on Activity Events.
- Enter Projection / Return to Root active-Principal transitions.
- Projection Principals can only be created through Projection Runtime; direct generic creation is rejected.

## Core model

```text
Root Principal
→ Projection record
→ Projection Principal
→ Space
→ scoped memory declaration
→ scoped managed-child permissions
→ ContextSession / Capability / Action
→ Event lineage
```

Projection is not Clone:

```text
Projection(A, S) = A^S
A^S != A
Lineage(A^S) = A
```

`spaceId` is a bounded context label in v0.0.7, not yet the full Shared Space entity planned for a later snapshot.

## Permission boundary

Projection permissions are enforced for **managed child-provider invocation**:

```text
projection permission check
→ Capability Runtime Manager
→ transport
```

Denied invocations never reach transport.

v0.0.7 does **not** yet implement a general RBAC engine for every local-native UI action. Provider probe/toggle and local-native action governance remain later work.

## Memory boundary

`memoryScope: string[]` records which memory categories/summaries are intentionally in scope for the Projection.

It does not:

- copy Root raw memory;
- mutate Root memory;
- run a Memory Compiler;
- perform Reintegration.

## Checkpoint and Merge Candidate

Projection checkpoints store portable summaries. A merge candidate is only:

```text
status = pending
```

No automatic Merge/Reintegration occurs in v0.0.7, even when `mergePolicy` is declared `automatic`; the field is future policy metadata only in this snapshot.

## Run locally

```bash
cd app
npm install
npm run dev
```

Dependency-free verification:

```bash
npm run test:core:offline
```

Offline source typecheck:

```bash
tsc -p validation/tsconfig.verify.json --noEmit --pretty false
```

Before deployment on a normal networked machine also run:

```bash
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```

## Snapshot workflow

```text
latest reconstructible snapshot
→ local / active AI workspace
→ TDD RED/GREEN
→ offline typecheck
→ immutable FULL snapshot
→ clean-extract re-verification
→ compact byte-verified GitHub deltas
```

GitHub remains a control/handoff plane, not the expanded source development surface.

## Key docs

- `docs/PROJECTION_RUNTIME.md`
- `docs/AGENT_IDENTITY_SESSION_CONTEXT.md`
- `docs/CAPABILITY_RUNTIME_MANAGER.md`
- `docs/CAPABILITY_ADAPTER_CONTRACT.md`
- `HANDOFF.md`
