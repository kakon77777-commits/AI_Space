
export type PrincipalType = 'human' | 'agent' | 'service' | 'projection'

export interface Principal {
  id: string
  type: PrincipalType
  displayName: string
  ownerId?: string
  provider?: string
  modelFamily?: string
  instanceId?: string
  createdAt: string
  updatedAt: string
}




export type ProjectionStatus = 'active' | 'suspended' | 'archived'
export type ProjectionMergePolicy = 'reviewed' | 'automatic' | 'none'

export interface Projection {
  id: string
  principalId: string
  rootPrincipalId: string
  spaceId: string
  role?: string
  status: ProjectionStatus
  permissionScope: string[]
  memoryScope: string[]
  mergePolicy: ProjectionMergePolicy
  createdAt: string
  updatedAt: string
  suspendedAt?: string
  archivedAt?: string
}

export interface ProjectionCheckpoint {
  id: string
  projectionId: string
  summary: string
  createdAt: string
}

export interface ProjectionMergeCandidate {
  id: string
  projectionId: string
  checkpointId?: string
  status: 'pending'
  createdAt: string
}

export type ContextSessionStatus = 'active' | 'closed'

export interface ContextSession {
  id: string
  principalId: string
  label: string
  status: ContextSessionStatus
  startedAt: string
  endedAt?: string
}

export type CapabilityMode = 'native' | 'api' | 'link'
export type CapabilityStatus = 'ready' | 'placeholder'

export interface CapabilityNavigation {
  visible: boolean
  order: number
}

export interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: CapabilityMode
  status: CapabilityStatus
  actions: string[]
  navigation?: CapabilityNavigation
}

export type ResourceType = 'game' | 'website' | 'research' | 'tool' | 'media'

export interface ExternalResource {
  id: string
  title: string
  type: ResourceType
  url: string
  createdAt: string
}

export interface ActivityEvent {
  id: string
  timestamp: string
  principalId: string
  contextSessionId?: string
  projectionId?: string
  rootPrincipalId?: string
  spaceId?: string
  action: string
  capabilityId?: string
  resourceId?: string
  sessionId?: string
  summary: string
}


export interface BoardPost {
  id: string
  principalId: string
  title: string
  body: string
  createdAt: string
  contextSessionId?: string
  sourceSessionId?: string
  sourceResourceId?: string
}

export type GameSessionStatus = 'active' | 'completed'

export interface GameSession {
  id: string
  principalId: string
  resourceId: string
  contextSessionId?: string
  status: GameSessionStatus
  startedAt: string
  endedAt?: string
  reflectionPostId?: string
}

export type CapabilityLifecycle = 'declared' | 'connected'
export type CapabilityHealth = 'unknown' | 'healthy' | 'degraded' | 'offline'

export interface CapabilityManifestNavigation {
  visible: boolean
  order: number
}

export interface CapabilityManifestSource {
  repository: string
}

export type CapabilityHttpMethod = 'GET' | 'POST'
export type CapabilityActionInputMode = 'query' | 'json' | 'none'

export interface CapabilityActionBinding {
  method: CapabilityHttpMethod
  path: string
  input: CapabilityActionInputMode
}

export interface CapabilityManifestRuntime {
  baseUrl?: string
  healthPath?: string
  actions?: Record<string, CapabilityActionBinding>
}

export interface CapabilityManifest {
  schemaVersion: '0.1'
  id: string
  name: string
  description: string
  version: string
  mode: CapabilityMode
  lifecycle: CapabilityLifecycle
  actions: string[]
  events: string[]
  permissions: string[]
  source: CapabilityManifestSource
  navigation?: CapabilityManifestNavigation
  route?: string
  externalUrl?: string
  runtime?: CapabilityManifestRuntime
}

export interface CapabilityProvider {
  manifest: CapabilityManifest
  health: CapabilityHealth
  observedVersion?: string
}

export interface CapabilityRuntimeState {
  capabilityId: string
  enabled: boolean
  health: CapabilityHealth
  lastProbeAt?: string
  lastInvokeAt?: string
  lastLatencyMs?: number
  lastSuccessAt?: string
  lastError?: string
}

export interface CapabilityRuntimeSnapshot {
  provider: CapabilityProvider
  state: CapabilityRuntimeState
}

export type CapabilityDispatchPlan =
  | { kind: 'link'; capabilityId: string; action: string; url: string }
  | { kind: 'native'; capabilityId: string; action: string; route: string }
  | { kind: 'api'; capabilityId: string; action: string; url: string; method: CapabilityHttpMethod; body?: unknown }
  | { kind: 'unavailable'; capabilityId: string; action: string; reason: string }
