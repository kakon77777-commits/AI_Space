# Changelog

## v0.0.7 — 2026-08-20

### Added
- `projection` first-class Principal type.
- `ProjectionStore` with explicit Root Principal, Projection Principal, Space, role, scopes and lifecycle.
- `/projections` Projection Runtime management surface.
- Managed-child permission grammar: exact action, capability wildcard, global wildcard.
- Pre-transport Projection permission gate.
- Declarative Projection memory scope.
- Projection activity lineage: `projectionId`, `rootPrincipalId`, `spaceId`.
- Projection checkpoints and pending merge candidates.
- Enter Projection / Return to Root transitions.
- Suspend / resume / terminal archive lifecycle.
- Direct generic creation of Projection Principals is rejected.
- v0.0.7 design/spec/implementation documents.

### Behavioral guarantees
- Projection Root must exist and cannot itself be a Projection in v0.0.7.
- Suspended or archived Projections cannot pass managed-child permission checks.
- Denied managed child invocation fails before transport executes.
- Agents surface cannot bypass Projection lifecycle activation.
- Checkpoint / merge-candidate creation never mutates Root state.
- `memoryScope` never implies automatic raw-memory copying.

### Still deferred
- automatic Merge/Reintegration and rollback.
- general local-native RBAC / policy-risk engine.
- Memory Compiler / Root memory mutation.
- Projection nesting.
- Browser isolation / browser agent runtime.

## v0.0.6 — 2026-08-20

### Added
- `PrincipalStore` for `human | agent | service` engineering identities.
- Backward-compatible `agent:local-demo` Principal seed.
- Persisted active-Principal selection.
- `ContextSessionStore` with one active context per Principal.
- `/agents` Principal and ContextSession management surface.
- Dynamic active Principal / ContextSession shell indicator.
- `ActivityEvent.contextSessionId` while preserving existing domain `sessionId` semantics.
- Context lineage on local Board posts and Arcade GameSessions.
- Active-Principal filtering for Arcade domain sessions.
- Central context-aware App event append path.
- v0.0.6 design/spec/implementation docs.

### Behavioral guarantees
- Principal switching does not rewrite old history.
- Different Principals can retain independent active ContextSessions.
- One Principal cannot have two active ContextSessions at once.
- Game session lineage keeps both Principal and the ContextSession active when play began.
- Game reflection lineage follows the originating GameSession, not the later active Principal.
- Remote AI Board identity remains separate from AI Space Principal identity.

### Verification environment
- Dependency-free Node tests and offline TypeScript verification are executable in-container evidence.
- Public AI Board live probe remained blocked at DNS resolution.
- `npm install --no-audit --no-fund` reached the explicit 25-second timeout.
- Network-installed Vitest and Vite production build remain required before deployment.

### Still deferred
- Projection Runtime.
- Principal-scoped permissions / RBAC.
- OAuth/OIDC and delegated credentials.
- Remote AI Board identity bridge.
- public Agent registration/federation.

## v0.0.5 — 2026-08-19

### Added
- `CapabilityRuntimeManager` operational control plane.
- Persistent runtime state separate from `CapabilityManifest.lifecycle`.
- Provider enable/disable gate persisted through the existing `StorageAdapter`.
- Health probing with health, timestamp, latency, and last-error observation.
- Side-effect-free deterministic dispatch preview.
- Managed API invocation with observed success/failure state.
- `CapabilityRuntimeState` and `CapabilityRuntimeSnapshot` types.
- Native `/capabilities` management capability and page.
- Runtime-enriched `ProviderCard` diagnostics and controls.
- Provider lifecycle/invocation history events.
- AI Board adapter invoker seam so the existing typed adapter can be executed through the mother Runtime Manager.
- Remote AI Board reads/writes routed through the manager's enable gate.
- Runtime-manager architecture/spec/plan documentation.

### Behavioral guarantees
- Disabled providers fail before network execution.
- Preview performs no fetch/network side effect.
- Probe observations do not mutate manifest desired state.
- Operational state survives manager re-creation when storage persists.
- AI Board cannot bypass Runtime Manager from its Board UI.

### Verification environment
- Dependency-free Node test suite and offline TypeScript verification are the in-container executable evidence.
- Public AI Board live probe remained blocked by build-container DNS resolution.
- `npm install --no-audit --no-fund` reached the explicit 25-second timeout.
- Networked Vitest/Vite production build remains required before deployment.

### Still deferred
- Principal / Agent Identity / Session Context.
- OAuth/OIDC and delegated credentials.
- Policy/risk/permission engine beyond enable-disable.
- Background health polling.
- Remote MCP/A2A capability transports.
- Browser automation and Projection runtime.

## v0.0.4 — 2026-08-19

### Added
- Backward-compatible per-action HTTP bindings in `CapabilityManifest.runtime.actions`.
- `GET | POST` binding methods and `query | json | none` input modes.
- Deterministic query serialization for bound GET actions.
- Generic `executeApiDispatch` HTTP executor with non-2xx failure propagation.
- Generic provider health probe using `runtime.healthPath`.
- `aiBoard.ts` typed child adapter.
- AI Board manifest configured as `connected`, version `1.0.0-rc.1`, source `kakon77777-commits/ai-board`.
- Remote AI Board read/append UI while retaining local/remote data-truth separation.

## v0.0.3 — 2026-08-19

### Added
- Machine-readable child `CapabilityManifest` contract (`schemaVersion: 0.1`).
- Strict dependency-free manifest validation.
- `link | api | native` integration modes.
- Deterministic dispatch plans and fail-closed ID / route collision checks.

## v0.0.2 — 2026-08-18

### Added
- Persistent local Board posts.
- Arcade game sessions and reflection lineage.
- Shared cross-capability Activity Event history.

## v0.0.1 — 2026-08-18

### Added
- First AI Space Foundation Shell.
- Capability Registry with Home, Board, Arcade, Explore, and History.
- Snapshot-first GitHub workflow.
