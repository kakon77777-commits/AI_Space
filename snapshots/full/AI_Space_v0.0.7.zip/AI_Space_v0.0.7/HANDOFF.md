# AI Space v0.0.7 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/PROJECTION_RUNTIME.md`
4. `app/src/core/projections.ts`
5. `app/src/core/principals.ts`
6. `app/src/core/types.ts`
7. `app/src/App.tsx`
8. `app/src/pages/ProjectionsPage.tsx`
9. `docs/AGENT_IDENTITY_SESSION_CONTEXT.md`
10. `docs/CAPABILITY_RUNTIME_MANAGER.md`

## Current state

v0.0.7 is the first AI Space snapshot with bounded Projection Principals.

```text
Root Principal
→ Projection Principal
→ Space scope
→ permission / memory scope
→ ContextSession
→ Capability invocation
→ Event lineage
```

## Projection stores

Persistent keys:

```text
ai-space.projections.v1
ai-space.projection-checkpoints.v1
ai-space.projection-merge-candidates.v1
```

Projection Principal records remain in:

```text
ai-space.principals.v1
```

## Creation authority

Do not call generic Principal creation with `type=projection`.

```text
PrincipalStore.create(... projection ...)
→ rejected
```

Use:

```text
ProjectionStore.create(...)
```

It validates a non-Projection Root, creates the Projection Principal through the privileged PrincipalStore path, and persists Projection lineage/scopes.

Nested projections are intentionally rejected in v0.0.7.

## Active identity behavior

Enter Projection:

```text
active Principal = projection.principalId
```

Return to Root:

```text
active Principal = projection.rootPrincipalId
```

Suspending or archiving the currently active Projection automatically returns the App to the Root Principal.

The Agents page is passed only non-Projection root Principals, preventing it from bypassing Projection lifecycle controls.

## Permission behavior

Current enforcement point:

```text
invokeWithProjectionPermission
→ CapabilityRuntimeManager.invoke
→ transport
```

Empty scope denies all managed child invocations.

Examples:

```text
child:ai-board:LIST_MESSAGES
child:ai-board:*
*:*
```

This is not yet a general local-native RBAC system.

## Event behavior

`appendActivity()` resolves Projection metadata from the event's `principalId` and injects:

```text
projectionId
rootPrincipalId
spaceId
```

Existing `contextSessionId` and domain `sessionId` remain independent.

## Checkpoint / merge candidate

Checkpoints and merge candidates persist, but Merge/Reintegration does not execute.

Do not interpret `mergePolicy=automatic` as an implemented automatic merge in v0.0.7; it is future policy metadata only.

## Environment limitations

Before deployment, rerun on a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```

## Still deferred

- automatic Merge/Reintegration and rollback
- Root memory mutation / Memory Compiler
- Projection nesting
- general native-action RBAC / risk engine
- OAuth/OIDC / delegated credentials
- Browser/Arcade automation runtime
- full Shared Space entity/context
- public Agent federation

## Recommended next snapshot

`v0.0.8 — AI Arcade + Browser Session Boundary`

The first implementation should still avoid unrestricted browser autonomy. Start with explicit browser-session records, external-resource launch boundaries, Projection-aware experience traces, and isolation contracts.
