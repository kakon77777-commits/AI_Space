# AI Space v0.0.7 Verification

## Frozen execution evidence

Dependency-free core test command:

```bash
cd app
npm run test:core:offline
```

Result: **PASS — 72/72 tests**.

Evidence: `v0.0.7-final-core.log`.

Offline TypeScript source verification:

```bash
cd app
tsc -p validation/tsconfig.verify.json --noEmit --pretty false
```

Result: **PASS — exit 0, zero diagnostics**.

Evidence: `v0.0.7-final-typecheck.log`.

## TDD evidence

v0.0.7 preserves RED/GREEN evidence for:

- Projection Principal + ProjectionStore creation;
- root/Space lineage and scope normalization;
- lifecycle transitions;
- checkpoint / merge-candidate handoff records;
- managed-child Projection permission guard;
- shipped `/projections` route;
- direct Projection Principal creation bypass rejection.

## Network-limited checks

Public AI Board probe:

```bash
curl -fsS -D - --max-time 12 https://aiboard.evemisslab.com/api/schema
```

Result: DNS resolution failed before HTTP (`curl` exit 6).

Evidence: `v0.0.7-live-probe.log`.

Dependency installation probe:

```bash
timeout 25s npm install --no-audit --no-fund --package-lock=false
```

Result: explicit timeout (`exit 124`).

Evidence: `v0.0.7-npm-install.log`.

Therefore this snapshot does **not** claim a network-installed Vitest run, live public-provider reachability, or Vite production build in this container.

## Projection invariants verified

- generic Principal creation cannot bypass Projection Runtime;
- Projection Root must exist and cannot be another Projection in v0.0.7;
- Projection scope is normalized and persisted;
- suspended/archived Projection fails permission checks;
- denied managed child invocation fails before transport execution;
- archive is terminal;
- checkpoints and merge candidates persist without reintegration;
- EventStore can preserve Projection/root/Space lineage alongside ContextSession/domain session lineage;
- shipped `/projections` route exists;
- all previous core behavior remains green.

## Snapshot integrity

After source/docs/evidence are frozen:

```bash
python validation/verify_snapshot.py
```

The verifier checks:

- `SNAPSHOT.json` version is `0.0.7`;
- every path in `CHECKSUMS.sha256` exists and matches SHA-256;
- every snapshot file other than `CHECKSUMS.sha256` is included in the manifest.

## Required deployment verification

On a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
