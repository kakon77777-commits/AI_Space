# AI Space v0.0.3 Capability Adapter Contract — Design

**Goal:** Allow an independently versioned child project to declare a machine-readable capability manifest that AI Space can validate, discover, display, and convert into a deterministic dispatch plan without copying the child project's source tree.

## Scope

v0.0.3 adds the contract boundary only. It does not add remote code execution, OAuth, live health polling, cross-repo source sync, or direct AI Board API calls.

## Manifest

A child manifest uses schema version `0.1` and declares:

- stable capability/provider ID;
- human label and description;
- independent semantic version string;
- integration mode: `link | api | native`;
- declared actions, events, permissions;
- optional navigation metadata;
- source repository metadata;
- integration-specific runtime metadata.

Mode constraints:

- `link`: requires `externalUrl` using HTTP(S);
- `native`: requires an AI Space route;
- `api`: may be `declared` without a `baseUrl`; dispatch returns an explicit unavailable plan until configured.

## Runtime provider state

Validated manifests are represented as provider records with observed health state:

`unknown | healthy | degraded | offline`.

v0.0.3 defaults external provider health to `unknown`; it does not perform live network health checks.

## Dispatch

Dispatch is deterministic and does not depend on an LLM.

- undeclared action -> reject;
- link -> external URL plan;
- native -> native route plan;
- connected API -> typed POST plan to `<baseUrl>/invoke`;
- declared API without endpoint -> explicit unavailable plan.

The dispatcher creates plans; `App.tsx` decides how the browser executes link/native plans. API network execution remains deferred.

## Registry merge

Core native capabilities remain desired-state authority. Child manifests are converted into discovered capabilities/providers and merged only if IDs and routes do not collide. Collisions fail closed.

## Example child

Ship one machine-readable `AI Board` child manifest as metadata only. It demonstrates source repository ownership, independent versioning, API-mode declaration, actions/events/permissions, and `unknown` runtime health. It does not copy AI Board source and does not claim a live endpoint.

## UI

Home gains a compact `Discovered child capabilities` section showing provider name, version, mode, lifecycle, health, and source repository. The existing local Board surface remains active and is not replaced by the child declaration in v0.0.3.

## Acceptance criteria

1. Machine-readable child manifest validates.
2. Invalid schema/mode/action manifests fail with precise errors.
3. Child manifest becomes a provider record without source copying.
4. Dispatch plans are deterministic for Link, Native, and API modes.
5. Registry collisions are rejected.
6. AI Board example is visible as a discovered child provider while local Board still works.
7. Existing v0.0.2 core tests remain green.
