# AI Space v0.0.7 — Projection Runtime Design

## Status
Approved architectural direction carried forward from v0.0.6 and the user's explicit continuation instruction.

## Goal
Add bounded Projection Principals that preserve root lineage while limiting permissions, memory scope, and activity to a declared Space context.

## Core model
Extend `PrincipalType` with `projection`.

```ts
interface Projection {
  id: string
  principalId: string
  rootPrincipalId: string
  spaceId: string
  role?: string
  status: 'active' | 'suspended' | 'archived'
  permissionScope: string[]
  memoryScope: string[]
  mergePolicy: 'reviewed' | 'automatic' | 'none'
  createdAt: string
  updatedAt: string
  suspendedAt?: string
  archivedAt?: string
}
```

The projection Principal is a real `Principal` with `type: 'projection'` so existing Principal, ContextSession, Event, Board and Arcade pipelines can attribute actions directly to the bounded presence.

`Projection.rootPrincipalId` points to a non-projection Principal. Nested Projection creation is out of scope for v0.0.7.

## Permission scope
Permissions use exact strings:

```text
capabilityId:ACTION
capabilityId:*
*:* 
```

`projectionAllows(projection, capabilityId, action)` is deterministic. Empty scope denies all managed child-provider invocation. v0.0.7 enforces Projection scope at the Capability Runtime invocation boundary; local-native action RBAC is deferred.

## Memory scope
`memoryScope: string[]` is metadata describing which root-memory summaries/categories are intentionally inherited into the Projection. v0.0.7 does not build a Memory Compiler and does not copy raw memory automatically.

## Lifecycle
Allowed transitions:

```text
active -> suspended
suspended -> active
active|suspended -> archived
archived -> terminal
```

Projection records are never deleted in v0.0.7.

## Checkpoint / merge-candidate interface
Add persistent records but no automatic reintegration:

```ts
interface ProjectionCheckpoint {
  id: string
  projectionId: string
  summary: string
  createdAt: string
}

interface ProjectionMergeCandidate {
  id: string
  projectionId: string
  checkpointId?: string
  status: 'pending'
  createdAt: string
}
```

These records only establish the handoff boundary for a later Merge/Reintegration runtime.

## Event lineage
`ActivityEvent` gains optional:

```ts
projectionId?: string
rootPrincipalId?: string
spaceId?: string
```

The App-level activity helper injects these fields whenever the active Principal is a Projection Principal.

## UI
Add first-class native capability:

```text
Projections /projections
```

The page supports:
- list Projection records;
- create Projection from a non-projection root Principal;
- choose `spaceId`, role, permission scope, memory scope and merge policy;
- Enter Projection (activate projection Principal);
- Return to Root;
- suspend/resume/archive;
- create checkpoint;
- create merge candidate from latest/selected checkpoint;
- inspect root, Space, scopes, lifecycle and pending merge candidates.

Shell may show active Projection lineage when the active Principal is a Projection Principal.

## Runtime boundary
Capability Runtime Manager remains provider-global. Projection permission scope is checked before `runtimeManager.invoke(...)`; denied calls never reach transport.

## Explicitly out of scope
- automatic Merge / Reintegration
- root memory mutation
- personality/behavior delta application
- Projection nesting
- Principal-scoped general RBAC for native actions
- OAuth/OIDC
- browser isolation/runtime
- public federation

## Success criteria
1. Projection creation creates a persisted Projection Principal linked to a non-projection root.
2. Scope normalization and permission matching are tested.
3. Lifecycle transitions and terminal archive are tested.
4. Checkpoints and merge candidates persist without reintegration.
5. ActivityEvent preserves projection/root/space lineage.
6. `/projections` is shipped as a route.
7. Enter/return updates active Principal correctly.
8. Projection-scoped child-provider invoke is denied before transport when not allowed.
9. Existing v0.0.6 tests remain green.
10. Offline TypeScript verification passes.
