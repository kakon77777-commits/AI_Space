# AI Space v0.1.3 — State Authority Contract + Migration Planner

## Goal

Add a local, portable state-authority contract that can classify whether an incoming AI Space state bundle is the same head, a safe next checkpoint, stale, diverged, foreign, legacy, or a safe bootstrap candidate. Provide a safe migration apply path that only commits provable bootstrap/fast-forward transitions.

## Non-goals

- No cloud transport or account system.
- No realtime multi-device sync.
- No last-write-wins policy.
- No automatic state merge or conflict resolution.
- No cryptographic identity or signature.
- No automatic adoption of foreign lineages.
- No automatic unsupported bundle-schema migration.

## Core model

`StateAuthorityRecord` is local control-plane metadata, stored separately from the 19 portable domain-state entries:

```ts
interface StateAuthorityRecord {
  schemaVersion: '1.0'
  lineageId: string
  revision: number
  headChecksum: string
  stateFingerprint: string
  updatedAt: string
}
```

`lineageId` identifies one logical state lineage. `revision` is a monotonic checkpoint number. `headChecksum` is the checksum of the last authoritative bundle checkpoint. `stateFingerprint` fingerprints only the 19 managed domain-state entries, so authority can reason about state independent of bundle timestamp metadata.

The local authority record is stored at `ai-space.state-authority.v1` and is intentionally not included in the 19 domain-state entry allowlist. A v1.1 bundle carries portable authority metadata in its envelope.

## Bundle compatibility

AI Space must continue accepting v1.0 bundles from v0.1.2.

- Bundle schema `1.0`: legacy/unversioned authority semantics; existing replace restore remains available.
- Bundle schema `1.1`: adds `authority` metadata and checksum coverage of that metadata.

```ts
interface AiSpaceStateBundleAuthority {
  lineageId: string
  revision: number
  parentChecksum: string | null
  stateFingerprint: string
}
```

The existing FNV-1a checksum remains accidental-corruption detection only.

## Authoritative export

A new `exportAuthoritativeAiSpaceStateBundle(...)` function:

1. Reads the same 19 managed state entries.
2. Reads local authority metadata.
3. Creates the next checkpoint:
   - if no authority exists: create revision 1 with a caller/injected lineage ID;
   - otherwise: same lineage, revision + 1, parentChecksum = prior headChecksum.
4. Computes the bundle v1.1 checksum including authority metadata.
5. Writes the new authority record only after the bundle is successfully constructed.

Exporting an authoritative bundle is therefore an explicit checkpoint operation. Re-exporting unchanged state creates a new revision; v0.1.3 does not deduplicate checkpoints.

## Migration relation

`planAiSpaceStateMigration(...)` classifies an incoming bundle against target storage:

- `equal`: v1.1 candidate checksum equals local authority head.
- `bootstrap`: target has no authority record and no managed state; candidate is v1.1.
- `fast-forward`: same lineage, candidate revision = local revision + 1, and candidate parentChecksum = local headChecksum.
- `stale`: same lineage, candidate revision <= local revision, but not equal.
- `diverged`: same lineage but the candidate is not a provable direct child of local head.
- `foreign`: different lineage IDs.
- `legacy`: candidate schema v1.0.
- `untracked-local`: target has managed state but no authority record.

Only `bootstrap` and `fast-forward` are safe-to-apply migrations. `equal` is a no-op. Every other relation is fail-closed for safe migration.

## Migration application

`applyPlannedAiSpaceStateMigration(...)` must recompute the plan immediately before mutation. It must not trust an earlier UI preview.

For safe relations:

1. Run existing staged bundle validation/audit.
2. Capture all 19 managed keys plus authority metadata.
3. Restore domain state using the existing audited restore path.
4. Commit the candidate authority record.
5. If authority commit or later write fails, roll back both domain state and authority metadata.

No merge semantics are introduced.

## UI

Extend `/backup` rather than adding a new product surface.

The page should show:

- local authority lineage/revision/head when available;
- Generate authoritative bundle;
- migration relation after Validate / Plan;
- whether safe migration is allowed;
- Apply safe migration & reload button only when safe;
- existing explicit replace restore remains available, visually separated and labelled destructive/replace semantics.

## Testing

Use dependency-free Node core tests first.

Required regressions:

1. v1.0 bundles remain valid and replace-restorable.
2. v1.1 authoritative export creates revision 1 and persists authority.
3. second authoritative export increments revision and links parentChecksum.
4. checksum covers authority metadata.
5. planner classifies equal/bootstrap/fast-forward/stale/diverged/foreign/legacy/untracked-local.
6. safe apply accepts bootstrap/fast-forward only.
7. stale/diverged/foreign/legacy/untracked-local safe apply performs zero target mutation.
8. migration apply rollback restores both domain state and authority metadata if authority commit fails.
9. full coherent MVP state migrates target A -> bundle rev1 -> target B bootstrap -> target A rev2 -> target B fast-forward, and remains coherent/audit-clean after fresh store recreation.
10. offline TypeScript source verification remains clean.

## Boundaries

- Authority metadata is a local state-lineage contract, not user identity.
- FNV-1a is not a trust signature.
- Safe migration proves only a direct checkpoint transition, not semantic conflict freedom between arbitrary branches.
- v0.1.3 intentionally rejects history gaps rather than guessing ancestry.
