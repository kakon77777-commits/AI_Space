# AI Space v0.1.0 — First Coherent AI Space MVP Design

## Goal

Turn the accumulated v0.0.x subsystems into one explicit, resumable, testable end-to-end MVP journey without adding a new horizontal product surface.

The canonical path is:

```text
Root Principal
→ ContextSession
→ Projection
→ Space presence
→ Capability interaction
→ BrowserSession boundary
→ ExperienceRecord
→ ReflectionCandidate
→ BoardPost
→ Return Root
→ Close ContextSession
→ Coherence PASS
```

## Scope

v0.1.0 adds an integration/runtime layer named **MVP Journey**. A Journey stores only stable references into the existing authoritative stores. It does not duplicate Principal, Space, Resource, Event, Experience, or Board data.

A Journey may be `active`, `completed`, or `abandoned`.

### Journey reference fields

- `rootPrincipalId`
- `contextSessionId`
- `projectionId`
- `projectionPrincipalId`
- `spaceId`
- `capabilityId`
- `resourceId`
- optional `browserSessionId`
- optional `experienceId`
- optional `reflectionCandidateId`
- optional `reflectionPostId`
- timestamps and terminal status

## Authoritative data

The Journey is an **index and coherence record**, not a second truth store.

```text
Principal truth        = PrincipalStore
Context truth          = ContextSessionStore
Projection truth       = ProjectionStore
Space truth            = SpaceStore
Capability truth       = Capability registry/runtime
Resource truth         = ResourceStore
Interaction truth      = BrowserSessionStore
Experience truth       = ExperienceRecord store
Reflection truth       = ReflectionCandidate + PostStore
History truth          = EventStore
Journey truth          = only stable cross-store references + terminal status
```

## Coherence evaluator

A pure evaluator verifies reference and lineage consistency. It produces named stages:

1. `principal`
2. `context`
3. `projection`
4. `space`
5. `capability`
6. `interaction`
7. `experience`
8. `reflection`
9. `return`

A completed Journey is coherent only when:

- root Principal exists and is not a Projection;
- ContextSession exists, belongs to root, and is closed;
- Projection exists and matches root, Projection Principal, and Space;
- root is a member of the Space;
- BrowserSession exists and matches Projection, Space, context, and Resource;
- BrowserSession is completed;
- ExperienceRecord exists and matches BrowserSession lineage;
- ReflectionCandidate is promoted and links to the Journey BoardPost;
- BoardPost points back to the BrowserSession and Resource;
- active Principal is the root;
- Projection Principal no longer has active Space presence;
- Journey status is `completed`.

An active Journey can be evaluated at any time and shows the first incomplete or invalid stage.

## MVP Journey runtime

`MvpJourneyRuntime` coordinates existing stores. It provides:

- `begin(...)`
- `startInteraction(...)`
- `completeInteraction(...)`
- `promoteReflection(...)`
- `finish(...)`
- `abandon(...)`
- `evaluate(...)`

### Begin

`begin` requires:

- a root Principal;
- no already-active ContextSession for that root;
- an active Space where the root is a member;
- an existing external Resource.

It creates a new ContextSession and Projection, enters the Projection into its Space, switches active Principal to the Projection, and stores a new Journey.

The generated Projection permission scope contains exactly the minimum MVP capability permission:

```text
arcade:START_BROWSER_SESSION
```

No automatic browser control is added.

### Interaction

`startInteraction` creates a tracked BrowserSession through the existing BrowserSessionStore and returns its launch plan. The runtime does not claim the external browser was observed.

### Complete interaction

`completeInteraction` requires an explicit human/agent supplied summary and records Experience + pending ReflectionCandidate through the existing BrowserSessionStore.

### Promote reflection

`promoteReflection` creates a local Board post from the Experience lineage, promotes the existing ReflectionCandidate, and stores only the resulting post reference in the Journey.

### Finish

`finish`:

- requires promoted reflection;
- leaves Projection Space presence;
- restores the root as active Principal;
- closes the Journey ContextSession;
- marks the Journey completed;
- re-evaluates and throws if the resulting chain is not coherent.

No Merge/Reintegration is performed. Projection lifecycle and Root memory remain unchanged.

## UI

Add a first-class `/mvp` native surface named **MVP Journey**.

It is a guided integration harness, not a new domain subsystem.

The page supports:

- selecting a root Principal, active/member Space, and existing Resource;
- starting a Journey;
- launching the tracked BrowserSession;
- completing it with an explicit Experience summary;
- promoting the pending reflection to Board;
- returning to Root and closing the context;
- viewing the coherence stage report;
- reopening/reviewing persisted Journeys after reload.

## Event history

The App records explicit Journey lifecycle events in the existing EventStore:

- `MVP_JOURNEY_STARTED`
- `MVP_INTERACTION_STARTED`
- `MVP_EXPERIENCE_RECORDED`
- `MVP_REFLECTION_PROMOTED`
- `MVP_JOURNEY_COMPLETED`
- `MVP_JOURNEY_ABANDONED`

Events reuse the Journey's root/context/projection/space/resource lineage.

## Safety and truth boundaries

- No browser automation.
- No DOM/click/screenshot observation.
- No inference that an opened external page was successfully used unless the user explicitly completes the BrowserSession.
- No automatic Projection Merge/Reintegration.
- No public federation/realtime collaboration.
- No source expansion on GitHub.

## Acceptance criteria

A clean local run can:

1. create or select a root Principal;
2. begin an MVP Journey in an active member Space;
3. create/enter a bounded Projection;
4. start a tracked browser interaction against an existing Resource;
5. explicitly complete with Experience text;
6. promote the Experience to a Board reflection;
7. return to Root and close the ContextSession;
8. persist all references;
9. reload stores and re-evaluate the completed Journey as coherent;
10. reconstruct the runnable app from the prior FULL snapshot plus verified GitHub deltas with `diff=0`.
