# AI Space Foundation Shell v0.0.1 Design

## Status
Approved in chat on 2026-08-18.

## Goal
Build the first runnable AI Space shell as a single Vite + React + TypeScript website while keeping GitHub as a snapshot/handoff repository rather than the live development surface.

## Scope
v0.0.1 implements only:

- Single website shell with Home, Board, Arcade, Explore, and History surfaces.
- Static Capability Registry that drives navigation and route resolution.
- External Link resources with safe `http:` / `https:` URL validation.
- Local event history for capability opens, resource creation, and external launches.
- localStorage persistence behind a storage adapter.
- Documentation, handoff metadata, checksums, and a versioned ZIP snapshot.

## Explicitly out of scope

- OAuth / OIDC.
- External agent registration.
- Agent Projection / merge runtime.
- Real AI Board API integration.
- Browser automation or isolated browser workers.
- Server database, backend API, or cloud deployment.
- Native game runtime.
- Global memory compiler.

## Architecture

The app uses a deliberately thin shell:

`Shell -> Capability Registry -> Route/Action -> Event Store`

Explore owns local external resources. Arcade is a filtered projection of resources whose type is `game`. Board is a placeholder Capability Surface proving that a capability may exist before its backend adapter is connected.

The domain core is framework-independent TypeScript so later AI Space clients and services can reuse it. React only renders projections of domain state.

## Data model

### Capability
- `id`
- `label`
- `description`
- `route`
- `mode`: `native | api | link`
- `status`: `ready | placeholder`
- `actions[]`
- optional navigation metadata

### Resource
- `id`
- `title`
- `type`: `game | website | research | tool | media`
- `url`
- `createdAt`

### Event
- `id`
- `timestamp`
- `principalId`
- `action`
- optional `capabilityId`
- optional `resourceId`
- `summary`

## Persistence
localStorage is accessed only through a `StorageAdapter` contract. The domain stores accept any adapter, enabling migration to IndexedDB, SQLite, D1, or a remote API later.

## UI
- Desktop-first responsive shell.
- Left navigation driven by the registry.
- Dark neutral interface with no external UI component library.
- Home shows capability state and recent activity.
- Explore can create and launch external resources.
- Arcade shows game-type resources and logs launches.
- History shows newest-first event records and can clear local history.

## Security baseline
- Only `http:` and `https:` external URLs are accepted.
- External links open with `noopener,noreferrer`.
- No credentials are stored.
- External pages are treated as untrusted; v0.0.1 provides links only, not embedded frames or automation.

## Snapshot workflow
Development occurs in the conversation/local workspace. GitHub stores only a minimal project README, snapshot index, and a versioned ZIP archive. Source files inside the ZIP are canonical for the snapshot.
