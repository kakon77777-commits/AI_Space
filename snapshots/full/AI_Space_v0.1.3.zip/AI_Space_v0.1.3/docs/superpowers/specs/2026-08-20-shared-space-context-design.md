# AI Space v0.0.9 — Shared Space Context Design

## Goal
Promote `spaceId` from a free-form lineage string into a persistent Mother Runtime object that owns local membership, active presence, shared resource references, and a history projection while preserving existing global Event and Resource authorities.

## Scope
v0.0.9 implements local Shared Space Context only. It does **not** implement remote federation, realtime multi-user synchronization, chat rooms, distributed locks, remote presence, or a second event database.

## Core model

```text
Space
├─ membership[]          (root Principals only)
├─ active presence[]     (root Principal or bounded Projection)
├─ resource refs[]       (references to canonical ResourceStore objects)
└─ history view          (projection of global ActivityEvent by spaceId)
```

A Space is persistent and authoritative. Projection/Event/BrowserSession records reference `spaceId`; they do not define the Space.

## Types

- `SpaceStatus = active | archived`
- `SpaceVisibility = private | shared`
- `SpaceMembershipRole = owner | member`
- `Space`
  - `id`
  - `name`
  - optional `description`
  - `ownerPrincipalId`
  - `visibility`
  - `status`
  - timestamps
- `SpaceMembership`
  - `spaceId`
  - `principalId`
  - `role`
  - `joinedAt`
- `SpacePresence`
  - `principalId`
  - `spaceId`
  - `enteredAt`
- `SpaceResourceRef`
  - `id`
  - `spaceId`
  - `resourceId`
  - `addedByPrincipalId`
  - `addedAt`

## Built-in local Spaces
On first local load, seed the four stable IDs below under the backward-compatible default root Principal `agent:local-demo`:

- `research`
- `arcade`
- `board`
- `library`

Seeding is idempotent and creates the owner membership if missing. Stable IDs preserve compatibility with v0.0.7/v0.0.8 Projection conventions such as `spaceId: arcade`.

## Membership rules
- Space owner must be a non-Projection Principal.
- Creating a Space automatically creates one owner membership.
- Only the owner may add/remove members or archive the Space.
- `private` Spaces reject member addition; `shared` Spaces may add non-Projection Principal members.
- The owner cannot be removed.
- Projection Principals are not stored as membership rows. Their access is inherited from their Root Principal plus Projection binding.

## Presence rules
- Each Principal may have at most one active Space presence.
- Root Principals may enter only active Spaces in which they are members.
- Entering a second Space requires leaving the first.
- Projection presence requires:
  - Projection status `active`
  - Projection `spaceId` equals target Space
  - target Space is active
  - Projection Root Principal is a Space member
- Leaving removes only presence; it does not close ContextSession and does not change identity.
- Archiving a Space clears all active presences in that Space.
- Entering a Projection through `/projections` also enters its bound Space; returning/suspending/archiving that Projection clears its Space presence.

## Projection binding
New Projection creation is accepted only when its `spaceId` resolves to an active Space and the Root Principal is a member. Existing persisted legacy Projection rows remain readable; if their Space does not exist they cannot be entered until a valid Space exists.

## Resource sharing
Canonical resources remain in `ResourceStore`. Space sharing stores only `SpaceResourceRef` records.

Adding a resource requires the acting Principal to have Space access:
- root Principal: membership in Space
- Projection Principal: active presence in the bound Space

Duplicate `(spaceId, resourceId)` references are rejected.

## History sharing
No second history database is created. `selectSpaceEvents(events, spaceId)` returns global Activity Events whose authoritative `spaceId` matches the Space.

`appendActivity` resolves `spaceId` in this order:
1. explicit caller-provided `spaceId`
2. active Space presence for the acting Principal
3. Projection lineage fallback
4. absent

This keeps Projection lifecycle events traceable even when they are emitted while the Projection is not currently entered.

## UI
Add `/spaces` native capability with:
- Space creation (root Principal only)
- local membership management
- enter/leave for root Principals
- Space archive
- attach canonical Resource references
- selected Space resource list
- selected Space activity history
- visible active-presence state

Update `/projections` creation to select from existing active Spaces in which the selected Root Principal is a member instead of accepting arbitrary free text.

Update the Shell sidebar to show active Space context.

## Security / semantic boundary
`shared` means shared among registered local root Principals in this browser-local runtime. It does **not** mean publicly accessible, remotely synchronized, federated, or cryptographically authenticated.

## Acceptance criteria
1. Built-in Spaces seed idempotently.
2. Space ownership/membership rules are enforced.
3. Presence enter/leave rules are enforced for root and Projection Principals.
4. New Projection binding requires an existing active member Space.
5. `/spaces` is a shipped native route.
6. Projection enter/return/suspend/archive updates Space presence.
7. Resource refs never duplicate the canonical Resource object.
8. Space history is a filtered view of global Activity Events.
9. Existing v0.0.8 tests remain green.
10. Offline TypeScript verification is clean.
