# AI Space v0.1.2 — Persistence Portability / Backup–Restore Gate

## Goal
Make AI Space browser-local persistent state portable across reloads, browsers, machines, and future storage backends without introducing cloud sync or changing existing domain stores.

## Design
AI Space gains a versioned `AiSpaceStateBundle` that captures only a fixed allowlist of AI Space-owned storage keys. Bundles use schema version `1.0`, carry a non-cryptographic deterministic integrity fingerprint for accidental-corruption detection, and never enumerate or export unrelated browser localStorage keys.

Import is a staged operation. The bundle is parsed and structurally validated first, restored into an isolated `MemoryStorageAdapter`, instantiated through the existing domain stores, and audited with the v0.1.1 invariant auditor. Only a bundle with no audit errors is eligible for commit to the real target adapter. Restore writes exactly the allowlisted keys and can explicitly clear keys represented as `null`; it does not touch unrelated storage.

A dry-run preview reports changed/created/cleared/unchanged AI Space keys before any mutation. Import does not attempt semantic schema migration in v0.1.2: unsupported bundle schema versions fail closed. This becomes the stable migration boundary for later versions.

## Bundle shape
```ts
interface AiSpaceStateBundle {
  schemaVersion: '1.0'
  appVersion: string
  createdAt: string
  checksumAlgorithm: 'fnv1a32'
  checksum: string
  entries: Record<AiSpaceStateKey, string | null>
}
```

The checksum is explicitly an accidental-corruption fingerprint, not a cryptographic signature or trust proof.

## Canonical state-key allowlist
The bundle includes the current durable and operational AI Space-owned keys:
- principals + active principal
- context sessions
- projections + checkpoints + merge candidates
- spaces + memberships + presences + resource refs
- resources
- events
- posts
- game sessions
- browser sessions + experiences + reflection candidates
- MVP journeys
- capability runtime state

Unknown browser keys are never exported or modified.

## Validation and staging
1. Parse object or JSON text.
2. Require schemaVersion `1.0`, checksumAlgorithm `fnv1a32`, and exact allowlisted entry keys.
3. Require every entry value to be `string | null`.
4. Recompute checksum from canonicalized metadata/entries and reject mismatch.
5. Stage entries into a fresh MemoryStorageAdapter.
6. Instantiate existing stores and run `auditAiSpaceState` against the staged state.
7. Reject import if audit `errorCount > 0`.
8. On commit, mutate only allowlisted keys.

## Restore modes
v0.1.2 exposes one explicit `replace-ai-space-state` restore mode. It replaces/clears the allowlisted AI Space state keys but leaves unrelated browser storage untouched. Merge semantics are deferred because silent record merging would create ambiguous identity and lineage conflicts.

## UI boundary
A first-class `/backup` native surface may export a JSON bundle, validate pasted/uploaded JSON, show dry-run counts, and commit a validated restore. It must explain that restore replaces AI Space-owned local state only and that the FNV fingerprint is not a security signature.

## Non-goals
- cloud sync
- multi-device live replication
- account login/OAuth
- cryptographic signing/encryption
- automatic schema migration across unsupported bundle versions
- merge import semantics
- backup of unrelated localStorage keys

## Acceptance
- Export/import round-trip into fresh storage preserves the v0.1.1 coherent MVP Journey and passes the hardening auditor after store recreation.
- Corrupted checksum fails before mutation.
- Unsupported schema version fails closed.
- Invalid/orphan cross-store state fails staging audit before mutation.
- Dry-run has zero side effects.
- Restore leaves an unrelated storage key untouched.
- Full prior test suite remains green and offline TypeScript source-check passes.
