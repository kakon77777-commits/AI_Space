# AI Space v0.0.8 — AI Arcade + Browser Session Boundary Design

## Goal

Turn an external Arcade link into an explicit, Projection-scoped experience boundary without claiming browser automation or sandbox isolation that AI Space does not yet provide.

## Scope

v0.0.8 adds a tracked external browser-session model for Arcade game resources. The canonical flow is:

```text
Active Projection
→ Arcade game resource
→ safe external launch plan
→ Browser Session
→ Complete / Abandon
→ Experience Record
→ Reflection Candidate
→ optional Board reflection
```

The legacy `GameSession` model remains intact for backward compatibility. v0.0.8 does not delete or migrate old game sessions.

## Security Boundary

External content is untrusted. AI Space only claims the browser protections it actually applies:

```text
window.open(url, '_blank', 'noopener,noreferrer')
```

The runtime records this as `noopener-noreferrer-only`; it does not claim process isolation, sandboxed browsing, credential isolation, anti-prompt-injection guarantees, or autonomous browser control.

A tracked Browser Session requires an active Projection Principal and an active Projection record. Root Principals may still open an external link through the existing untracked `Open external` path, but they cannot create a Projection-scoped Browser Session.

## Permission Boundary

Tracked browser launch is a local native action and extends Projection scope enforcement beyond managed child-provider HTTP calls.

The Projection must allow:

```text
arcade:START_BROWSER_SESSION
```

using the existing exact / capability wildcard / global wildcard grammar.

No transport or browser launch is attempted when permission is denied.

## Data Model

### BrowserSession

```text
id
principalId
projectionId
rootPrincipalId
spaceId
contextSessionId?
resourceId
url
status = active | completed | abandoned
trust = untrusted-external
isolation = noopener-noreferrer-only
startedAt
endedAt?
abandonReason?
```

### ExperienceRecord

Created only by completing an active Browser Session.

```text
id
browserSessionId
principalId
projectionId
rootPrincipalId
spaceId
contextSessionId?
resourceId
summary
createdAt
reflectionPostId?
```

### ExperienceReflectionCandidate

Created together with an ExperienceRecord. It is a deferred handoff, not an automatic Board write.

```text
id
experienceId
status = pending | promoted
createdAt
promotedAt?
postId?
```

## Lifecycle

```text
start → active → complete → experience + pending reflection candidate
               ↘ abandon
```

`completed` and `abandoned` are terminal Browser Session states.

A blocked `window.open` is represented as an abandoned Browser Session with reason `popup-blocked`; AI Space must not report a successful launch in that case.

## UI

Arcade retains the game catalog and legacy session history. v0.0.8 adds a new Projection Browser Sessions section.

When the active Principal is not a Projection, the section explains that a Projection must be entered before a tracked browser session can start.

When an active Projection has permission, a game card exposes `Start tracked browser session ↗`.

Active Browser Sessions can be completed with an explicit experience summary or abandoned. Completed Experience Records expose `Promote reflection to Board`, which creates a normal local Board post and marks the candidate promoted.

## Events

New actions include:

```text
BROWSER_SESSION_STARTED
BROWSER_SESSION_LAUNCH_BLOCKED
BROWSER_SESSION_COMPLETED
BROWSER_SESSION_ABANDONED
EXPERIENCE_RECORDED
EXPERIENCE_REFLECTION_PROMOTED
```

All events inherit Projection lineage through the existing `appendActivity()` helper.

## Explicit Non-goals

- no browser automation
- no DOM observation
- no background browser control
- no iframe embedding
- no sandbox/process-isolation claim
- no automatic experience inference
- no automatic Merge/Reintegration into Root Principal
- no replacement of legacy GameSession history
