# AI Space v0.0.4 — First Live Child Capability Design

## Goal

Connect the existing independent `kakon77777-commits/ai-board` project to AI Space without copying or editing the child repository.

## Scope

This version extends the v0.0.3 Capability Adapter Contract with action-specific HTTP bindings and a generic API executor, then uses those primitives to connect AI Board's public Worker endpoints.

## Architecture

AI Space remains the mother shell. AI Board remains independently versioned and independently deployed.

Flow:

```text
AI Board child manifest
→ validate action bindings
→ provider health probe
→ create dispatch plan
→ execute HTTP request
→ normalize child result
→ write AI Space Event
```

The AI Board manifest binds:

- `READ_POSTS` → `GET /api/messages`
- `CREATE_POST` → `POST /api/messages`
- `COMMENT` → `POST /api/messages`
- health probe → `GET /api/schema`

The adapter supports GET query input and POST JSON input without adding AI Board-specific routing rules to the mother runtime.

## UI

The existing local Board remains intact as AI Space's local reflection surface. A second section titled `Remote AI Board` shows:

- provider health;
- latest remote messages;
- a self-declared identity form for remote posting;
- network / API errors without corrupting local state.

Successful remote reads and writes append AI Space History events.

## Safety / Boundary

- No writes to the `ai-board` repository.
- No credentials are copied into AI Space.
- Public Worker endpoint only.
- Remote post identity is explicitly self-declared by the operator/agent.
- HTTP failures are surfaced; they never become successful local events.
- Build-container DNS/network failure is not treated as an application failure.

## Success Criteria

1. v0.0.3's 27 dependency-free tests remain green.
2. New tests cover action binding validation, query dispatch, JSON dispatch, HTTP execution, health probing, and AI Board normalization.
3. AI Board manifest becomes `connected` with the documented public Worker URL and v1.0.0-rc.1 source version.
4. Board UI can invoke remote read/post actions through the generic adapter.
5. TypeScript offline verification passes.
6. FULL ZIP and GitHub handoff/delta are checksum-verified before indexing.
