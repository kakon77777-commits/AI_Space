# AI Space v0.0.5 Capability Runtime Manager Design

**Date:** 2026-08-19  
**Status:** Implemented / snapshot design  
**Base:** v0.0.4 First Live Child Capability

## Goal

Turn the passive Capability Registry into an operational Mother Runtime that can persist per-provider runtime state, diagnose providers, gate invocation, preview dispatch, and expose those operations in a first-class management surface.

## Non-goals

v0.0.5 does not add Agent Identity, OAuth/OIDC, Projection Runtime, a second child provider, background polling, or third-party capability installation.

## Architecture

Keep the existing layers:

```text
Manifest → Adapter → Provider
```

Add one operational layer:

```text
Provider
→ CapabilityRuntimeManager
→ runtime state / probe / preview / invoke
```

The Runtime Manager is framework-independent and consumes existing `StorageAdapter`, `CapabilityProvider`, dispatch-plan builder, and HTTP executor interfaces.

## State separation

`CapabilityManifest.lifecycle` is desired/configuration state. It is never changed by health observations.

`CapabilityRuntimeState.enabled` is the local operational invocation gate.

`CapabilityRuntimeState.health` and timestamps/errors are observed state.

## Persistence

Persist runtime state as one JSON object through `StorageAdapter` under `ai-space.capability-runtime.v1`. Domain data stays in its existing stores.

## Probe behavior

Probe `baseUrl + healthPath`. Record observation timestamp and latency. Map 2xx to healthy, non-2xx to degraded, transport failure to offline, missing health endpoint to unknown.

## Invoke behavior

Reject disabled providers before I/O. Build the same deterministic dispatch plan used by Preview. v0.0.5 executes API plans only. Update runtime observations after success/failure.

## UI

Add native `/capabilities` route. Render one control block per registered provider with status, actions, endpoint, Probe, Enable/Disable, Preview, Invoke, result and error.

## AI Board integration

Preserve `aiBoard.ts` as a typed domain adapter. Add an invoker seam so the adapter may delegate execution through the Runtime Manager. Remote Board read/write calls must use that seam in `App.tsx`.

## Event behavior

Project management operations into the existing EventStore at the App boundary, not inside the core manager.

## Acceptance

- Runtime state persists across manager recreation.
- Enable/disable persists.
- Disabled invoke performs zero fetch calls.
- Probe records health, time, latency and error.
- Preview performs zero fetch calls.
- Invoke updates success/failure observations.
- `/capabilities` is a valid mother route.
- Remote AI Board cannot bypass a disabled provider.
- Existing Board/Arcade/History behavior remains green.
