# AI Space v0.0.6 Agent Identity + Session Context Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add persisted Principals and cross-capability ContextSessions, then thread that context through shared activity without changing existing domain-session semantics.

**Architecture:** `PrincipalStore` owns engineering identities and active-principal selection. `ContextSessionStore` owns one active cross-capability session per Principal. App-level event creation injects the active context, while existing Arcade `GameSession` remains a distinct domain session.

**Tech Stack:** React 19, TypeScript, Vite, StorageAdapter/localStorage, Node built-in dependency-free tests.

**Spec:** `docs/superpowers/specs/2026-08-20-agent-identity-session-context-design.md`

## Global Constraints
- Snapshot-first development; GitHub source tree stays unexpanded.
- Preserve existing `ActivityEvent.sessionId` as domain-session lineage.
- Add `contextSessionId`; do not rename or reinterpret `sessionId`.
- Seed `agent:local-demo` for backward compatibility.
- No Projection, OAuth, RBAC, federation, or server database in v0.0.6.
- Use `npm run test:core:offline` for dependency-free test verification.
- Use `npx tsc -p validation/tsconfig.verify.json --noEmit --pretty false` only if installed; otherwise use the snapshot's offline TypeScript verifier pattern already present in the project.

---

### Task 1: Principal model and persistence

**Files:**
- Modify: `app/src/core/types.ts`
- Create: `app/src/core/principals.ts`
- Create: `app/tests/principals.test.mjs`

**Interfaces:**
- Produces: `Principal`, `PrincipalType`, `PrincipalStore`, `CreatePrincipalInput`.
- `PrincipalStore.ensureDefault(): Principal`
- `PrincipalStore.create(input): Principal`
- `PrincipalStore.list(): Principal[]`
- `PrincipalStore.get(id): Principal | undefined`
- `PrincipalStore.getActive(): Principal`
- `PrincipalStore.setActive(id): Principal`

- [ ] **Step 1: Write failing PrincipalStore tests** covering default seeding, create/persist, trimmed required displayName, and active-principal validation.
- [ ] **Step 2: Run `npm run test:core:offline`** and confirm failure is caused by missing PrincipalStore/types.
- [ ] **Step 3: Implement minimal Principal types and PrincipalStore** using `StorageAdapter`.
- [ ] **Step 4: Re-run `npm run test:core:offline`** and require all baseline + principal tests to pass.

### Task 2: ContextSession lifecycle

**Files:**
- Modify: `app/src/core/types.ts`
- Create: `app/src/core/contextSessions.ts`
- Create: `app/tests/context-sessions.test.mjs`

**Interfaces:**
- Produces: `ContextSession`, `ContextSessionStatus`, `ContextSessionStore`.
- `ContextSessionStore.start({ principalId, label }): ContextSession`
- `ContextSessionStore.close(id): ContextSession`
- `ContextSessionStore.list(): ContextSession[]`
- `ContextSessionStore.listForPrincipal(principalId): ContextSession[]`
- `ContextSessionStore.getActive(principalId): ContextSession | undefined`

- [ ] **Step 1: Write failing context-session tests** for start/close, one-active-per-principal, different-principal independence, and trimmed labels.
- [ ] **Step 2: Run core tests** and verify RED is the missing ContextSession implementation.
- [ ] **Step 3: Implement ContextSessionStore** with deterministic storage semantics.
- [ ] **Step 4: Re-run core tests** and require GREEN.

### Task 3: Activity/context lineage

**Files:**
- Modify: `app/src/core/types.ts`
- Modify: `app/tests/events.test.mjs`
- Modify: `app/src/core/sessions.ts`
- Modify: `app/tests/sessions.test.mjs`
- Modify: `app/src/core/posts.ts`
- Modify: `app/tests/posts.test.mjs`

**Interfaces:**
- Adds: `ActivityEvent.contextSessionId?: string`.
- Adds: `GameSession.contextSessionId?: string` and `StartGameSessionInput.contextSessionId?: string`.
- Adds: `BoardPost.contextSessionId?: string` and post creation support.

- [ ] **Step 1: Add failing lineage tests** proving events can hold both `contextSessionId` and `sessionId`, game sessions preserve context lineage, and posts preserve context lineage.
- [ ] **Step 2: Run core tests** and confirm RED comes from missing fields/behavior.
- [ ] **Step 3: Implement minimal optional lineage fields** without migrating legacy rows.
- [ ] **Step 4: Re-run all core tests** and require GREEN.

### Task 4: Agents route and shell context UI

**Files:**
- Modify: `app/src/data/capabilities.ts`
- Modify: `app/tests/shell.test.mjs`
- Create: `app/src/pages/AgentsPage.tsx`
- Modify: `app/src/components/ShellLayout.tsx`
- Modify: `app/src/App.tsx`
- Modify: `app/src/styles.css`

**Interfaces:**
- Adds native capability: `agents` at `/agents`.
- `ShellLayout` consumes `activePrincipal?: Principal` and `activeContextSession?: ContextSession`.
- `AgentsPage` consumes principal/session lists and callbacks for create/select/start/close.

- [ ] **Step 1: Add failing shell-route test** for `/agents`.
- [ ] **Step 2: Run core tests** and verify route RED.
- [ ] **Step 3: Add Agents capability and page UI**, then wire PrincipalStore and ContextSessionStore into App.
- [ ] **Step 4: Replace hard-coded `PRINCIPAL_ID`** with active Principal and a single context-aware event helper.
- [ ] **Step 5: Ensure Board posts, Arcade sessions, remote Board events, provider events, and resource events use active Principal/context.**
- [ ] **Step 6: Run all core tests** and require GREEN.

### Task 5: Offline type verification and version freeze

**Files:**
- Modify: `app/package.json`
- Modify: `README.md`
- Modify: `HANDOFF.md`
- Modify: `CHANGELOG.md`
- Create: `docs/AGENT_IDENTITY_SESSION_CONTEXT.md`
- Modify/Create validation and snapshot metadata files following existing snapshot convention.

**Interfaces:**
- Version becomes `0.0.6`.
- Handoff records exact verified test count and network/build limitations.

- [ ] **Step 1: Run dependency-free core tests fresh.**
- [ ] **Step 2: Run offline TypeScript verification fresh.**
- [ ] **Step 3: Attempt networked `npm install` and live AI Board probe with explicit timeout; record limitations without treating environment failures as source failures.**
- [ ] **Step 4: Update README/HANDOFF/CHANGELOG and technical doc with no placeholders.**
- [ ] **Step 5: Freeze snapshot, generate checksum manifest, create FULL ZIP, extract it cleanly, and re-run verifier/tests/typecheck from the delivered artifact.**
- [ ] **Step 6: Create compact GitHub deltas, prove reconstruction diff=0, verify Git blob SHA byte-equivalence, and update only README/SNAPSHOTS/snapshots on GitHub.**
