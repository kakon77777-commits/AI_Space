# AI Arcade + Browser Session Boundary Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build Projection-scoped tracked external Browser Sessions that produce explicit Experience Records and reviewable Board reflection candidates.

**Architecture:** Add one persistent `BrowserSessionStore` responsible for BrowserSession, ExperienceRecord, and ReflectionCandidate state. Reuse Projection permission grammar for the local `arcade:START_BROWSER_SESSION` boundary, then wire the new store into Arcade without deleting legacy GameSession behavior.

**Tech Stack:** TypeScript, React, BrowserStorageAdapter, Node dependency-free test runner.

**Spec:** `docs/superpowers/specs/2026-08-20-ai-arcade-browser-session-boundary-design.md`

## Global Constraints

- External content remains untrusted.
- Browser protection claim is limited to `noopener,noreferrer`.
- Tracked Browser Sessions require an active Projection.
- `arcade:START_BROWSER_SESSION` must be allowed before browser I/O.
- No automatic Browser observation or automation.
- No automatic Merge/Reintegration.
- Existing GameSession data remains backward compatible.

---

### Task 1: Browser Session core

**Files:**
- Modify: `app/src/core/types.ts`
- Create: `app/src/core/browserSessions.ts`
- Create: `app/tests/browser-sessions.test.mjs`

**Interfaces:**
- Consumes: `Projection`, `ExternalResource`, `StorageAdapter`, `projectionAllows()`.
- Produces: `BrowserSessionStore`, `BrowserLaunchPlan`, BrowserSession / ExperienceRecord / ReflectionCandidate types.

- [ ] Write tests proving active Projection + permission are required, URL and lineage are captured, and safe launch metadata is explicit.
- [ ] Run `npm run test:core:offline` and confirm RED because `browserSessions.ts` is missing.
- [ ] Implement the minimal persistent store and launch-plan helper.
- [ ] Run `npm run test:core:offline` and confirm GREEN.

### Task 2: Completion, abandon, and reflection handoff

**Files:**
- Modify: `app/src/core/browserSessions.ts`
- Modify: `app/tests/browser-sessions.test.mjs`

**Interfaces:**
- Produces: `complete()`, `abandon()`, `promoteReflection()` persistence semantics.

- [ ] Add failing tests for terminal lifecycle, non-empty completion summary, ExperienceRecord creation, pending candidate creation, and candidate promotion metadata.
- [ ] Run the tests and confirm RED for missing behavior.
- [ ] Implement minimal lifecycle methods.
- [ ] Run full core tests and confirm GREEN.

### Task 3: Arcade UI + App integration

**Files:**
- Modify: `app/src/App.tsx`
- Modify: `app/src/pages/ArcadePage.tsx`
- Modify: `app/src/styles.css`
- Modify: `app/src/data/capabilities.ts`
- Create/Modify tests: `app/tests/shell.test.mjs`, `app/tests/browser-sessions.test.mjs`

**Interfaces:**
- Consumes: active Projection, BrowserSessionStore, PostStore, EventStore.
- Produces: tracked launch, complete/abandon controls, experience promotion to local Board.

- [ ] Add a failing shipped-capability test requiring new Arcade browser-session actions.
- [ ] Wire store state and callbacks into `App.tsx`.
- [ ] Add Projection-aware tracked-session controls to `ArcadePage` while preserving legacy session UI.
- [ ] Record Browser / Experience actions through `appendActivity()`.
- [ ] Run core tests and offline TypeScript verification.

### Task 4: Freeze and handoff

**Files:**
- Modify: `README.md`, `CHANGELOG.md`, `HANDOFF.md`, `SNAPSHOT.json`, `validation/VERIFICATION.md`
- Generate: `CHECKSUMS.sha256`, FULL ZIP, verified GitHub deltas.

**Interfaces:**
- Produces: immutable v0.0.8 snapshot and reconstructible snapshot-first handoff.

- [ ] Attempt the live AI Board probe and networked npm install with explicit timeout; record actual result.
- [ ] Run fresh full core tests and offline TypeScript verification.
- [ ] Freeze the checksum manifest and verify it.
- [ ] Create FULL ZIP; clean-extract and re-run verifier/tests/typecheck.
- [ ] Build deltas from v0.0.7, apply with `--strip-components=1`, and require `app/ diff=0`.
- [ ] Byte-verify GitHub blobs before attaching to `main`.
