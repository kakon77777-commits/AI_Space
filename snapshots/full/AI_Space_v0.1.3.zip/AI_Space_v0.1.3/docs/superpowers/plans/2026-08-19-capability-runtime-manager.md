# Capability Runtime Manager Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build AI Space v0.0.5 so the mother shell can persist, observe, enable/disable, preview and invoke registered child capability providers through one operational Runtime Manager.

**Architecture:** Add a framework-independent `CapabilityRuntimeManager` above the existing validated providers/dispatch adapter. Persist only operational state through `StorageAdapter`; project operational events from `App.tsx`; render manager state through a native `/capabilities` page. AI Board remains a typed child adapter but delegates transport to the manager.

**Tech Stack:** TypeScript, React, browser `localStorage` through `StorageAdapter`, dependency-free Node test runner, existing Vite project.

**Spec:** `docs/superpowers/specs/2026-08-19-capability-runtime-manager-design.md`

## Global Constraints

- Do not expand source development onto GitHub; keep snapshot-first handoff.
- Do not mutate `CapabilityManifest.lifecycle` from runtime observations.
- Disabled providers must fail before network I/O.
- Preview must be side-effect free.
- Local Board and Remote AI Board remain separate data authorities.
- Do not add OAuth, Projection Runtime, background polling, or a second child provider in v0.0.5.

---

### Task 1: Runtime state and manager core

**Files:**
- Create: `app/src/core/capabilityRuntime.ts`
- Modify: `app/src/core/types.ts`
- Test: `app/tests/capability-runtime.test.mjs`

**Interfaces:**
- Consumes: `CapabilityProvider`, `CapabilityDispatchPlan`, `StorageAdapter`, `createDispatchPlan`, `executeApiDispatch`.
- Produces: `CapabilityRuntimeState`, `CapabilityRuntimeSnapshot`, `CapabilityRuntimeManager.register/list/get/setEnabled/probe/preview/invoke`.

- [x] Write failing tests for persisted registration, enable/disable, probe, preview, disabled invoke, success and failure observations.
- [x] Run `node --experimental-strip-types --test tests/*.test.mjs` and confirm RED from missing runtime implementation.
- [x] Implement the manager with storage key `ai-space.capability-runtime.v1`.
- [x] Rerun the full dependency-free suite and confirm GREEN.

### Task 2: Mother management route and UI

**Files:**
- Modify: `app/src/data/capabilities.ts`
- Modify: `app/tests/shell-model.test.mjs`
- Create: `app/src/pages/CapabilitiesPage.tsx`
- Modify: `app/src/components/ProviderCard.tsx`
- Modify: `app/src/styles.css`

**Interfaces:**
- Consumes: `CapabilityRuntimeSnapshot` and App callbacks.
- Produces: native `/capabilities` management surface.

- [x] Add a failing shell-model assertion for `/capabilities`.
- [x] Add the native capability metadata and confirm route GREEN.
- [x] Implement provider diagnostics, Probe, Enable/Disable, JSON action input, Preview and Invoke controls.
- [x] Add explicit React change-event types so offline TypeScript verification is deterministic.

### Task 3: Route AI Board through the Runtime Manager

**Files:**
- Modify: `app/src/core/aiBoard.ts`
- Modify: `app/tests/ai-board.test.mjs`
- Modify: `app/src/App.tsx`

**Interfaces:**
- Produces: `CapabilityInvoker(action, input)` seam in the typed AI Board adapter.
- App supplies `runtimeManager.invoke('child:ai-board', action, input)`.

- [x] Add a failing adapter test showing reads/writes can delegate to an injected capability invoker.
- [x] Implement the optional invoker seam without breaking the existing fetcher path.
- [x] Register AI Board into the Runtime Manager after manifest validation.
- [x] Route Remote Board read/write through the manager gate.
- [x] Project probe/toggle/invoke outcomes into shared Event History.

### Task 4: Verification and immutable snapshot

**Files:**
- Modify: `README.md`, `HANDOFF.md`, `CHANGELOG.md`, `SNAPSHOT.json`.
- Create: `docs/CAPABILITY_RUNTIME_MANAGER.md`.
- Modify: `validation/verify_snapshot.py`, `validation/VERIFICATION.md`.

- [x] Run the complete dependency-free Node test suite.
- [x] Run offline TypeScript verification.
- [x] Attempt the public AI Board health probe and record environment failure honestly if DNS is unavailable.
- [x] Attempt networked dependency installation under an explicit timeout; do not claim Vite build if dependencies cannot be installed.
- [x] Freeze all snapshot files, generate `CHECKSUMS.sha256`, and run the snapshot verifier.
- [x] Create and integrity-check the FULL ZIP.
- [x] Publish only compact byte-verified GitHub deltas and update the snapshot index.
