# AI Space v0.0.3 Capability Adapter Contract Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a stable machine-readable child capability contract and deterministic provider/dispatch layer to AI Space.

**Architecture:** Keep core capabilities local and authoritative. Add a pure TypeScript manifest validator + provider/dispatch module, load one static child manifest from `public/manifests`, and project it into Home diagnostics without copying child source or executing remote code.

**Tech Stack:** React 19, TypeScript, Vite, browser fetch for static manifest loading, dependency-free Node core tests.

**Spec:** `docs/superpowers/specs/2026-08-19-capability-adapter-contract-design.md`

## Global Constraints

- Snapshot-first development; GitHub receives only immutable handoff archives and indexes.
- No remote code execution, OAuth/OIDC, live API invocation, health polling, or Agent Projection runtime in v0.0.3.
- Child source code is never copied into the mother project.
- Manifest validation and dispatch planning must remain dependency-free and testable under Node TypeScript strip mode.
- Existing local Board remains the active Board surface in v0.0.3.

---

### Task 1: Manifest contract and validation

**Files:**
- Create: `app/src/core/capabilityAdapter.ts`
- Modify: `app/src/core/types.ts`
- Create: `app/tests/capability-adapter.test.mjs`

**Interfaces:**
- Produces: `CapabilityManifest`, `CapabilityProvider`, `validateCapabilityManifest(input)`, `manifestToProvider(manifest)`.

- [ ] Write failing tests for valid manifest, schema mismatch, mode requirements, and action validation.
- [ ] Run the focused test and verify RED because the adapter module does not exist.
- [ ] Implement minimal types and validator.
- [ ] Run the focused test and then all offline core tests GREEN.

### Task 2: Deterministic dispatch planning and registry collision rules

**Files:**
- Modify: `app/src/core/capabilityAdapter.ts`
- Modify: `app/src/core/registry.ts`
- Modify: `app/tests/capability-adapter.test.mjs`
- Modify: `app/tests/registry.test.mjs`

**Interfaces:**
- Produces: `createDispatchPlan(manifest, action, input?)`, `mergeCapabilities(core, discovered)`.

- [ ] Add failing tests for Link, Native, configured API, unconfigured API, undeclared actions, ID collision, and route collision.
- [ ] Run focused tests and verify RED for missing behavior.
- [ ] Implement minimal deterministic dispatch plan and collision checks.
- [ ] Run all offline core tests GREEN.

### Task 3: Machine-readable AI Board child manifest and shell discovery

**Files:**
- Create: `app/public/manifests/ai-board.capability.json`
- Create: `app/src/components/ProviderCard.tsx`
- Modify: `app/src/pages/HomePage.tsx`
- Modify: `app/src/App.tsx`
- Modify: `app/src/styles.css`
- Modify: `app/tests/capability-adapter.test.mjs`

**Interfaces:**
- App loads `/manifests/ai-board.capability.json`, validates it, stores `CapabilityProvider[]`, and passes providers to Home.
- Home displays provider ID/name/version/mode/lifecycle/health/source repository.

- [ ] Add a test that parses the shipped JSON manifest from disk and validates it.
- [ ] Run the test and verify RED until the manifest exists.
- [ ] Add the manifest and provider UI/load path.
- [ ] Run offline core tests and source typecheck.

### Task 4: Version documentation, immutable snapshot, and GitHub handoff

**Files:**
- Modify: `README.md`, `HANDOFF.md`, `CHANGELOG.md`, `SNAPSHOT.json`
- Modify: `docs/ARCHITECTURE.md`, `docs/CAPABILITY_MODEL.md`
- Add fresh validation evidence and checksums.

**Interfaces:**
- Snapshot version becomes `0.0.3`.
- GitHub receives only README/SNAPSHOTS updates and `snapshots/AI_Space_v0.0.3_Handoff.tar.xz`.

- [ ] Document contract boundaries and deferred functionality.
- [ ] Run fresh full offline test suite and typecheck.
- [ ] Generate immutable FULL ZIP and compact handoff archive.
- [ ] Verify checksums/archive integrity and Git blob byte equality before indexing GitHub.
