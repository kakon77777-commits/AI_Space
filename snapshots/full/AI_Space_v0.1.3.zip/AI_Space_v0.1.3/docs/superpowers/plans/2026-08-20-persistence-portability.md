# Persistence Portability / Backup–Restore Gate Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a versioned, validated, auditable AI Space state bundle that can export, dry-run, and safely restore browser-local runtime state.

**Architecture:** A pure portability module owns the fixed state-key allowlist, canonical checksum, parse/validate/export/preview/restore functions, and staging audit. It composes existing stores on a temporary MemoryStorageAdapter rather than teaching each domain store backup semantics. `/backup` is a thin UI over those APIs.

**Tech Stack:** TypeScript, React, existing StorageAdapter/domain stores, Node dependency-free tests.

**Spec:** `docs/superpowers/specs/2026-08-20-persistence-portability-design.md`

## Global Constraints
- Snapshot-first workflow; v0.1.1 is immutable base.
- No cloud sync, login, encryption, schema migration, or merge restore in v0.1.2.
- Export and restore only the explicit AI Space-owned key allowlist.
- Restore must validate checksum and staged hardening audit before target mutation.
- FNV-1a checksum must be documented as non-cryptographic.
- Prior tests must remain green.

---

### Task 1: Bundle format, export, checksum, structural validation
**Files:**
- Create: `app/src/core/statePortability.ts`
- Modify: `app/src/core/types.ts`
- Test: `app/tests/state-portability.test.mjs`

**Interfaces:**
- Produces `AI_SPACE_STATE_KEYS`, `exportAiSpaceStateBundle`, `validateAiSpaceStateBundle`, `parseAiSpaceStateBundle`.

- [ ] Write failing tests for exact key allowlist export, deterministic checksum, corruption rejection, and unsupported schema rejection.
- [ ] Run `npm run test:core:offline` and confirm only the new module tests fail for missing production API.
- [ ] Implement minimal bundle types/canonical checksum/export/validation.
- [ ] Re-run all offline core tests and require zero failures.

### Task 2: Dry-run and staged audited restore
**Files:**
- Modify: `app/src/core/statePortability.ts`
- Test: `app/tests/state-portability-restore.test.mjs`

**Interfaces:**
- Produces `previewAiSpaceStateRestore`, `validateAiSpaceStateRestore`, `restoreAiSpaceStateBundle`.

- [ ] Write failing tests proving preview has zero mutation, checksum/schema rejection occurs before mutation, invalid cross-store state fails staged audit, and unrelated keys survive restore.
- [ ] Run tests and confirm failures reflect missing restore APIs.
- [ ] Build staged MemoryStorage restore, instantiate current stores, run `auditAiSpaceState`, then commit allowlisted keys only when clean.
- [ ] Re-run full offline core suite.

### Task 3: Coherent MVP round-trip acceptance
**Files:**
- Test: `app/tests/state-portability-acceptance.test.mjs`

**Interfaces:**
- Consumes existing MvpJourneyRuntime and portability APIs.

- [ ] Write an end-to-end test that creates/completes a coherent MVP Journey, exports it, restores to fresh storage, recreates all stores, and requires Journey coherence plus zero hardening errors.
- [ ] Run RED if any portability gap is found.
- [ ] Make the smallest portability fix required.
- [ ] Re-run full offline suite.

### Task 4: `/backup` native surface
**Files:**
- Modify: `app/src/data/capabilities.ts`
- Modify: `app/src/core/registry.ts` only if route behavior requires it
- Create: `app/src/pages/BackupPage.tsx`
- Modify: `app/src/App.tsx`
- Modify: `app/src/styles.css`
- Test: `app/tests/registry.test.mjs`

**Interfaces:**
- Exposes backup export JSON, validation/dry-run, explicit restore action, and clear warnings.

- [ ] Add failing shipped-capability test for `/backup`.
- [ ] Add `backup` native capability/actions.
- [ ] Add BackupPage and App wiring using portability APIs; no duplicate persistence logic.
- [ ] Run full core suite and offline TypeScript source-check.

### Task 5: Freeze, clean-extract verification, and snapshot handoff
**Files:**
- Modify: `README.md`, `HANDOFF.md`, `CHANGELOG.md`, `SNAPSHOT.json`, verification docs.
- Create: `docs/STATE_PORTABILITY.md`.

- [ ] Document schema `1.0`, exact replace semantics, non-cryptographic checksum boundary, and deployment limitations.
- [ ] Fresh-run core tests and offline TypeScript verification.
- [ ] Probe live AI Board and npm install with the existing explicit timeout; run networked build only if dependencies become available.
- [ ] Generate immutable checksum manifest and FULL ZIP.
- [ ] Clean-extract the delivered ZIP and rerun verifier/tests/typecheck.
- [ ] Build compact GitHub delta handoff from v0.1.1 and require reconstruction `app/ diff=0`.
- [ ] Byte-verify each GitHub blob before attaching to `main`; keep root source-unexpanded.
