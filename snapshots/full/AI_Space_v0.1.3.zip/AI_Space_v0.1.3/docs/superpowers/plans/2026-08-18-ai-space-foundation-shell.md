# AI Space Foundation Shell v0.0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a locally developed, versioned AI Space Foundation Shell ZIP with registry-driven navigation, external resources, and persistent activity history.

**Architecture:** Framework-independent TypeScript domain modules implement capability resolution, resource validation/storage, and event history. A small React shell renders Home, Board, Arcade, Explore, and History without a routing dependency. GitHub receives only snapshot/handoff files after local verification.

**Tech Stack:** React 19.2.x, Vite 8.2.x, TypeScript, browser localStorage, Node built-in test runner for dependency-free core tests.

**Spec:** `docs/superpowers/specs/2026-08-18-ai-space-foundation-shell-design.md`

## Global Constraints
- One website; no sub-sites.
- No backend in v0.0.1.
- GitHub is snapshot/control-plane storage, not the live development surface.
- External links are untrusted and must be restricted to HTTP(S).
- Do not implement OAuth, Projection, Browser Agent, or AI Board API in this version.

---

### Task 1: Capability Registry Core

**Files:**
- Test: `app/tests/registry.test.mjs`
- Create: `app/src/core/types.ts`
- Create: `app/src/core/registry.ts`
- Create: `app/src/data/capabilities.ts`

**Interfaces:**
- `resolveCapability(capabilities, route): Capability | undefined`
- `getNavigationCapabilities(capabilities): Capability[]`

- [ ] Write failing tests for route resolution and navigation filtering.
- [ ] Run tests and confirm module-not-found failure.
- [ ] Implement the minimal registry core and seed capabilities.
- [ ] Run tests and confirm pass.

### Task 2: Event History Core

**Files:**
- Test: `app/tests/events.test.mjs`
- Create: `app/src/storage/storage.ts`
- Create: `app/src/core/events.ts`

**Interfaces:**
- `MemoryStorageAdapter`
- `EventStore.append(input): ActivityEvent`
- `EventStore.list(): ActivityEvent[]`
- `EventStore.clear(): void`

- [ ] Write failing tests for append, newest-first listing, persistence, and clear.
- [ ] Run tests and confirm module-not-found failure.
- [ ] Implement storage contract and event store.
- [ ] Run tests and confirm pass.

### Task 3: External Resource Core

**Files:**
- Test: `app/tests/resources.test.mjs`
- Create: `app/src/core/resources.ts`

**Interfaces:**
- `validateExternalUrl(url): string`
- `ResourceStore.add(input): ExternalResource`
- `ResourceStore.list(): ExternalResource[]`
- `selectGameResources(resources): ExternalResource[]`

- [ ] Write failing tests for HTTP(S) validation, rejection of unsafe protocols, persistence, and game filtering.
- [ ] Run tests and confirm module-not-found failure.
- [ ] Implement resource core.
- [ ] Run tests and confirm pass.

### Task 4: React Foundation Shell

**Files:**
- Create: `app/package.json`
- Create: `app/index.html`
- Create: `app/tsconfig.json`
- Create: `app/vite.config.ts`
- Create: `app/src/main.tsx`
- Create: `app/src/App.tsx`
- Create: `app/src/styles.css`
- Create focused UI components/pages under `app/src/components` and `app/src/pages`.

**Interfaces:**
- React UI consumes the core interfaces from Tasks 1–3 only.

- [ ] Add package/config files for Vite React TypeScript.
- [ ] Implement custom hash/path shell routing without react-router.
- [ ] Render registry-driven navigation and five approved surfaces.
- [ ] Wire Explore/Arcade actions into ResourceStore and EventStore.
- [ ] Type-check with the local dependency-free verification shim.

### Task 5: Handoff and Snapshot

**Files:**
- Create: `README.md`
- Create: `HANDOFF.md`
- Create: `CHANGELOG.md`
- Create: `docs/ARCHITECTURE.md`
- Create: `docs/CAPABILITY_MODEL.md`
- Create: `docs/GITHUB_WORKFLOW.md`
- Create: `SNAPSHOT.json`
- Create: `CHECKSUMS.sha256`
- Create: `validation/VERIFICATION.md`

- [ ] Document run/install instructions and current limitations.
- [ ] Run all dependency-free core tests.
- [ ] Run static/type verification available in this environment.
- [ ] Build snapshot manifest and checksums.
- [ ] Create `AI_Space_v0.0.1.zip`.
- [ ] Only after local verification, write minimal GitHub README / snapshot index and upload the ZIP snapshot.
