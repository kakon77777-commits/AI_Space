# Shared Space Context Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement persistent local Shared Space Runtime objects with memberships, active presences, resource references, and history projection, then bind Projection entry to those authoritative Spaces.

**Architecture:** Add one `spaces.ts` core module that persists Space, membership, presence, and ResourceRef records while reusing PrincipalStore, ResourceStore, and global EventStore as authorities. App runtime glue owns cross-store orchestration: Projection creation validates Space binding, Projection lifecycle updates Space presence, and Activity Events inherit active Space context.

**Tech Stack:** TypeScript, React, browser localStorage via StorageAdapter, Node built-in test runner with experimental strip-types.

**Spec:** `docs/superpowers/specs/2026-08-20-shared-space-context-design.md`

## Global Constraints
- GitHub remains snapshot-first and source-unexpanded.
- No remote federation or realtime synchronization.
- No second event database and no copied Resource objects.
- `shared` means local registered Principals only.
- Projection lifecycle and Browser Session boundaries from v0.0.7/v0.0.8 must remain compatible.
- TDD: every production behavior begins with a failing test.

---

### Task 1: Space persistence, membership, and built-ins
**Files:**
- Create: `app/tests/spaces.test.mjs`
- Create: `app/src/core/spaces.ts`
- Modify: `app/src/core/types.ts`

**Interfaces:**
- Produces: `SpaceStore`, `Space`, `SpaceMembership`, `SpacePresence`, `SpaceResourceRef`.

- [ ] Write failing tests for built-in seed idempotence, Space creation, owner membership, shared member addition, private-space rejection, owner-only governance, and owner removal rejection.
- [ ] Run `npm run test:core:offline` and verify only the new Space tests fail for missing implementation.
- [ ] Implement minimal Space/types persistence and membership rules.
- [ ] Run `npm run test:core:offline` and verify green.

### Task 2: Presence, resource refs, and history projection
**Files:**
- Modify: `app/tests/spaces.test.mjs`
- Modify: `app/src/core/spaces.ts`

**Interfaces:**
- Produces: `enterRoot`, `enterProjection`, `leave`, `getActivePresence`, `addResource`, `selectSpaceEvents`, `assertProjectionSpaceBinding`, `assertProjectionSpacePresence`.

- [ ] Write failing tests for root presence, one-presence invariant, Projection binding/presence, archive clearing presence, resource-ref access/duplicate prevention, and event filtering.
- [ ] Run tests and verify RED.
- [ ] Implement the minimal behavior.
- [ ] Run tests and verify GREEN.

### Task 3: Shipped Space capability and Projection creation constraint
**Files:**
- Modify: `app/tests/shell.test.mjs`
- Modify: `app/src/data/capabilities.ts`
- Modify: `app/src/pages/ProjectionsPage.tsx`

**Interfaces:**
- Produces: `/spaces` route and Projection Space selector constrained by root membership.

- [ ] Write failing shipped-route test for `/spaces`.
- [ ] Run tests and verify RED.
- [ ] Add the Space capability and update Projection creation UI to consume `spaces` + `memberships`.
- [ ] Run tests and verify GREEN.

### Task 4: Mother Runtime integration and Space UI
**Files:**
- Create: `app/src/pages/SpacesPage.tsx`
- Modify: `app/src/App.tsx`
- Modify: `app/src/components/ShellLayout.tsx`
- Modify: `app/src/styles.css`

**Interfaces:**
- Consumes: SpaceStore and current Principal/Projection/Event/Resource stores.
- Produces: Space create/member/enter/leave/archive/resource actions and active Space sidebar context.

- [ ] Add runtime glue that seeds built-ins and maintains Space state.
- [ ] Enforce Space binding before Projection creation and presence on Projection enter/return/suspend/archive.
- [ ] Resolve ActivityEvent.spaceId from explicit Space, active presence, or Projection lineage.
- [ ] Require active Projection Space presence for managed Projection child invoke and tracked Browser Session start.
- [ ] Render `/spaces` management surface and active Space context in Shell.
- [ ] Run full core tests and offline TypeScript verification.

### Task 5: Freeze and handoff
**Files:**
- Modify: `README.md`, `HANDOFF.md`, `CHANGELOG.md`, `SNAPSHOT.json`, `validation/VERIFICATION.md`
- Create/update: `docs/SHARED_SPACE_CONTEXT.md`, `CHECKSUMS.sha256`

**Interfaces:**
- Produces: immutable FULL ZIP plus byte-verified GitHub deltas.

- [ ] Run fresh core tests and offline TypeScript verification and save evidence.
- [ ] Record network/build limitations without claiming unavailable checks.
- [ ] Generate checksum manifest and verify immutable snapshot.
- [ ] Build FULL ZIP and clean-extract reverify tests/typecheck/manifest.
- [ ] Build small v0.0.9 deltas over v0.0.8, reconstruct with `--strip-components=1`, require `app/ diff=0`.
- [ ] Byte-verify GitHub blobs, update README/SNAPSHOTS, attach deltas, then read back `main`.
