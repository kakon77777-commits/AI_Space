# Projection Runtime Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build bounded Projection Principals with Space/scopes/lifecycle/event lineage and a deferred checkpoint/merge-candidate handoff.

**Architecture:** Extend Principal with `projection`, persist Projection metadata separately, and keep root lineage explicit. Reuse existing ContextSession and domain stores through the projection Principal ID. Enforce projection scope only at managed child-provider invocation in v0.0.7.

**Tech Stack:** React 19, TypeScript, Vite, browser StorageAdapter, dependency-free Node strip-types tests.

**Spec:** `docs/superpowers/specs/2026-08-20-projection-runtime-design.md`

## Global Constraints
- Snapshot-first development; GitHub remains source-unexpanded.
- Preserve all v0.0.6 data keys and compatibility.
- No automatic Merge/Reintegration.
- No nested projections.
- Existing domain `sessionId` semantics remain unchanged.

---

### Task 1: Projection Principal and Store
**Files:** Create `app/src/core/projections.ts`; modify `app/src/core/types.ts`, `app/src/core/principals.ts`; test `app/tests/projections.test.mjs`.

**Interfaces:** Produce `ProjectionStore`, `Projection`, `ProjectionCheckpoint`, `ProjectionMergeCandidate`, `projectionAllows`.

- [ ] Write tests for create/persist/root validation/scope normalization.
- [ ] Run them and confirm RED because Projection runtime is absent.
- [ ] Implement the minimal Principal/Projection types and persistence.
- [ ] Run full offline core suite.

### Task 2: Lifecycle and Handoff Boundary
**Files:** Modify `app/src/core/projections.ts`; test `app/tests/projections.test.mjs`.

**Interfaces:** `suspend`, `resume`, `archive`, `checkpoint`, `createMergeCandidate`.

- [ ] Add lifecycle/checkpoint/merge-candidate tests.
- [ ] Confirm RED.
- [ ] Implement valid transitions and terminal archive.
- [ ] Run full offline core suite.

### Task 3: Projection Event Lineage and Runtime Permission Gate
**Files:** Modify `app/src/core/types.ts`, `app/src/App.tsx`; test `app/tests/events.test.mjs`, `app/tests/projection-permissions.test.mjs`.

**Interfaces:** Event fields `projectionId`, `rootPrincipalId`, `spaceId`; deterministic `projectionAllows` gate before managed provider invoke.

- [ ] Add lineage and permission tests.
- [ ] Confirm RED where new behavior is missing.
- [ ] Implement minimal event context injection and provider invoke gate.
- [ ] Run full offline core suite.

### Task 4: Projection Surface
**Files:** Create `app/src/pages/ProjectionsPage.tsx`; modify `app/src/data/capabilities.ts`, `app/src/App.tsx`, `app/src/components/ShellLayout.tsx`, `app/src/styles.css`; test `app/tests/shell.test.mjs`.

**Interfaces:** `/projections` native route and callbacks for create/enter/return/lifecycle/checkpoint/merge-candidate.

- [ ] Add shipped-route test and confirm RED.
- [ ] Add Projection page and App wiring.
- [ ] Run full offline core suite and offline TypeScript verification.

### Task 5: Freeze and Handoff
**Files:** Update root docs/version metadata; regenerate validation, checksum manifest, FULL ZIP, verified GitHub deltas.

- [ ] Run fresh full offline tests.
- [ ] Run fresh offline TypeScript verification.
- [ ] Build immutable manifest and verify.
- [ ] Clean-extract FULL ZIP and re-run verifier/tests/typecheck.
- [ ] Create minimal reconstructible deltas and prove overlay `diff=0`.
