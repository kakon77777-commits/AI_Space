# State Authority + Migration Planner Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add v1.1 authoritative state bundles, explicit local lineage metadata, fail-closed migration planning, and safe bootstrap/fast-forward application while preserving v1.0 replace restore compatibility.

**Architecture:** Keep the existing 19-key domain-state allowlist unchanged. Add authority metadata in a separate local key and v1.1 bundle envelope. Build a pure planner that compares candidate authority to local authority, and an apply function that re-plans immediately, delegates domain restore to the existing staged-audit restore path, then transactionally commits authority metadata.

**Tech Stack:** TypeScript, browser-local StorageAdapter abstraction, React UI, dependency-free Node tests, offline TypeScript verification.

**Spec:** `docs/superpowers/specs/2026-08-20-state-authority-migration-design.md`

## Global Constraints

- Preserve all v0.1.2 behavior and v1.0 replace restore compatibility.
- Do not add cloud sync, accounts, realtime replication, automatic merge, or last-write-wins.
- Safe migration may apply only `bootstrap` and `fast-forward`.
- Recompute migration plan immediately before mutation.
- Preserve staged hardening audit and rollback guarantees.
- Keep GitHub snapshot-first/source-unexpanded.

---

### Task 1: Authority types + store + authoritative bundle v1.1

**Files:**
- Create: `app/src/core/stateAuthority.ts`
- Modify: `app/src/core/types.ts`
- Modify: `app/src/core/statePortability.ts`
- Test: `app/tests/state-authority.test.mjs`

**Interfaces:**
- Produces `STATE_AUTHORITY_KEY`, `StateAuthorityStore`, `exportAuthoritativeAiSpaceStateBundle`.
- Extends `AiSpaceStateBundleSchemaVersion` to `'1.0' | '1.1'` and adds optional v1.1 authority metadata.

- [ ] Write failing tests for first checkpoint, second checkpoint parent link, and authority-metadata checksum coverage.
- [ ] Run `npm run test:core:offline` and verify only new authority tests fail for missing behavior.
- [ ] Implement minimal authority store and v1.1 export while retaining v1.0 export/validation.
- [ ] Run full core tests to green.

### Task 2: Pure migration planner

**Files:**
- Create: `app/src/core/stateMigration.ts`
- Modify: `app/src/core/types.ts`
- Test: `app/tests/state-migration-plan.test.mjs`

**Interfaces:**
- Produces `planAiSpaceStateMigration(input, target)`.
- Returns relation, safeToApply, reason, local/candidate authority summaries.

- [ ] Write failing classification tests for equal/bootstrap/fast-forward/stale/diverged/foreign/legacy/untracked-local.
- [ ] Run full core tests and verify expected RED.
- [ ] Implement the pure planner with no mutation.
- [ ] Run full core tests to green.

### Task 3: Safe migration apply + rollback

**Files:**
- Modify: `app/src/core/stateMigration.ts`
- Test: `app/tests/state-migration-apply.test.mjs`

**Interfaces:**
- Produces `applyPlannedAiSpaceStateMigration(input, target, options)`.
- Reuses `restoreAiSpaceStateBundle` for audited domain restore.

- [ ] Write failing tests proving only bootstrap/fast-forward mutate target and rejected relations perform zero writes.
- [ ] Write failing rollback test with authority write failure after domain commit.
- [ ] Implement re-plan-before-write, capture/rollback, audited restore, and authority commit.
- [ ] Run full core tests to green.

### Task 4: End-to-end two-target migration acceptance

**Files:**
- Test: `app/tests/state-migration-acceptance.test.mjs`

**Interfaces:**
- Uses real Principal/Context/Projection/Space/Browser/MVP stores plus authority/migration APIs.

- [ ] Create coherent MVP state on target A and export authoritative rev1.
- [ ] Bootstrap rev1 into fresh target B and require 9/9 coherent + audit-clean.
- [ ] Mutate target A through a second coherent Journey/checkpoint, export rev2, fast-forward target B, recreate stores, and require coherent/audit-clean state.
- [ ] Run full core tests to green.

### Task 5: Backup UI authority/migration wiring

**Files:**
- Modify: `app/src/pages/BackupPage.tsx`
- Modify: `app/src/App.tsx`
- Modify: `app/src/styles.css`
- Modify: `app/src/data/capabilities.ts` only if action labels need expansion.

**Interfaces:**
- Backup page shows local authority summary and migration plan.
- Existing replace restore remains present and separate.
- Safe migration button is only enabled for safe relations.

- [ ] Add minimal UI contract test if registry/actions change.
- [ ] Wire authoritative export, migration preview, and safe apply through core APIs.
- [ ] Run core tests.
- [ ] Run offline TypeScript verification.

### Task 6: Docs, immutable snapshot, reconstruction

**Files:**
- Create: `docs/STATE_AUTHORITY_MIGRATION.md`
- Update: `README.md`, `HANDOFF.md`, `CHANGELOG.md`, `SNAPSHOT.json`, `validation/VERIFICATION.md`, `app/package.json`

- [ ] Document authority semantics, migration relation table, legacy compatibility, and non-goals.
- [ ] Run fresh core tests and offline TypeScript verification.
- [ ] Probe live AI Board and dependency install under explicit timeout; record actual environment result.
- [ ] Freeze checksum manifest and produce FULL ZIP.
- [ ] Clean-extract FULL ZIP and rerun verifier/tests/typecheck.
- [ ] Build compact GitHub handoff deltas/patches from v0.1.2, reconstruct with `app/ diff=0`, byte-verify Git blobs, update README/SNAPSHOTS, attach blobs to latest main, and read back metadata.
