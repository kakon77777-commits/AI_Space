# AI Space v0.1.0 First Coherent MVP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a resumable MVP Journey runtime that proves the existing AI Space spine works end-to-end.

**Architecture:** Add one integration layer that persists only cross-store references and derives coherence from existing authoritative stores. Add one guided `/mvp` surface. Preserve all v0.0.9 domain stores and safety boundaries.

**Tech Stack:** TypeScript, React, localStorage-compatible StorageAdapter, dependency-free Node core tests.

**Spec:** `docs/superpowers/specs/2026-08-20-first-coherent-ai-space-mvp-design.md`

## Global Constraints

- No browser automation or DOM observation.
- No automatic Projection Merge/Reintegration.
- Journey records contain references, not copied authoritative domain objects.
- Completed coherence must be derivable after store reload.
- Existing v0.0.9 behavior and tests must remain green.
- GitHub remains snapshot-first and source-unexpanded.

---

### Task 1: Journey data model and persistence

**Files:**
- Modify: `app/src/core/types.ts`
- Create: `app/src/core/mvpJourneys.ts`
- Test: `app/tests/mvp-journeys.test.mjs`

**Interfaces:**
- Produces: `MvpJourney`, `MvpJourneyStatus`, `MvpJourneyStore`.

- [ ] Write failing tests proving Journey create/update/persist/reload behavior and terminal-state rules.
- [ ] Run `npm run test:core:offline` and confirm only the new Journey tests fail because the implementation is missing.
- [ ] Implement the minimal Journey types/store.
- [ ] Re-run the full core suite and confirm green.

### Task 2: Pure coherence evaluator

**Files:**
- Modify: `app/src/core/mvpJourneys.ts`
- Test: `app/tests/mvp-coherence.test.mjs`

**Interfaces:**
- Produces: `MvpJourneySources`, `MvpJourneyStage`, `MvpJourneyEvaluation`, `evaluateMvpJourney(...)`.

- [ ] Write failing tests for a fully coherent completed chain.
- [ ] Write failing mismatch tests for wrong root/context/projection/space/resource/reflection lineage.
- [ ] Implement the evaluator as a pure function over store snapshots and active runtime IDs.
- [ ] Re-run the full core suite.

### Task 3: MVP Journey runtime orchestration

**Files:**
- Modify: `app/src/core/mvpJourneys.ts`
- Test: `app/tests/mvp-runtime.test.mjs`

**Interfaces:**
- Produces: `MvpJourneyRuntime` with `begin`, `startInteraction`, `completeInteraction`, `promoteReflection`, `finish`, `abandon`, `evaluate`.

- [ ] Write a failing end-to-end test using MemoryStorage and the real existing stores.
- [ ] Assert `begin` creates ContextSession + Projection + Space presence and makes the Projection active.
- [ ] Assert interaction completion creates Experience + pending reflection.
- [ ] Assert promotion creates Board lineage.
- [ ] Assert `finish` restores root, closes context, clears Projection presence, and yields coherent PASS after a fresh store reload.
- [ ] Implement the minimal orchestration and rerun the full suite.

### Task 4: Shipped MVP capability and guided surface

**Files:**
- Modify: `app/src/data/capabilities.ts`
- Create: `app/src/pages/MvpJourneyPage.tsx`
- Modify: `app/src/App.tsx`
- Modify: `app/src/components/ShellLayout.tsx`
- Modify: `app/src/styles.css`
- Test: `app/tests/shell.test.mjs`

**Interfaces:**
- Produces route `/mvp` and guided callbacks backed by `MvpJourneyRuntime`.

- [ ] Add a failing shipped-registry test for `/mvp`.
- [ ] Add the native capability with actions `LIST_MVP_JOURNEYS`, `START_MVP_JOURNEY`, `START_MVP_INTERACTION`, `COMPLETE_MVP_INTERACTION`, `PROMOTE_MVP_REFLECTION`, `FINISH_MVP_JOURNEY`, `ABANDON_MVP_JOURNEY`, `EVALUATE_MVP_JOURNEY`.
- [ ] Wire App state to the runtime and record Journey lifecycle events in EventStore.
- [ ] Add the guided page and coherence-stage UI.
- [ ] Run the full core suite and offline TypeScript verification.

### Task 5: Coherence documentation and release freeze

**Files:**
- Modify: `README.md`
- Modify: `HANDOFF.md`
- Modify: `CHANGELOG.md`
- Create: `docs/FIRST_COHERENT_MVP.md`
- Modify: `SNAPSHOT.json`
- Modify: `validation/VERIFICATION.md`

**Interfaces:**
- Produces the immutable v0.1.0 FULL snapshot and evidence.

- [ ] Update version metadata and describe the end-to-end acceptance path.
- [ ] Fresh-run full core tests and offline TypeScript verification.
- [ ] Attempt the existing bounded network/npm probes and record limitations without converting them into success claims.
- [ ] Generate and verify the immutable checksum manifest.
- [ ] Produce the FULL ZIP and clean-extract verify it.
- [ ] Produce compact GitHub deltas from v0.0.9, overlay them with `--strip-components=1`, and require `app/ diff=0`.
- [ ] Byte-verify Git blobs before attaching them to `main`.
