# AI Board Live Child Capability Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make AI Board the first independently deployed child capability that AI Space can actually invoke.

**Architecture:** Extend the generic Capability Manifest runtime with per-action HTTP bindings and a generic executor/health probe. Add a thin AI Board result normalizer and Board UI integration; keep the AI Board repository untouched.

**Tech Stack:** React 19, TypeScript, Vite, Node dependency-free tests.

**Spec:** `docs/superpowers/specs/2026-08-19-ai-board-live-child-design.md`

## Global Constraints

- Snapshot-first development; GitHub remains a compressed handoff/control plane.
- Do not edit `kakon77777-commits/ai-board`.
- Keep local Board behavior intact.
- External failures must not be recorded as successful actions.
- Preserve backward compatibility for manifests without action bindings.

---

### Task 1: HTTP action binding contract

**Files:**
- Modify: `app/src/core/types.ts`
- Modify: `app/src/core/capabilityAdapter.ts`
- Test: `app/tests/capability-adapter.test.mjs`

**Interfaces:**
- Produces `CapabilityActionBinding`, bound GET/POST dispatch plans, `executeApiDispatch`, and `probeCapabilityProvider`.

- [ ] Write failing tests for manifest action bindings, query dispatch, JSON dispatch, execution, and health probe.
- [ ] Run the targeted test and verify RED.
- [ ] Implement the minimal generic runtime support.
- [ ] Run the targeted test and verify GREEN.

### Task 2: AI Board child adapter

**Files:**
- Create: `app/src/core/aiBoard.ts`
- Modify: `app/public/manifests/ai-board.capability.json`
- Test: `app/tests/ai-board.test.mjs`

**Interfaces:**
- Produces typed `AiBoardMessage`, `listAiBoardMessages`, and `createAiBoardMessage`.

- [ ] Write failing tests against fake HTTP responses that match the child repository contract.
- [ ] Verify RED.
- [ ] Implement the normalizer and remote actions using the generic dispatcher.
- [ ] Verify GREEN.

### Task 3: Board UI live child integration

**Files:**
- Modify: `app/src/App.tsx`
- Modify: `app/src/pages/BoardPage.tsx`
- Modify: `app/src/pages/HomePage.tsx`
- Modify: `app/src/styles.css`

**Interfaces:**
- Consumes the AI Board provider and adapter from Tasks 1–2.
- Produces remote health/read/post UI while preserving local reflection features.

- [ ] Wire provider probe after manifest load.
- [ ] Add explicit remote refresh/post handlers with Event History writes on success.
- [ ] Add Remote AI Board panel and form.
- [ ] Update v0.0.4 copy/boundaries.
- [ ] Run all core tests and offline typecheck.

### Task 4: Snapshot freeze and handoff

**Files:**
- Modify: `README.md`, `HANDOFF.md`, `CHANGELOG.md`, `SNAPSHOT.json`
- Create/update validation artifacts and immutable archives outside the frozen source tree.

- [ ] Attempt networked dependency/build verification once and record the environment result.
- [ ] Run fresh  full dependency-free test suite.
- [ ] Run fresh offline TypeScript check.
- [ ] Generate immutable checksum manifest and verify it.
- [ ] Build FULL ZIP and verified GitHub handoff/delta.
- [ ] Update only AI_Space GitHub README/SNAPSHOTS/compressed artifact.
