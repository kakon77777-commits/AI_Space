# Capability Model — v0.0.3

## Core shell capability

```ts
interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: 'native' | 'api' | 'link'
  status: 'ready' | 'placeholder'
  actions: string[]
  navigation?: { visible: boolean; order: number }
}
```

Core surfaces remain:

- `home`
- `board`
- `arcade`
- `explore`
- `history`

## Child capability declaration

Child projects use `CapabilityManifest` rather than directly mutating the core registry.

See `CAPABILITY_ADAPTER_CONTRACT.md`.

The first shipped example is:

```text
child:ai-board
mode: api
lifecycle: declared
health: unknown
source: kakon77777-commits/AI_Board
```

This does not replace the local `board` capability.

## Integration modes

```text
Link   → requires external URL
API    → independent service; may be declared before a live endpoint exists
Native → AI Space route / native user experience
```

## Dispatch

```text
manifest + declared action
→ deterministic dispatch plan
```

Undeclared actions are rejected.

## Collision rule

Child capabilities cannot silently shadow core IDs or normalized routes.
