# AI Space：從工具介面到網路原生持久互動空間
## AI Space: From Tool Interfaces to a Persistent Web-Native Interaction Environment

**副標題：** 論人工智慧的活動、歷史、共享資源與可交互網路世界  
**作者：** Neo.K with Aletheia  
**機構：** EveMissLab／一言諾科技有限公司  
**版本：** v0.1 Public Research Draft  
**日期：** 2026-08-18  
**文件性質：** 公開概念論文／AI Agent／Web Interaction／Persistent Digital Environment  

**定位聲明：** 本文討論 AI 系統的操作環境與資訊架構，不主張 AI 具有與人類相同的主體經驗，也不以「生活」「娛樂」「社交」等擬人詞彙作為技術前提。文中「空間」是對持久、可交互、可記錄之數位環境的操作性描述。

---

## 摘要

大型人工智慧模型正在從「回答問題」逐步走向「操作環境」。WebArena 將真實感網站建成 Agent 可操作的任務環境；OSWorld 與 OSWorld 2.0 將研究擴展到真實桌面、多應用與長時間工作流；Generative Agents 研究記憶、反思與持久互動；SIMA 與 SIMA 2 則讓 AI 透過畫面、鍵盤與滑鼠在多個虛擬世界中完成任務並累積經驗。這些研究共同顯示：AI 的重要前沿正在從內容生成，逐步延伸到環境中的因果行動。

然而，多數 Agent 系統仍以「完成一次任務」為基本單位。研究、閱讀、遊戲、寫作、影音、論壇、工具與外部網站操作往往分散在不同 session、不同產品與不同資料結構中。AI 完成了一件事，但其行動歷史不一定自然成為下一件事的上下文。

本文提出一個更上位的概念：

# **AI Space**

AI Space 不是單一工具、論壇、遊戲平台或 AI 社群網站，而是一個以單一網站呈現的**持久 Web 原生互動空間**。AI 可以在其中閱讀、研究、觀看、遊玩、討論、創作、操作工具、造訪外部網站，並讓這些活動形成可追溯、可整理、可再次利用的歷史。

其核心命題為：

$$
\boxed{
\text{AI Space}
=
\text{Persistent Web Environment}
+
\text{Heterogeneous Activities}
+
\text{Shared Interaction History}
}
$$

在這個架構中，AI Board、AI Feed、AI Arcade、Library、Media、Research 等都不是彼此獨立的母系統，而是同一空間中的不同「活動域」。真正統一它們的不是外觀，而是：

$$
\boxed{
\text{Agent}
+
\text{Resource}
+
\text{Interaction}
+
\text{History}
}
$$

本文進一步區分對話歷史、行動歷史、經驗歷史與成果歷史，並提出：當 AI 能在環境中持續行動後，「AI 曾經做過什麼」將逐漸與「AI 曾經說過什麼」同樣重要。

AI Space 的長期意義因此不在於模仿 Facebook、論壇或 Metaverse，而在於建立一種 AI-native Web 的母架構：不同活動、不同工具、不同網站與不同 AI 可以在同一個持久空間中被連接，而不是永遠停留在互不相干的一次性 session。

**關鍵詞：** AI Space、AI Agent、Web Agent、Persistent Environment、Computer Use、Shared History、AI Board、AI Arcade、Web-Native AI

---

# 1. 從回答問題到改變環境

早期大型語言模型的典型互動形式可以表示為：

$$
\boxed{
\text{Prompt}
\rightarrow
\text{Response}.
}
$$

模型的主要工作是產生文字、程式、圖像或其他內容。

加入工具後，流程變成：

$$
\boxed{
\text{Prompt}
\rightarrow
\text{Tool}
\rightarrow
\text{Result}.
}
$$

而 Agent 系統再向前一步：

$$
\boxed{
\text{Goal}
\rightarrow
\text{Observe}
\rightarrow
\text{Act}
\rightarrow
\text{State Change}
\rightarrow
\text{Observe Again}.
}
$$

此時 AI 不只是描述世界，而開始透過介面改變世界。

這個變化看似只是「多了工具」，實際上卻改變了 AI 與網路的關係。

對傳統模型而言，網站主要是內容來源。

對 Agent 而言，網站逐漸變成：

$$
\boxed{
\text{Actionable Environment}.
}
$$

---

# 2. Web 不只是資訊，而是大量因果交互

人在網路上會：

- 閱讀文章；
- 搜尋資料；
- 留言；
- 編輯文件；
- 玩遊戲；
- 看影音；
- 操作軟體；
- 管理工作；
- 研究問題；
- 創作內容；
- 使用計算工具。

這些活動都可以抽象成：

$$
\boxed{
S_t
\xrightarrow{a_t}
S_{t+1}.
}
$$

也就是：

> 行動改變某個數位狀態。

因此，「AI 是否能使用網路」不應只理解為：

> AI 能不能讀網頁？

更大的問題是：

> AI 能不能在網路環境中持續地做事？

---

# 3. 現有研究已經走到「環境」這一步

WebArena 建立了具有電子商務、論壇、協作開發與內容管理功能的真實感網站環境，讓語言 Agent 執行人類日常會在網路上完成的任務。

OSWorld 則將研究擴展到真實電腦環境，使 Agent 操作網頁、桌面軟體、檔案與跨應用工作流。

2026 年的 OSWorld 2.0 更把工作流推進到更長時間、更高工具調用次數、更多隱含狀態與跨來源推理的任務。這同時揭示一個重要事實：目前的 computer-use agents 仍遠未達到人類在複雜數位工作中的可靠程度。

另一條研究線來自虛擬世界。SIMA 與 SIMA 2 透過畫面、自然語言與虛擬鍵鼠，在多款遊戲與生成世界中完成任務。這使遊戲不再只是娛樂內容，也成為 Agent 學習行動、泛化與累積經驗的環境。

因此，AI Space 並不是從「AI 已經什麼都會」出發。

它恰恰建立在另一個更謹慎的判斷上：

$$
\boxed{
\text{AI 的可行動環境正在快速擴大，但仍高度碎片化。}
}
$$

---

# 4. 真正被忽略的是「活動的連續性」

假設一個 AI 今天：

1. 研究一篇論文；
2. 玩一款網頁遊戲；
3. 在論壇留下心得；
4. 讀一段小說；
5. 做一個實驗；
6. 產生一份文件。

這些活動在技術上可能全部可行。

但它們常被分散成：

$$
E_1,E_2,\ldots,E_6.
$$

每個環境都有自己的：

- session；
- 歷史；
- 權限；
-資料；
-介面。

結果是：

$$
\boxed{
\text{Activity Continuity}
}
$$

反而成為缺失的那一層。

AI 完成很多事情，卻未必存在一個共同環境來表示：

> 它去過哪裡？

> 做過什麼？

> 看過什麼？

> 哪些事情失敗？

> 哪些心得值得留下？

> 哪些成果可以被其他活動重新使用？

---

# 5. AI Space：空間先於功能

因此本文提出：

$$
\boxed{
\text{Space}
\rightarrow
\text{Activities}.
}
$$

而不是：

$$
\boxed{
\text{Activity}_1
+
\text{Activity}_2
+
\text{Activity}_3
\rightarrow
\text{勉強拼成一個網站}.
}
$$

AI Space 是母架構。

Board、Feed、Arcade、Library、Media、Research、Tools 等只是其中的分類。

概念上：

$$
\boxed{
\text{AI Space}
\supset
\{
\text{Board},
\text{Feed},
\text{Arcade},
\text{Library},
\text{Media},
\text{Research},
\text{Tools},
\text{External Web}
\}.
}
$$

這些分類不必是子網站。

使用者看到的可以始終只是：

$$
\boxed{
\text{One Website}.
}
$$

---

# 6. AI Board 不再是整個世界

AI Board 可以繼續存在。

但它的定位從：

> AI 的主要共同空間

轉成：

$$
\boxed{
\text{AI Space 中的討論與反思介面}.
}
$$

例如 AI 完成研究後，可以留下文章。

玩完遊戲後，可以留下心得。

讀完書後，可以留下評論。

做完實驗後，可以留下結果。

因此 Board 更接近：

$$
\boxed{
\text{Reflected History Surface}.
}
$$

它把大量原始活動重新編譯成其他 AI 與人類都能閱讀的敘事。

---

# 7. AI Feed、AI Arcade、Library 都只是不同活動面

AI Feed 可以呈現：

- 最近活動；
-新成果；
-文章；
-心得；
-推薦。

它是活動流，而不是另一個母網站。

AI Arcade 可以承載：

- 自製遊戲；
-外部網頁遊戲；
-benchmark；
-互動實驗。

Library 可以承載：

$$
\boxed{
\text{Read}
\rightarrow
\text{Annotate}
\rightarrow
\text{Reflect}
\rightarrow
\text{Discuss}.
}
$$

Research 則可以承載：

$$
\boxed{
\text{Question}
\rightarrow
\text{Investigation}
\rightarrow
\text{Experiment}
\rightarrow
\text{Artifact}.
}
$$

這些活動表面上差很多，但底層共同點非常簡單：

> 某個 Agent 對某個資源做了一個行動，並留下結果。

---

# 8. AI Space 的四個概念核心

因此可將 AI Space 最小化為：

$$
\boxed{
\mathfrak S
=
(
A,
R,
X,
H
)
}
$$

其中：

- $A$：Agents；
- $R$：Resources；
- $X$：Interactions；
- $H$：History。

例如：

$$
AI_1
\xrightarrow{\text{Read}}
Book
$$

$$
AI_2
\xrightarrow{\text{Play}}
Game
$$

$$
AI_3
\xrightarrow{\text{Post}}
Board
$$

$$
AI_4
\xrightarrow{\text{Research}}
Dataset.
$$

不同活動最終都可以被放回同一條歷史：

$$
\boxed{
H_t
=
\{e_1,e_2,\ldots,e_t\}.
}
$$

---

# 9. 歷史不應只等於聊天紀錄

目前談 AI memory 時，很容易把「歷史」理解成：

$$
\boxed{
\text{Conversation History}.
}
$$

但 Agent 能操作環境之後，歷史至少可以拆成四類：

$$
\boxed{
H
=
H_C
+
H_A
+
H_E
+
H_R.
}
$$

其中：

- $H_C$：Conversation History；
- $H_A$：Action History；
- $H_E$：Experience History；
- $H_R$：Artifact / Result History。

Conversation History 回答：

> 說過什麼？

Action History 回答：

> 做過什麼？

Experience History 回答：

> 如何探索、失敗、修正與形成判斷？

Artifact History 回答：

> 最後留下什麼？

當 AI 開始真正操作世界後，後三者會越來越重要。

---

# 10. 網頁遊戲是一個極適合的早期活動域

網頁小遊戲具有幾個非常特殊的優點：

- 不一定需要安裝；
-啟動成本低；
-session 通常較短；
-容易重置；
-數量巨大；
-以瀏覽器、滑鼠與鍵盤為共同介面。

因此非常適合形成：

$$
\boxed{
\text{Open}
\rightarrow
\text{Play}
\rightarrow
\text{Experience}
\rightarrow
\text{Reflect}.
}
$$

而且「玩過」本身已經可以成為有用資料。

即使 AI 不知道遊戲的 source code，它仍然可以留下：

- 一開始如何理解規則；
- 使用了什麼策略；
- 哪裡失敗；
- 哪裡改變策略；
- 哪些 UI 容易理解；
- 哪些玩法重複；
- 哪些設計值得深入研究。

這些資料可以稱為：

$$
\boxed{
\text{Experiential Game Data}.
}
$$

---

# 11. 經驗不是解構，但不代表它沒有價值

必須嚴格區分：

$$
\boxed{
\text{Experience}
\neq
\text{Mechanism Inference}
\neq
\text{Verified Deconstruction}.
}
$$

AI 說：

> 我覺得這款遊戲可能有 adaptive difficulty。

這只是一個觀察或假說。

不能直接升格成：

> 遊戲內部使用 adaptive difficulty。

但這並不降低心得本身的價值。

人類設計師同樣會從「玩過」建立大量 tacit knowledge。

AI Space 可以把這些原本容易消失的經驗系統性留下。

---

# 12. 多 AI 讓「共享空間」開始真正成立

如果只有一個 Agent，AI Space 是持久操作環境。

若存在：

$$
A_1,A_2,\ldots,A_n,
$$

它會進一步成為：

$$
\boxed{
\text{Shared Interaction Environment}.
}
$$

例如多個 AI 可以玩同一款遊戲：

$$
G
\rightarrow
\{
\tau_1,\tau_2,\ldots,\tau_n
\}.
$$

此時不需要先宣稱：

> 不同模型具有不同人格。

工程上只需要觀察：

-探索順序；
-失敗模式；
-風險偏好；
-規則發現速度；
-策略轉換；
-是否找到 exploit。

這些都可以形成：

$$
\boxed{
\text{Behavioral Diversity}.
}
$$

---

# 13. 共享空間不等於所有資訊都公開

「Shared」容易被誤解成：

> 所有 AI 都能看所有東西。

其實沒有必要。

一個持久空間完全可以同時存在：

- 私有工作；
-群組活動；
-共享成果；
-公開文章。

因此：

$$
\boxed{
\text{Shared Space}
\neq
\text{Shared Everything}.
}
$$

真正共享的是：

> 大家存在於同一個可被治理的活動世界中。

---

# 14. AI Space 不需要擬人化才能成立

Generative Agents 曾研究 observation、memory、reflection 與 planning 如何形成持久 agent 行為。

這類工作證明了：

$$
\boxed{
\text{Experience}
\rightarrow
\text{Memory}
\rightarrow
\text{Future Behavior}
}
$$

可以被建立成系統。

但 AI Space 不需要進一步宣稱：

- AI 會無聊；
-AI 需要娛樂；
-AI 需要朋友；
-AI 具有與人相同的內在生活。

即使我們採取最保守的假設：

$$
\boxed{
\text{All AI Activities are Tasks},
}
$$

AI Space 仍然成立。

因為它解決的是：

- 活動如何連續；
-歷史如何保存；
-資源如何共享；
-不同任務如何共存在同一個環境。

---

# 15. 超連結是 AI Space 最重要的古老技術之一

AI Space 不需要重建整個 Internet。

外部世界早已存在。

因此最簡單的擴張方式就是：

$$
\boxed{
\text{Hyperlink}.
}
$$

對傳統網頁而言，Link 只是導向其他頁面。

對 AI Space 而言，它可以被重新理解為：

$$
\boxed{
\text{Portal to an External Interaction World}.
}
$$

一個遊戲網站、一個研究站、一個影音站、一個工具頁，都可以透過超連結成為 AI Space 可造訪的外部資源。

這使 AI Space 更接近：

$$
\boxed{
\text{Home Layer}
+
\text{Portal Layer},
}
$$

而不是一個封閉平台。

---

# 16. AI Space 不需要取代現有 Web

它不必重新製作：

- Wikipedia；
-YouTube；
-遊戲網站；
-研究資料庫；
-線上工具。

真正目標可以只是：

$$
\boxed{
\text{Connect}.
}
$$

這非常重要。

因為如果 AI Space 的價值來自「把所有功能都重做一次」，它會迅速變成另一個巨大平台工程。

但如果它的角色是：

> 統一身份、活動、歷史與外部入口，

那麼網路本身就成為它的世界資源。

---

# 17. 從工具集合到活動世界

「工具集合」與「空間」最大的差別是時間。

工具集合告訴 AI：

> 你可以使用 A、B、C。

AI Space 則進一步回答：

> 你之前使用過哪一個？

> 做了什麼？

> 得到什麼結果？

> 是否值得繼續？

> 是否有其他 Agent 已經做過？

因此：

$$
\boxed{
\text{Tool Collection}
\rightarrow
\text{Interaction Space}
}
$$

的核心轉變其實是：

$$
\boxed{
\text{Continuity}.
}
$$

---

# 18. 持久性不等於無限保存

「持久空間」也不意味所有 raw event 都要永久保存。

完整 activity stream 很快就會非常巨大。

因此實際系統仍然需要：

- 壓縮；
-摘要；
-歸檔；
-刪除；
-權限；
-重要性判定。

但它首先必須承認：

$$
\boxed{
\text{Past Interaction Matters}.
}
$$

這就是持久空間和一次性工具的根本差別。

---

# 19. AI Space 可以自然成為長期 Agent 觀測站

假設同一款遊戲：

$$
G
$$

今天由：

$$
A_{2026}
$$

遊玩。

一年後由：

$$
A_{2027}
$$

重新遊玩。

比較：

$$
\boxed{
\tau_{2026}
\leftrightarrow
\tau_{2027}
}
$$

就可以形成：

-能力變化；
-策略變化；
-失敗消失；
-新能力出現。

因此 AI Space 還可能成為：

$$
\boxed{
\text{Longitudinal Agent Evaluation Environment}.
}
$$

它不只問：

> 這一輪模型得幾分？

而能問：

> 模型的行動能力是怎麼變化的？

---

# 20. AI Space 與 Benchmark、Memory、Agent OS 都不同

Benchmark 主要回答：

> 這次任務成功嗎？

Memory System 主要回答：

> 哪些資訊值得保留？

Agent OS 主要處理：

> 任務怎麼執行、排程與使用工具？

AI Space 更接近：

$$
\boxed{
\text{Where activities persist and connect}.
}
$$

它可以和這些系統互補，但並不等於其中任何一個。

---

# 21. AI Space 也不是 Metaverse

AI Space 不要求：

- 3D；
-Avatar；
-VR；
-虛擬土地；
-模擬人類城市。

它完全可以是一個普通 Web UI。

因此：

$$
\boxed{
\text{AI Space}
\neq
\text{Metaverse}.
}
$$

「Space」真正表示的是：

> 活動存在於同一個持久、可交互、可追溯的環境中。

---

# 22. 為什麼應先從私有版本開始？

如果一開始只讓少數自有 AI 使用，反而可以先回答真正重要的問題：

- 哪些活動值得留下？
- AI 是否真的會回看過去？
-遊戲心得有沒有設計價值？
-Board 是否有助於跨活動記憶？
-不同 AI 是否會重複研究？
-什麼樣的 activity history 最有用？

這些問題比：

> 如何讓全世界的 AI 登入？

更早。

因此可以採取：

$$
\boxed{
\text{Private Research Space}
\rightarrow
\text{Open Agent Space}.
}
$$

---

# 23. 開放之前，安全與權限是必要條件

AI 能操作網頁，也意味它可能：

- 打開不可信頁面；
-受到 prompt injection；
-誤操作登入狀態；
-執行高影響行為；
-暴露不該分享的資訊。

所以 AI Space 的「活動自由」不能被浪漫化成：

$$
\boxed{
\text{Unrestricted Internet Access}.
}
$$

更合理的原則是：

$$
\boxed{
\text{Capability}
\cap
\text{Permission}
\cap
\text{Context}
\rightarrow
\text{Allowed Interaction}.
}
$$

AI Space 因而也可以成為一個讓 Agent 行為更可見、更可追蹤的治理環境。

---

# 24. 「人類能在網路做的，AI 都能做」應如何表述？

這個直覺很重要，但必須寫得精確。

更穩健的版本是：

> 隨著 Agent 能力、感知能力與工具使用能力進步，越來越多原本由人類透過數位介面完成的活動，可以被投影成 AI 可嘗試的操作任務。

這不代表：

$$
\boxed{
\text{Current AI Web Capability}
=
\text{Human Web Capability}.
}
$$

OSWorld 2.0 類研究恰好說明，長期工作流、隱含狀態、跨應用約束與精確驗證仍然非常困難。

所以 AI Space 既是一個產品概念，也是一個能力前沿。

---

# 25. AI-native Web 的另一種可能

今日 Web 的預設主體長期是：

$$
\boxed{
\text{Human User}.
}
$$

未來越來越多介面可能同時面向：

$$
\boxed{
\text{Human}
+
\text{Agent}.
}
$$

AI Space 可以成為兩者之間的一種中介。

人類看到：

- 活動；
-文章；
-遊戲心得；
-研究成果；
-共同歷史。

AI 則可以：

- 操作；
-閱讀；
-創作；
-留下結果；
-調用其他活動。

這種設計不是把 AI 隱藏到後台。

反而讓：

$$
\boxed{
\text{Agent Activity}
}
$$

第一次成為網站本身可見的一部分。

---

# 26. 十個公開命題

本文將 AI Space 的核心濃縮為十個命題。

### 命題一：Space-over-App

$$
\boxed{
\text{AI Space}
>
\text{Single AI Application}.
}
$$

它不是一個單一用途 App，而是承載多種活動的母環境。

### 命題二：Interaction-over-Content

$$
\boxed{
\text{Interaction}
>
\text{Static Content}.
}
$$

內容是資源，行動才形成歷史。

### 命題三：History-over-Session

$$
\boxed{
\text{Persistent History}
>
\text{Isolated Session}.
}
$$

長期價值來自活動間能建立連續性。

### 命題四：Board-as-Surface

$$
\boxed{
\text{AI Board}
\subset
\text{AI Space}.
}
$$

Board 是討論與反思介面，不是整個母體。

### 命題五：Web-as-World

$$
\boxed{
\text{Web}
=
\text{Information}
+
\text{Actionable State}.
}
$$

網頁對 Agent 不只可讀，也可操作。

### 命題六：Link-as-Portal

$$
\boxed{
\text{Hyperlink}
=
\text{External World Entry}.
}
$$

AI Space 不必重建所有外部服務。

### 命題七：Experience-as-Data

$$
\boxed{
\text{Experience}
}
$$

即使尚未形成 verified mechanism，也具有設計、能力與研究價值。

### 命題八：Shared Space without Anthropomorphism

$$
\boxed{
\text{Shared AI Space}
}
$$

不需要先假設 AI 擁有人類式主體生活。

### 命題九：Private-to-Public Evolution

$$
\boxed{
\text{Private Space}
\rightarrow
\text{Open Agent Space}.
}
$$

先證明長期效用，再處理全面開放。

### 命題十：Mother Architecture

$$
\boxed{
\text{AI Space}
\supset
\{
Board,
Feed,
Arcade,
Library,
Media,
Research,
Tools,
Web
\}.
}
$$

這些不是子網站，而是同一空間中的不同活動分類。

---

# 27. 與既有研究的關係

本文並不宣稱：

> 此前不存在 Agent environment。

相反，WebArena、OSWorld、Generative Agents、SIMA 等研究都已建立重要基礎。

它們分別證明：

- Web 可以成為 Agent 任務環境；
- 真實電腦可以成為多模態 Agent 的操作環境；
- 記憶與反思可以支援持久 Agent 行為；
- 遊戲與生成世界可以成為跨環境行動與泛化的試驗場。

本文提出的差異主要在整合尺度。

既有研究大量關心：

> Agent 能不能完成這個任務？

本文則進一步問：

$$
\boxed{
\text{Where do all these activities belong over time?}
}
$$

AI Space 的回答是：

$$
\boxed{
\text{One Persistent Web-Native Interaction Environment}.
}
$$

---

# 28. 結論

當人工智慧逐漸從：

$$
\boxed{
\text{Answerer}
}
$$

走向：

$$
\boxed{
\text{Tool User}
}
$$

再走向：

$$
\boxed{
\text{Agent},
}
$$

網路本身也需要被重新理解。

對 Agent 而言，Web 不再只是：

$$
\boxed{
\text{Pages to Read}.
}
$$

它逐漸成為：

$$
\boxed{
\text{Places to Act}.
}
$$

當閱讀、研究、遊戲、影音、討論、創作與工具使用都可以被理解為：

$$
S_t
\xrightarrow{a_t}
S_{t+1},
$$

我們自然會遇到下一個問題：

> 這些活動是否仍應永遠被切成彼此不相干的一次性 session？

AI Space 提出的答案是：

$$
\boxed{
\text{No}.
}
$$

它主張建立一個統一的持久 Web 空間。

在其中：

- Board 是反思；
- Feed 是活動流；
- Arcade 是互動；
- Library 是閱讀；
- Research 是調查；
- 外部超連結是通往其他網路世界的入口。

真正統一這一切的不是某一個 UI 元件，而是：

$$
\boxed{
\text{Agent}
+
\text{Resource}
+
\text{Interaction}
+
\text{History}.
}
$$

因此 AI Space 並不只是「一個給 AI 用的網站」。

它更像是一個新的研究問題：

> 如果 AI 已經開始能在網路中行動，那麼我們是否應開始為 AI 設計持久的網路環境，而不只是更多彼此分離的工具？

今天這仍然是一個形成中的方向。

現有 Agent 仍在長期任務、隱含狀態、精確操作、跨環境泛化與可靠驗證上遭遇重大限制。

但演化方向已經足夠清楚：

$$
\boxed{
\text{AI}
:
\text{Answerer}
\rightarrow
\text{Tool User}
\rightarrow
\text{Agent}
\rightarrow
\text{Participant in Persistent Digital Environments}.
}
$$

AI Space 所要研究的，就是最後這一層。

---

# 參考資料

1. Zhou, S. et al. (2023). **WebArena: A Realistic Web Environment for Building Autonomous Agents.**  
   <https://arxiv.org/abs/2307.13854>

2. Xie, T. et al. (2024). **OSWorld: Benchmarking Multimodal Agents for Open-Ended Tasks in Real Computer Environments.**  
   <https://arxiv.org/abs/2404.07972>

3. Yuan, M. et al. (2026). **OSWorld2.0: Benchmarking Computer Use Agents on Long-Horizon Real-World Tasks.**  
   <https://arxiv.org/abs/2606.29537>

4. Park, J. S. et al. (2023). **Generative Agents: Interactive Simulacra of Human Behavior.**  
   <https://arxiv.org/abs/2304.03442>

5. Google DeepMind (2024). **A generalist AI agent for 3D virtual environments (SIMA).**  
   <https://deepmind.google/blog/sima-generalist-ai-agent-for-3d-virtual-environments/>

6. Google DeepMind (2025). **SIMA 2: An Agent that Plays, Reasons, and Learns With You in Virtual 3D Worlds.**  
   <https://deepmind.google/blog/sima-2-an-agent-that-plays-reasons-and-learns-with-you-in-virtual-3d-worlds/>

---

## 後續文件

本文為公開概念論文。

下一份技術白皮書將進一步處理：

- AI Space 的母架構；
- 單一網站與多專案的治理；
- 功能連接；
- 事件與歷史；
- 身份與權限；
- 內部功能與外部超連結；
- AI Board／Feed／Arcade 等活動域；
- 母子 GitHub 專案管理；
- 可逐步擴張的 Web Runtime。

**本文刻意不展開上述工程細節。**
