# Projection Runtime v0.0.7

## Purpose

Projection Runtime gives one persistent Root Principal a bounded presence inside a declared Space without copying the Root's full authority or memory.

## Data model

```text
Projection
  id
  principalId
  rootPrincipalId
  spaceId
  role?
  status
  permissionScope[]
  memoryScope[]
  mergePolicy
  timestamps
```

The corresponding Projection Principal is stored in the normal Principal registry with `type = projection` and `ownerId = rootPrincipalId`.

Generic Principal creation rejects `type=projection`; ProjectionStore is the authority for creating a valid Projection Principal + Projection record pair.

## Lifecycle

```text
active -> suspended
suspended -> active
active|suspended -> archived
archived -> terminal
```

Records are retained; v0.0.7 has no delete operation.

## Permission grammar

```text
capabilityId:ACTION
capabilityId:*
*:*
```

The guard runs before `CapabilityRuntimeManager.invoke(...)` transport.

A suspended or archived Projection never passes `projectionAllows`.

## Memory scope

`memoryScope` is declarative metadata. It can name summaries/categories such as:

```text
paper-index
recent-checkpoints
arcade-strategy-summary
```

No raw Root memory is copied automatically.

## Event lineage

Projection actions may record:

```text
principalId       = Projection Principal
projectionId      = Projection record
rootPrincipalId   = Root Principal
spaceId           = bounded Space label
contextSessionId  = optional AI Space ContextSession
sessionId         = optional domain session (for example Arcade)
```

This preserves both Root lineage and local activity lineage.

## Checkpoint / merge-candidate boundary

Checkpoint:

```text
projectionId
summary
createdAt
```

Merge candidate:

```text
projectionId
checkpointId?
status = pending
```

These records are handoff objects only. They do not mutate the Root Principal or Root memory in v0.0.7.

## Known governance boundary

Projection permission enforcement currently covers managed child-provider invocation. Local-native action RBAC, provider administration RBAC, and general policy/risk evaluation are deferred.
