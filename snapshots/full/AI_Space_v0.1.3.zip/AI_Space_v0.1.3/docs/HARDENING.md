# AI Space v0.1.1 Hardening

v0.1.1 does not add a new product surface. It hardens the v0.1.0 coherent MVP with four defenses:

1. **Pure invariant audit** — detects orphan/cross-store/cross-Space damage without mutation.
2. **Derived-state cleanup** — removes only provably stale Space presence and missing-resource refs; authoritative domain data is never auto-deleted.
3. **Shared Projection runtime guard** — tracked browser, MVP interaction, and managed child invoke share active + permission + real Space-presence enforcement.
4. **Journey recovery** — reconciles uniquely provable Experience/Candidate/Post references, resumes reload-interrupted active Journeys, or explicitly abandons irrecoverable active Journeys.

## Recovery boundary

Recovery never fabricates an Experience, reflection, Principal, Projection, Space, or completed Journey. A reference is backfilled only when the authoritative store contains a unique lineage-consistent object.

## Cleanup boundary

Safe cleanup may remove only derived state that is invalid by current authoritative state:
- stale or cross-Space presences;
- presences in missing/archived Spaces;
- Projection presences without active binding/root membership;
- Space resource refs whose canonical Resource no longer exists.

## Acceptance

The hardening acceptance test deliberately corrupts persisted MVP state, then runs audit → cleanup → reference reconciliation → resume → fresh-store reload → re-audit. The recovered active Journey must have zero audit errors and remain coherent.
