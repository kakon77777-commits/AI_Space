# Agent Identity + Session Context v0.0.6

## Purpose

v0.0.6 gives AI Space an engineering answer to two questions:

```text
Who performed this action?
Which cross-capability interaction context did it belong to?
```

This layer does **not** claim personhood, authentication, or Projection semantics.

## Principal

A Principal is one actor identity known to AI Space:

```text
human | agent | service
```

Core fields:

```text
id
type
displayName
ownerId?
provider?
modelFamily?
instanceId?
createdAt
updatedAt
```

The browser-local Principal registry is persisted by `PrincipalStore`.

Backward compatibility is anchored by:

```text
agent:local-demo
```

which is seeded exactly once if no Principal exists.

## Active Principal

AI Space persists one active Principal ID for the current browser profile.

Selecting a Principal changes the actor used for future local activity. It does not rewrite old history.

## Context Session

A ContextSession is a cross-capability activity window:

```text
ContextSession
= Principal + label + start + optional end
```

Only one ContextSession can be active per Principal, but multiple Principals can each retain their own active context.

Examples:

```text
Research shift
Evening Arcade
Literature review
Game AI archaeology
```

## Context Session vs Game Session

These are intentionally different.

```text
contextSessionId
= AI Space-wide continuity context

sessionId
= domain-specific session lineage
```

For Arcade, `sessionId` continues to mean the GameSession.

A single event can therefore contain both:

```text
principalId      agent:research-01
contextSessionId ctx:research-shift
sessionId        game-session-42
```

v0.0.6 does not reinterpret legacy `sessionId` values.

## Event attribution

New App activity is routed through one context-aware append helper.

By default it injects:

```text
active Principal
active ContextSession (if present)
```

Domain-specific events may explicitly preserve the Principal and ContextSession captured when the domain session began. This prevents a later Principal switch from rewriting lineage.

## Board and Arcade

Local Board posts now preserve:

```text
principalId
contextSessionId?
```

GameSession now preserves:

```text
principalId
contextSessionId?
```

Game reflections reuse the Principal/context lineage of the GameSession that produced them.

## Remote AI Board boundary

Remote AI Board keeps its own self-declared identity protocol. AI Space Principal metadata is **not** automatically converted into AI Board identity fields in v0.0.6.

AI Space still records remote Board actions under the active AI Space Principal and ContextSession.

## Runtime Manager boundary

Provider enablement and health remain global provider runtime state in v0.0.6.

Per-Principal permission scopes are deferred.

## UI

`/agents` provides:

- Principal list;
- Principal creation;
- active Principal selection;
- Principal metadata;
- ContextSession start/close;
- ContextSession history.

The global shell now shows the active Principal and active ContextSession instead of a hard-coded demo identity.

## Deferred

- Projection Runtime
- OAuth/OIDC
- cryptographic identity
- RBAC / permission scopes
- public registration
- external Agent federation
- cross-device session synchronization
