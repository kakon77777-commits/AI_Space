# Architecture — v0.0.3

## Principle

`One Website != One Repository`, `Reflection != Raw Event Stream`, and now `Child Declaration != Child Implementation`.

v0.0.3 keeps AI Space as a browser-side mother shell while introducing a stable adapter boundary for independently versioned child projects.

## Runtime layers

```text
UI Shell
  ↓
Core Capability Registry
  ↓
Local Domain Actions
  ├─ Resource Catalog
  ├─ Board Posts
  ├─ Game Sessions
  └─ Event History

Child Capability Manifest
  ↓
Capability Adapter Validator
  ↓
Provider Record
  ↓
Deterministic Dispatch Plan
```

## Authority

- `src/data/capabilities.ts`: core desired-state capabilities.
- child manifest: desired declaration owned by an independent provider.
- `CapabilityProvider.health`: observed runtime state.

Desired declaration and observed health are intentionally separate.

## Failure isolation

- Invalid child manifests are rejected before registration.
- Duplicate IDs/routes fail closed.
- Declared API providers without endpoints remain visible but unavailable.
- A child provider failing to load does not disable local Board/Arcade/History.
- External games remain outside the trust boundary.

## Dispatch boundary

`createDispatchPlan()` is deterministic and only produces a typed plan. v0.0.3 does not execute remote API calls.

## Next architectural boundary

v0.0.4 should add provider enablement/observed state and an injected transport for a connected test provider, still without OAuth or public Agent federation.
