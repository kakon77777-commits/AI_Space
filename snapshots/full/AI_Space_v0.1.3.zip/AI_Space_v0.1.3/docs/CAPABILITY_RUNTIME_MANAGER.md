# Capability Runtime Manager v0.0.5

## 1. Purpose

The Capability Manifest answers:

> What capability is declared, what actions does it expose, and how should it be dispatched?

The Runtime Manager answers:

> Is that provider operationally enabled now, what was last observed, and what happens when the mother runtime probes or invokes it?

The two layers intentionally remain separate.

## 2. State model

```text
Desired / declarative state
CapabilityManifest
- id
- version
- lifecycle
- actions
- runtime bindings

Observed / operational state
CapabilityRuntimeState
- capabilityId
- enabled
- health
- lastProbeAt
- lastInvokeAt
- lastLatencyMs
- lastSuccessAt
- lastError
```

No probe or invocation rewrites the Manifest.

## 3. Persistence

The browser-local v0.0.5 implementation stores operational state through the existing `StorageAdapter` under:

```text
ai-space.capability-runtime.v1
```

This is deliberately small. It stores observations/gates, not child domain data.

## 4. Register

```ts
register(provider: CapabilityProvider): CapabilityRuntimeSnapshot
```

Registration:

1. indexes the provider by manifest ID;
2. restores any persisted runtime state;
3. otherwise initializes `enabled=true` and uses the provider's current declared/observed health as the initial value;
4. persists the normalized runtime state.

Registration does not probe the network by itself.

## 5. Enable / Disable

```ts
setEnabled(capabilityId: string, enabled: boolean): CapabilityRuntimeSnapshot
```

`enabled` is an operational gate, not a manifest edit.

The invariant is:

```text
invoke(disabled provider)
→ reject
→ zero fetch calls
```

This turns capability management into enforceable runtime behavior rather than presentation-only UI.

## 6. Probe

```ts
probe(capabilityId: string): Promise<CapabilityRuntimeSnapshot>
```

Using `runtime.baseUrl + runtime.healthPath`:

```text
2xx        → healthy
non-2xx    → degraded
transport  → offline
no health  → unknown
```

The manager records observation time, elapsed latency, and error where applicable.

Probe does not require the provider to be enabled, because diagnostics and invocation permission are different concerns.

## 7. Preview

```ts
preview(capabilityId: string, action: string, input?: unknown): CapabilityDispatchPlan
```

Preview delegates to the existing deterministic capability adapter. It must not execute `fetch` or mutate runtime observations.

This lets humans/agents inspect the exact planned URL/method/body before execution.

## 8. Invoke

```ts
invoke(capabilityId: string, action: string, input?: unknown)
```

v0.0.5 invokes API plans only:

```text
Require provider registered
→ require enabled
→ build deterministic plan
→ require plan.kind == api
→ execute
→ update observed runtime state
→ return typed result or rethrow error
```

Success records:

```text
health = healthy
lastInvokeAt
lastSuccessAt
lastError = undefined
```

Failure records:

```text
HTTP error      → degraded
transport error → offline
lastInvokeAt
lastError
```

## 9. Event projection

The manager itself is deliberately UI/framework independent. `App.tsx` projects user-visible operations into the shared Event Store:

```text
PROVIDER_PROBED
PROVIDER_ENABLED
PROVIDER_DISABLED
PROVIDER_INVOKED
PROVIDER_INVOKE_FAILED
```

This keeps operational history in the same cross-capability timeline without coupling the core manager to one EventStore implementation.

## 10. AI Board gate

The AI Board adapter preserves its typed domain API, but now accepts a `CapabilityInvoker` seam.

Therefore:

```text
Remote Board UI
→ typed AI Board adapter
→ CapabilityRuntimeManager.invoke
→ generic HTTP executor
→ AI Board
```

The local Board remains independent. Runtime health/status is not copied into Board domain state.

## 11. `/capabilities`

The native management page is a Runtime projection, not a second truth store. It renders snapshots returned by the manager and provides:

- Provider diagnostics;
- Probe;
- Enable/Disable;
- action selection;
- JSON input;
- Preview;
- Invoke;
- output/error rendering.

## 12. Limits

v0.0.5 deliberately does not implement:

- policy/permission scopes;
- Agent Principal identity;
- secret/credential delegation;
- scheduled probe loops;
- install/uninstall of arbitrary third-party providers;
- Link/native execution through the Runtime Manager;
- distributed runtime-state persistence.

Those should be added only after the current state split remains stable under additional providers.
