# AI Space v0.1.0 — First Coherent MVP

v0.1.0 is the first release whose primary goal is **coherence rather than subsystem growth**.

## Canonical Journey

```text
Root Principal
→ ContextSession
→ bounded Projection
→ real Space presence
→ Arcade Capability / existing Resource
→ tracked BrowserSession boundary
→ explicit ExperienceRecord
→ pending ReflectionCandidate
→ promoted local BoardPost
→ Return Root
→ close ContextSession
→ coherence PASS after reload
```

## Journey authority

`MvpJourney` is an integration index. It stores stable IDs only. The source of truth remains the existing store that owns each object.

| Concern | Authority |
|---|---|
| Principal | `PrincipalStore` |
| Context | `ContextSessionStore` |
| Projection | `ProjectionStore` |
| Space / membership / presence | `SpaceStore` |
| Capability | shipped capability registry / runtime manager |
| Resource | `ResourceStore` |
| tracked external interaction | `BrowserSessionStore` |
| Experience | `ExperienceRecord` in `BrowserSessionStore` |
| Reflection promotion | `ExperienceReflectionCandidate` + `PostStore` |
| history | global `EventStore` |
| cross-store references | `MvpJourneyStore` |

The Journey never copies those domain objects.

## Nine coherence gates

`evaluateMvpJourney()` derives these stages every time it is called:

1. Root Principal
2. Context Session
3. Projection
4. Space
5. Capability / Resource
6. Tracked Interaction
7. Experience
8. Reflection
9. Return / Close

An active Journey may have `pending` future stages. Any inconsistent existing lineage is `fail`.

A completed Journey is accepted only when all nine stages are `pass`.

## Runtime semantics

`MvpJourneyRuntime.begin()` creates exactly one dedicated ContextSession and one bounded Projection, enters that Projection into an existing member Space, switches active Principal to the Projection, and persists the Journey references.

The Projection gets only the minimum browser-boundary permission used by this MVP:

```text
arcade:START_BROWSER_SESSION
```

`startInteraction()` uses the existing browser-boundary runtime. `Tracked != Observed` remains unchanged.

`completeInteraction()` requires explicit Experience text.

`promoteReflection()` creates a local Board post with BrowserSession / Resource / Context lineage.

`finish()` refuses to run while any pre-return coherence stage is not `pass`; it then clears Projection Space presence, restores Root, closes the ContextSession, marks the Journey completed, and immediately re-evaluates the full chain.

## Reload proof

The core acceptance test completes a full Journey, reconstructs every store object from the same persistent StorageAdapter, and re-runs coherence evaluation. Completion is not accepted merely because one in-memory orchestrator instance says it succeeded.

## Explicit non-goals

v0.1.0 does **not** add:

- autonomous browser control;
- DOM / click / screenshot observation;
- automatic Projection Merge/Reintegration;
- public Space federation;
- realtime multi-user synchronization;
- OAuth/OIDC or delegated credentials.

Those remain later layers. v0.1.0 first proves that the existing AI Space spine forms one persistent loop.
