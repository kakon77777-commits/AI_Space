# AI Space v0.1.3 — State Authority + Migration Contract

## Why this exists

v0.1.2 made AI Space state portable. Portability alone does not answer which of two portable states is allowed to replace the other. v0.1.3 introduces explicit state-lineage authority so future cloud or multi-device transports do not default to last-write-wins.

## Local authority record

Stored separately at:

```text
ai-space.state-authority.v1
```

It contains:

```text
lineageId
revision
headChecksum
stateFingerprint
updatedAt
```

`lineageId` identifies a logical state lineage, not a user or device identity. `revision` is a monotonic explicit checkpoint number. `headChecksum` identifies the last authoritative bundle checkpoint. `stateFingerprint` fingerprints only the 19 managed AI Space domain-state entries.

The authority key is intentionally outside the 19-key domain payload allowlist. v1.1 bundles carry authority metadata in their envelope so a restored/migrated target can reconstruct authority without pretending authority itself is ordinary domain data.

## Bundle versions

### Schema 1.0

Legacy v0.1.2 bundle. It has no lineage authority metadata. It remains valid for explicit replace restore.

### Schema 1.1

Adds:

```text
authority.lineageId
authority.revision
authority.parentChecksum
authority.stateFingerprint
```

The v1.1 checksum covers authority metadata in addition to app metadata and the 19 domain-state entries.

FNV-1a remains accidental-corruption detection only. It is not authentication, encryption, or a cryptographic trust signature.

## Authoritative checkpoint export

`exportAuthoritativeAiSpaceStateBundle` is an explicit checkpoint operation.

- first export creates revision 1;
- later exports keep the same lineage and increment revision;
- each later bundle stores `parentChecksum` equal to the previous authoritative head;
- local authority is persisted only after the bundle checksum has been constructed.

Repeated export of unchanged state still creates a new revision in v0.1.3. Checkpoint deduplication is intentionally deferred.

## Migration planner

| Relation | Meaning | Safe apply? |
|---|---|---:|
| `equal` | candidate already equals local authoritative head | no-op |
| `bootstrap` | target is empty/untracked and can adopt v1.1 lineage | yes |
| `fast-forward` | same lineage; candidate is exactly local revision + 1 and parent=head | yes |
| `stale` | candidate is same-lineage but not newer | no |
| `diverged` | same lineage but candidate is not a provable direct child | no |
| `foreign` | candidate belongs to another lineage | no |
| `legacy` | schema 1.0; no authority lineage | no |
| `untracked-local` | target has managed state but no authority record | no |

Only `bootstrap` and `fast-forward` are safe-to-apply migrations.

## Apply semantics

`applyPlannedAiSpaceStateMigration` recomputes the plan immediately before mutation. UI preview is never trusted as authorization.

For safe relations:

1. validate bundle checksum/schema;
2. run v0.1.2 staged invariant audit;
3. capture all 19 domain keys and the authority key;
4. restore audited domain state;
5. commit candidate authority metadata;
6. roll back both domain and authority state if authority commit fails.

No merge or conflict resolution is performed.

## Explicit replace escape hatch

`replaceAiSpaceStateBundleWithAuthority` remains available for a deliberate operator choice:

- v1.1 replace adopts the candidate lineage/head;
- v1.0 replace clears local authority because the imported bundle has no lineage proof.

This is intentionally distinct from safe migration and is visibly separated in `/backup`.

## Future cloud/multi-device consequence

A future transport can exchange bundles or checkpoints, but it should call this planner before state adoption. The transport does not decide authority. That separation allows later providers (cloud store, local NAS, peer replica, account sync) to remain interchangeable while the Mother Runtime keeps state-adoption policy.
