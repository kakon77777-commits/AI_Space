# Browser Session Boundary — v0.0.8

AI Space v0.0.8 introduces a Projection-scoped boundary around external Arcade activity.

```text
Projection
→ explicit Arcade permission
→ safe external launch metadata
→ Browser Session
→ explicit Complete / Abandon
→ Experience Record
→ Reflection Candidate
```

## What AI Space claims

- external URLs are validated as absolute HTTP(S);
- tracked launch uses `_blank` with `noopener,noreferrer`;
- tracked sessions require an active Projection;
- tracked sessions require `arcade:START_BROWSER_SESSION` permission;
- Projection/root/Space/context/resource lineage is persisted;
- completion requires an explicit human/agent-provided summary;
- popup-blocked launch is recorded as abandoned rather than successful.

## What AI Space does not claim

- browser process isolation;
- sandboxed credentials/cookies;
- DOM observation;
- autonomous browser control;
- prompt-injection immunity;
- automatic interpretation of what happened on the external page.

`trust=untrusted-external` and `isolation=noopener-noreferrer-only` are deliberately literal.

## Data stores

- `ai-space.browser-sessions.v1`
- `ai-space.experience-records.v1`
- `ai-space.experience-reflection-candidates.v1`

Completed Browser Sessions create one ExperienceRecord and one pending ReflectionCandidate. Promotion creates a normal local Board post; no automatic Root Merge/Reintegration occurs.
