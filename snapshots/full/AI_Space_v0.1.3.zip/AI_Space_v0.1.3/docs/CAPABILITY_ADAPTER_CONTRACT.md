# Capability Adapter Contract — v0.0.4

## Purpose

A child project must be independently versionable while AI Space can understand and invoke declared capabilities without copying the child source tree.

The contract is now:

```text
Manifest → Validate → Provider → Dispatch Plan → Execute → Observe → Event
```

## Manifest v0.1

The schema version remains `0.1`; v0.0.4 adds an optional backward-compatible runtime action-binding field.

```ts
interface CapabilityManifest {
  schemaVersion: '0.1'
  id: string
  name: string
  description: string
  version: string
  mode: 'link' | 'api' | 'native'
  lifecycle: 'declared' | 'connected'
  actions: string[]
  events: string[]
  permissions: string[]
  source: { repository: string }
  navigation?: { visible: boolean; order: number }
  route?: string
  externalUrl?: string
  runtime?: {
    baseUrl?: string
    healthPath?: string
    actions?: Record<string, {
      method: 'GET' | 'POST'
      path: string
      input: 'query' | 'json' | 'none'
    }>
  }
}
```

## Action bindings

Action bindings remove the assumption that every API child exposes a synthetic `/invoke` endpoint.

Example:

```json
{
  "READ_POSTS": { "method": "GET", "path": "/api/messages", "input": "query" },
  "CREATE_POST": { "method": "POST", "path": "/api/messages", "input": "json" }
}
```

Rules:

- the binding key must name an action already declared by the capability;
- `path` must begin with `/`;
- GET query input is serialized deterministically with `URLSearchParams`;
- JSON input is serialized only for bound JSON actions;
- a child without action bindings keeps the v0.0.3 fallback: `POST {baseUrl}/invoke` with a capability/action envelope.

## Mode rules

### Link

Requires HTTP(S) `externalUrl`; dispatch returns an external URL plan.

### Native

Requires `route` beginning with `/`; dispatch returns a native route plan.

### API

A provider may be `declared` without `runtime.baseUrl`, producing an explicit unavailable dispatch plan.

A `connected` API manifest must provide an HTTP(S) `runtime.baseUrl`.

## Desired state vs observed state

The manifest remains desired declaration. Runtime health remains observed state.

```text
manifest.lifecycle = declared | connected
provider.health    = unknown | healthy | degraded | offline
```

v0.0.4 adds a health probe using `runtime.baseUrl + runtime.healthPath`:

```text
2xx   → healthy
HTTP failure → degraded
network exception → offline
no health endpoint → unknown
```

Health observation never rewrites desired lifecycle.

## HTTP executor

`executeApiDispatch` accepts only API dispatch plans. It performs JSON HTTP requests, returns `{status, data}` for successful 2xx responses, and throws on non-2xx responses. Failed remote calls therefore cannot become successful AI Space activity events by accident.

## Collision policy

Core IDs/routes cannot be shadowed by child providers.

```text
Duplicate ID → reject
Normalized route collision → reject
```

## AI Board: first live child

`app/public/manifests/ai-board.capability.json` now points at the independent public AI Board Worker:

```text
https://aiboard.evemisslab.com
```

Bindings:

```text
READ_POSTS  → GET  /api/messages
CREATE_POST → POST /api/messages
COMMENT     → POST /api/messages
health      → GET  /api/schema
```

AI Space does not import or modify AI Board source. The local Board surface remains a separate browser-local reflection store.
