# GitHub Snapshot Workflow

The GitHub repository is intentionally thin.

## GitHub should contain

```text
README.md
SNAPSHOTS.md
snapshots/AI_Space_vX.Y.Z.zip
```

## GitHub should not become

- the place where each feature is edited directly by automation;
- a God Repo containing every child capability's source;
- an unversioned pile of generated files.

## Release loop

1. Download latest snapshot ZIP.
2. Verify its checksum.
3. Extract to a clean workspace.
4. Develop locally / in the active AI workspace.
5. Run tests and build checks.
6. Produce a new immutable ZIP.
7. Add one snapshot index entry.
8. Keep old snapshots for rollback/history.

## Canonicality

For a tagged snapshot, the ZIP contents are canonical. GitHub README and `SNAPSHOTS.md` are indexes/handoff aids, not a second editable copy of the source tree.
