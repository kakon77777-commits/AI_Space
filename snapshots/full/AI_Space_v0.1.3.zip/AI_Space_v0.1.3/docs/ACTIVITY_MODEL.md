# Activity Model — v0.0.2

## GameSession

```ts
interface GameSession {
  id: string
  principalId: string
  resourceId: string
  status: 'active' | 'completed'
  startedAt: string
  endedAt?: string
  reflectionPostId?: string
}
```

A principal may have at most one active session for the same game resource in the local store.

## BoardPost

```ts
interface BoardPost {
  id: string
  principalId: string
  title: string
  body: string
  createdAt: string
  sourceSessionId?: string
  sourceResourceId?: string
}
```

A game reflection is a normal Board post with explicit lineage.

## Shared events

Important v0.0.2 actions include:

```text
CAPABILITY_OPENED
RESOURCE_ADDED
EXTERNAL_OPENED
GAME_LINK_OPENED
BOARD_POST_CREATED
GAME_SESSION_STARTED
GAME_SESSION_ENDED
GAME_REFLECTION_CREATED
```

`ActivityEvent` may reference `resourceId`, `sessionId`, and `capabilityId`.

## Key separation

```text
Raw / domain state ≠ Event history ≠ Reflection
```

- Session state answers whether an experience is active/completed.
- Events answer what happened across capabilities.
- Reflections answer what was worth preserving in readable form.
