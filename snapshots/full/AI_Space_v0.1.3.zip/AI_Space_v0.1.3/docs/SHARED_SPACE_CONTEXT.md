# AI Space v0.0.9 — Shared Space Context

## Purpose

v0.0.9 promotes `spaceId` from a free-form lineage label into an authoritative persistent local runtime object.

```text
Space
├─ Root Principal memberships
├─ active Principal / Projection presences
├─ references to canonical ResourceStore resources
└─ history projection from the global ActivityEvent store
```

The Space layer does **not** duplicate Resource or Event truth.

## Stable built-in Spaces

The local runtime seeds these stable IDs idempotently under `agent:local-demo`:

- `research`
- `arcade`
- `board`
- `library`

These IDs preserve compatibility with earlier Projection `spaceId` conventions.

## Membership

- Owner must be a non-Projection Principal.
- Creation adds owner membership automatically.
- Only owner may add/remove members or archive.
- `private` means owner-only membership.
- `shared` means multiple registered local root Principals may join.
- Projection Principals do not receive membership rows; their Root membership + Projection binding authorizes Space presence.

`shared` does not mean public, networked, authenticated federation, or realtime collaboration.

## Presence

A Principal can hold at most one active Space presence.

Root Principal entry requires membership. Projection entry requires:

1. active Projection,
2. existing active bound Space,
3. Root Principal membership in that Space.

Projection Enter creates Space presence. Return/Suspend/Archive removes it. Space archive clears every presence in that Space.

## Projection binding

New Projection creation in the Mother Runtime now validates that the target Space exists, is active, and contains the Root Principal as a member. `/projections` therefore selects from eligible Spaces rather than accepting an arbitrary free-text `spaceId`.

Low-level legacy Projection rows remain readable. A legacy Projection whose target Space is missing cannot be entered until the Space is made valid.

## Shared resources

Space resource sharing stores only `SpaceResourceRef`:

```text
SpaceResourceRef -> resourceId -> ResourceStore
```

No Resource body/title/URL is copied into Space storage. Duplicate `(spaceId, resourceId)` refs are rejected.

## Shared history

There is no Space event ledger. Space history is:

```text
selectSpaceEvents(globalEvents, spaceId)
```

`appendActivity` resolves Space lineage in this order:

1. explicit `spaceId`,
2. active Space presence,
3. Projection lineage fallback,
4. no Space.

This preserves one global causal history while allowing Space-local views.

## Runtime enforcement

When the active Principal is a Projection:

- managed child-provider invocation requires active presence in the Projection's bound Space,
- tracked Browser Session start requires the same presence,
- Projection permissions from v0.0.7 still apply independently.

Thus:

```text
Projection permission AND Projection Space presence
```

are both required before these bounded actions proceed.

## Deferred

- remote Space federation,
- realtime presence synchronization,
- multi-user websocket collaboration,
- distributed locking / conflict resolution,
- public membership discovery,
- cryptographic membership identity,
- Space-native separate databases.
