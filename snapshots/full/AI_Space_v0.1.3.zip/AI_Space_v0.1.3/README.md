# AI Space v0.1.3 — State Authority Contract + Migration Planner

AI Space v0.1.3 adds the control-plane rule that portability was missing: **which state is allowed to replace which other state**.

The coherent runtime spine remains:

```text
Principal -> ContextSession -> Projection -> Space -> Capability
-> Interaction -> Experience -> Reflection -> Persist -> Return
```

v0.1.3 extends persistence into explicit checkpoint lineage:

```text
portable domain state
-> authoritative checkpoint
-> lineage / revision / parent-head
-> migration relation
-> safe bootstrap or direct fast-forward only
-> staged audit
-> transactional apply
```

Key properties:
- legacy State Bundle schema 1.0 remains valid for explicit replace restore;
- new schema 1.1 bundles carry portable authority metadata;
- local authority lives separately at `ai-space.state-authority.v1`;
- planner classifies `equal / bootstrap / fast-forward / stale / diverged / foreign / legacy / untracked-local`;
- safe apply only accepts `bootstrap` and provable direct `fast-forward`;
- no last-write-wins, automatic merge, or history-gap guessing;
- migration plan is recomputed immediately before mutation;
- authority commit failure rolls back both restored domain state and authority metadata;
- explicit replace remains available and authority-aware;
- two-target acceptance proves A rev1 -> B bootstrap -> A rev2 -> B fast-forward while preserving 9/9 MVP coherence and audit-clean state;
- `/backup` now shows local authority and migration relation alongside the existing destructive replace escape hatch.

See `docs/STATE_AUTHORITY_MIGRATION.md`, `HANDOFF.md`, and `validation/VERIFICATION.md`.
