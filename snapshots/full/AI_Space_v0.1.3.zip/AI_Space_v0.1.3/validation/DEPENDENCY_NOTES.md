# Dependency / network notes

For v0.1.3 the build container could not resolve `aiboard.evemisslab.com` (`curl` exit 6). A fresh `npm install --no-audit --no-fund` attempt was terminated by the explicit 25-second timeout (`exit 124`).

The dependency-free core suite and offline TypeScript source verification are the verified executable gates in this snapshot. Run networked install/test/typecheck/build before deployment.
