# AI Space v0.1.3 Handoff

Base: v0.1.2 Persistence Portability / Backup–Restore Gate.

v0.1.3 introduces state-lineage authority and a fail-closed migration planner. It does not add cloud transport, accounts, realtime multi-device sync, automatic merge, cryptographic identity, or last-write-wins.

Key files:
- `app/src/core/stateAuthority.ts` — local authority record validation/store.
- `app/src/core/stateMigration.ts` — pure planner, safe apply, transactional rollback, explicit authority-aware replace.
- `app/src/core/statePortability.ts` — v1.1 authoritative bundle export plus v1.0 compatibility.
- `app/src/pages/BackupPage.tsx` — authority/migration UI over the same core APIs.
- `app/tests/state-authority.test.mjs` — checkpoint lineage tests.
- `app/tests/state-migration-plan.test.mjs` — relation classification tests.
- `app/tests/state-migration-apply.test.mjs` — safe apply/rejection/rollback/replace tests.
- `app/tests/state-migration-acceptance.test.mjs` — two-target bootstrap + fast-forward coherent MVP acceptance.
- `docs/STATE_AUTHORITY_MIGRATION.md` — semantics and future transport boundary.

Safe migration rule:
1. validate schema/checksum;
2. classify against current local authority;
3. allow only bootstrap or exact direct fast-forward;
4. recompute plan immediately before mutation;
5. run staged hardening audit;
6. capture domain + authority state;
7. restore domain state;
8. commit authority metadata;
9. rollback both if authority commit fails.

Explicit replace is not safe migration. v1.1 replace adopts candidate authority; v1.0 replace clears local authority.
