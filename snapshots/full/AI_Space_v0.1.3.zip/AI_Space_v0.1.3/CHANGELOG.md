# Changelog

## v0.1.3 — State Authority Contract + Migration Planner

- Added local `StateAuthorityStore` metadata.
- Added authoritative State Bundle schema 1.1 while retaining schema 1.0 compatibility.
- Added explicit checkpoint lineage/revision/parent-head metadata.
- Added pure migration relation planner.
- Added fail-closed safe migration restricted to bootstrap/direct fast-forward.
- Added transactional domain + authority rollback.
- Added authority-aware explicit replace restore.
- Added two-target bootstrap/fast-forward coherent MVP acceptance.
- Extended `/backup` with local authority and safe migration plan/apply UI.
- No cloud transport, realtime sync, automatic merge, or last-write-wins.
