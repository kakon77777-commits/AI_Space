# Dependency Notes — 2026-08-18

Selected current package lines for the snapshot manifest:

- React `19.2.8`
- React DOM `19.2.8`
- Vite `8.2.0`
- `@vitejs/plugin-react` `6.0.5`
- Vitest `4.1.10`
- TypeScript `7.0.2`

Vite's official guide states the current Node compatibility floor as Node `20.19+` or `22.12+`.

The execution container has Node `22.16.0` and global TypeScript `5.8.3`, but cannot resolve `registry.npmjs.org`, so dependencies were not installed in-container. Core tests use Node's TypeScript strip mode; source static checking uses an explicit offline React shim. A real `npm install && npm run build` remains required after handoff.
