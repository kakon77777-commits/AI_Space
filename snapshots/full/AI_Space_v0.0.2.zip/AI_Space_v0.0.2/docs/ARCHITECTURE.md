# Architecture — v0.0.2

## Principle

`One Website != One Repository` and `Reflection != Raw Event Stream`.

v0.0.2 remains a browser-side mother shell. It proves that multiple activity surfaces can share identity-shaped local state and one event history while keeping their domain records separate.

## Runtime layers

```text
UI Shell
  ↓
Capability Registry
  ↓
Domain Actions
  ├─ Resource Catalog
  ├─ Board Posts
  ├─ Game Sessions
  └─ Event History
  ↓
StorageAdapter
  ↓
localStorage
```

## Domain boundaries

- `ResourceStore`: external things AI Space can open.
- `SessionStore`: explicit game experience lifecycle; references Resource IDs.
- `PostStore`: compact human/agent-readable reflections; may reference Session/Resource lineage.
- `EventStore`: cross-capability `who did what` history. It does not replace domain stores.

## Authority

`src/data/capabilities.ts` remains the local desired-state registry for this snapshot. Runtime UI is a projection of it.

## Failure isolation

External games are still outside the trust boundary. Losing an external page does not invalidate the AI Space event/session records already written locally. Clearing History does not delete Resources, Posts, or Sessions.

## Next architectural boundary

v0.0.3 should stop adding local domain features and introduce a stable adapter/manifest boundary for independent child repositories.
