# Capability Model — v0.0.2

```ts
interface Capability {
  id: string
  label: string
  description: string
  route: string
  mode: 'native' | 'api' | 'link'
  status: 'ready' | 'placeholder'
  actions: string[]
  navigation?: { visible: boolean; order: number }
}
```

## Current capabilities

- `home` — ready/native
- `board` — ready/native; local `CREATE_POST`
- `arcade` — ready/native; game catalog/session/reflection actions
- `explore` — ready/native; external HTTP(S) resource catalog
- `history` — ready/native; shared event projection

## Board status change

Board is no longer a placeholder UI. It now provides a **local reflection store** only. This does **not** mean the existing independent AI Board project has been copied or integrated. A future adapter can replace/bridge the local provider while preserving the surface contract.

## Arcade actions

```text
LIST_GAMES
OPEN_GAME
START_GAME_SESSION
END_GAME_SESSION
WRITE_GAME_REFLECTION
```

## Integration modes

The technical whitepaper defines `Link | API | Native`. v0.0.2 still implements native shell surfaces and link resources. API/child-repo capability discovery remains deferred to v0.0.3.
