# Dependency notes — v0.1.2

The frozen dependency-free core suite and offline TypeScript source verification pass without installing npm packages.

A fresh `npm install --no-audit --no-fund` was attempted with an explicit 25-second timeout and exited 124 in this build container. The public AI Board hostname probe also failed at DNS resolution (`curl` exit 6).

Therefore the network-installed Vitest suite and Vite production build were not run in this container. Before deployment, use a normally networked machine and run:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
