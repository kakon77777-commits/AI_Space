# Changelog

## 0.1.2 — 2026-08-20

- Added `AiSpaceStateBundle` schema `1.0` and an exact AI Space-owned state-key allowlist.
- Added deterministic FNV-1a accidental-corruption fingerprinting with explicit non-cryptographic semantics.
- Added structural parse/validation and unsupported-schema fail-closed behavior.
- Added zero-side-effect restore preview.
- Added isolated staged restore into `MemoryStorageAdapter` followed by the v0.1.1 hardening audit.
- Added replace-only restore that leaves unrelated localStorage untouched.
- Added rollback if a target StorageAdapter throws during commit.
- Added coherent MVP Journey export/restore/reload acceptance.
- Added first-class `/backup` native surface for export, download, validation/dry-run, and explicit restore/reload.
- Preserved all v0.1.1 hardening and product safety boundaries.
