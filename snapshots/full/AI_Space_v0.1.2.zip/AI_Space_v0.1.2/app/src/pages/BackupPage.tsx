import { useState } from 'react'
import type { AiSpaceStateRestorePreview } from '../core/types.ts'

export interface BackupPreviewResult {
  preview: AiSpaceStateRestorePreview
  warningCount: number
  sourceVersion: string
  createdAt: string
}

interface BackupPageProps {
  onExport: () => string
  onPreview: (text: string) => BackupPreviewResult
  onRestore: (text: string) => void
}

function downloadBundle(text: string): void {
  const blob = new Blob([text], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `ai-space-state-${new Date().toISOString().replace(/[:.]/g, '-')}.json`
  link.click()
  URL.revokeObjectURL(url)
}

export function BackupPage({ onExport, onPreview, onRestore }: BackupPageProps) {
  const [text, setText] = useState('')
  const [preview, setPreview] = useState<BackupPreviewResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  function generate(): void {
    try {
      const value = onExport()
      setText(value)
      setPreview(null)
      setError(null)
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : String(caught))
    }
  }

  function validate(): void {
    try {
      setPreview(onPreview(text))
      setError(null)
    } catch (caught) {
      setPreview(null)
      setError(caught instanceof Error ? caught.message : String(caught))
    }
  }

  function restore(): void {
    try {
      onRestore(text)
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : String(caught))
    }
  }

  return (
    <section className="backup-page">
      <div className="hero backup-hero">
        <div>
          <p className="eyebrow">Persistence portability</p>
          <h1>Backup / Restore</h1>
          <p>Export only AI Space-owned local state into a versioned bundle, validate it in an isolated staging store, then explicitly replace the AI Space state in this browser.</p>
        </div>
        <div className="backup-boundary card">
          <strong>Boundary</strong>
          <p>The bundle fingerprint is FNV-1a for accidental corruption detection. It is <b>not</b> a cryptographic signature, encryption, or proof that a bundle is trustworthy.</p>
          <p>Restore never touches unrelated localStorage keys.</p>
        </div>
      </div>

      <div className="backup-actions card">
        <div className="action-row">
          <button onClick={generate}>Generate bundle JSON</button>
          <button className="secondary" disabled={!text.trim()} onClick={() => downloadBundle(text)}>Download JSON</button>
          <button className="secondary" disabled={!text.trim()} onClick={validate}>Validate / Dry-run</button>
        </div>
        <label>
          <span>State bundle JSON</span>
          <textarea value={text} onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => { setText(event.target.value); setPreview(null); setError(null) }} rows={18} spellCheck={false} placeholder="Generate a bundle here, or paste an AI Space state bundle to validate and restore." />
        </label>
        {error ? <div className="error-banner">{error}</div> : null}
      </div>

      {preview ? (
        <div className="backup-preview card">
          <div>
            <p className="eyebrow">Staged audit passed</p>
            <h2>Restore preview</h2>
            <p>Source {preview.sourceVersion} · {preview.createdAt}</p>
          </div>
          <div className="backup-metrics">
            <div><strong>{preview.preview.created}</strong><span>created</span></div>
            <div><strong>{preview.preview.changed}</strong><span>changed</span></div>
            <div><strong>{preview.preview.cleared}</strong><span>cleared</span></div>
            <div><strong>{preview.preview.unchanged}</strong><span>unchanged</span></div>
            <div><strong>{preview.warningCount}</strong><span>audit warnings</span></div>
          </div>
          <div className="backup-restore-warning">
            <strong>Replace semantics</strong>
            <p>This replaces or clears the fixed AI Space-owned state-key allowlist. It does not merge identities or histories. After commit, AI Space reloads from the restored state.</p>
            <button className="danger-lite" onClick={restore}>Restore AI Space state & reload</button>
          </div>
        </div>
      ) : null}
    </section>
  )
}
