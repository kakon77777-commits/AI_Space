# AI Space v0.1.2 Handoff

Base: v0.1.1 MVP Hardening / Audit.

v0.1.2 is the persistence portability release. It does not add cloud sync, account identity, encrypted backup, multi-device replication, merge import, or automatic cross-schema migration.

Key files:
- `app/src/core/statePortability.ts` — canonical 19-key allowlist, State Bundle schema 1.0, checksum, parse/validate, dry-run, staged audit, restore and rollback.
- `app/src/pages/BackupPage.tsx` — thin UI over portability APIs.
- `app/tests/state-portability*.test.mjs` — format, restore safety, and coherent MVP round-trip acceptance.
- `docs/STATE_PORTABILITY.md` — contract and operational boundaries.

Important restore rule:
1. validate schema/checksum/entry set;
2. parse serialized JSON entries;
3. stage into fresh memory storage;
4. recreate existing stores and run `auditAiSpaceState`;
5. reject on any audit error;
6. preview target changes without mutation;
7. replace only allowlisted AI Space keys;
8. rollback allowlisted keys if target commit throws;
9. reload the app so all stores are recreated from restored state.

Do not treat `fnv1a32` as authentication. A maliciously modified bundle can recompute that checksum. Security signing/encryption is a future layer, not part of v0.1.2.
