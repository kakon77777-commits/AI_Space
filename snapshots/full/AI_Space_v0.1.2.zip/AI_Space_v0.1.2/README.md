# AI Space v0.1.2 — Persistence Portability / Backup–Restore Gate

AI Space v0.1.2 makes the browser-local runtime portable without adding cloud sync or changing the existing domain-store authority model.

Core spine remains:

```text
Principal -> ContextSession -> Projection -> Space -> Capability
-> Interaction -> Experience -> Reflection -> Persist -> Return
```

v0.1.2 upgrades `Persist` with a versioned local State Bundle:

```text
AI Space-owned StorageAdapter keys
-> State Bundle schema 1.0
-> deterministic accidental-corruption fingerprint
-> structural validation
-> isolated staged restore
-> v0.1.1 hardening audit
-> dry-run preview
-> rollback-safe replace restore
-> reload
```

Key properties:
- exact 19-key AI Space allowlist; unrelated browser localStorage is never exported or modified;
- FNV-1a 32-bit fingerprint detects accidental changes but is **not** a cryptographic signature or trust proof;
- unsupported bundle schema versions fail closed;
- import is staged in a fresh `MemoryStorageAdapter` and rejected if the hardening auditor reports errors;
- restore uses explicit replace semantics for AI Space-owned keys only; merge semantics are deferred;
- a target write failure triggers rollback to the pre-restore allowlisted state;
- a full coherent MVP Journey can round-trip into fresh storage and remain 9/9 coherent after all stores are recreated;
- `/backup` provides export JSON, file download, validate/dry-run, and explicit Restore & Reload.

See `docs/STATE_PORTABILITY.md`, `HANDOFF.md`, and `validation/VERIFICATION.md`.
