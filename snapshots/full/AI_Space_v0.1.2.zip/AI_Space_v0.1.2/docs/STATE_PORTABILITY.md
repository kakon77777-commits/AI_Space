# AI Space State Portability v0.1.2

## Purpose

AI Space is browser-local in the current MVP. Persistence that exists only inside one browser profile is not enough for a durable runtime, so v0.1.2 introduces a portable, versioned state-transfer boundary before cloud sync or federation.

## State Bundle schema 1.0

```ts
interface AiSpaceStateBundle {
  schemaVersion: '1.0'
  appVersion: string
  createdAt: string
  checksumAlgorithm: 'fnv1a32'
  checksum: string
  entries: Record<AiSpaceStateKey, string | null>
}
```

The 19 `AiSpaceStateKey` values are an explicit allowlist of AI Space-owned storage keys. The exporter never enumerates arbitrary browser localStorage and the restore path never modifies unrelated keys.

## Integrity boundary

The checksum is FNV-1a 32-bit over deterministic bundle metadata and ordered entries. It catches ordinary accidental corruption and editing mistakes. It is not collision-resistant, is not authentication, and is not a cryptographic signature.

Do not use the checksum to decide whether a bundle came from a trusted party.

## Restore model

v0.1.2 supports one restore mode: `replace-ai-space-state`.

The incoming bundle is validated and staged into a fresh `MemoryStorageAdapter`. Existing stores are recreated on top of that staged adapter, then the v0.1.1 hardening auditor evaluates cross-store invariants. An audit error prevents any mutation of the real target adapter.

On commit, each allowlisted key is either set to the incoming raw value or removed when the incoming entry is `null`. Unrelated storage keys are untouched. If the target adapter throws during commit, the previous allowlisted values are restored.

## Why merge import is deferred

Merging two independent runtime histories requires conflict semantics for Principal identity, Projection lineage, ContextSession activity, Space ownership/membership, Event ordering, BrowserSession lineage, Journey IDs, and capability state. Silent merging would make the system less trustworthy. v0.1.2 therefore chooses explicit replacement rather than inventing ambiguous conflict rules.

## Migration boundary

Schema versions other than `1.0` fail closed. This is intentional: the State Bundle becomes the stable point where future versions can add explicit migrations. v0.1.2 does not pretend unsupported versions are compatible.

## Acceptance

A completed coherent MVP Journey is exported, restored into completely fresh storage, and then every relevant store is recreated over that restored adapter. The Journey must remain coherent, complete, and 9/9 pass; the hardening auditor must report zero errors.
