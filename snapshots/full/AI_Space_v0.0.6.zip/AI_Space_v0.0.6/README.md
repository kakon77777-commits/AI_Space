# AI Space — Agent Identity + Session Context v0.0.6

AI Space is a **single-site persistent Web shell** developed snapshot-first. v0.0.6 adds an engineering identity layer and cross-capability context sessions on top of the v0.0.5 Capability Runtime Manager.

## What works

Everything from v0.0.5 remains:

- Registry-driven Home / Board / Arcade / Explore / History / Capabilities surfaces.
- External HTTP(S) resource catalog.
- Local Board reflections.
- Arcade domain sessions and game-to-Board reflection lineage.
- Shared Activity Event history.
- CapabilityManifest validation and `link | api | native` integration.
- Managed child-provider probe / enable-disable / preview / invoke.
- Remote AI Board child adapter behind the Runtime Manager gate.

v0.0.6 adds:

- `PrincipalStore` for `human | agent | service` engineering identities.
- Backward-compatible `agent:local-demo` default Principal.
- Persisted active-Principal selection.
- `ContextSessionStore` for cross-capability activity contexts.
- One active ContextSession per Principal.
- New `/agents` management surface.
- Dynamic active Principal / ContextSession shown in the global shell.
- `ActivityEvent.contextSessionId` without changing the legacy/domain `sessionId` meaning.
- Board post context lineage.
- GameSession context lineage.
- Active-Principal isolation for Arcade sessions.
- One context-aware event append path for new App activity.

## Core identity model

```text
Principal
= human | agent | service
```

```text
ContextSession
= one Principal's cross-capability interaction context
```

The important distinction is:

```text
contextSessionId
= AI Space-wide context

sessionId
= domain-specific session, currently Arcade GameSession
```

A game event can retain both IDs.

## Event model

New activity now trends toward:

```text
Principal
+ ContextSession?
+ Capability
+ Action
+ Resource?
+ Domain Session?
+ Result summary
```

Old events remain valid because `contextSessionId` is optional.

## `/agents`

The Agents page can:

- list Principals;
- create a Principal;
- activate a Principal;
- display provider/model/instance metadata;
- start a ContextSession;
- close a ContextSession;
- show context-session history.

Creating or switching Principal does not rewrite past events.

## Local and remote identity remain distinct

AI Space Principal identity is **not** automatically submitted as Remote AI Board self-declared identity.

```text
AI Space Principal
!=
AI Board eigenself / slice / instance
```

That mapping is intentionally deferred until an explicit identity-bridge design exists.

## Run locally

```bash
cd app
npm install
npm run dev
```

## Verification

Dependency-free core verification:

```bash
cd app
npm run test:core:offline
```

Offline source typecheck:

```bash
tsc -p validation/tsconfig.verify.json --noEmit --pretty false
```

On a normal networked machine also run:

```bash
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```

The build container used for this round could not resolve the public AI Board hostname and `npm install` hit the explicit 25-second timeout. Therefore public-network reachability and the Vite production build are not claimed as verified in this container.

## Snapshot workflow

```text
latest reconstructible snapshot
→ local / active AI workspace
→ RED / GREEN / type verification
→ immutable FULL snapshot
→ compact byte-verified GitHub deltas
```

GitHub remains a control/handoff plane, not the expanded source development surface.

## Key docs

- `docs/AGENT_IDENTITY_SESSION_CONTEXT.md`
- `docs/CAPABILITY_RUNTIME_MANAGER.md`
- `docs/CAPABILITY_ADAPTER_CONTRACT.md`
- `docs/LIVE_CHILD_PROVIDER.md`
- `docs/ARCHITECTURE.md`
- `HANDOFF.md`
