# AI Space v0.0.6 Verification

## Frozen execution evidence

Dependency-free core test command:

```bash
cd app
npm run test:core:offline
```

Result: **PASS — 58/58 tests**.

Evidence: `12_V006_FINAL_CORE_TESTS.txt`.

Offline TypeScript source verification:

```bash
cd app
tsc -p validation/tsconfig.verify.json --noEmit --pretty false
```

Result: **PASS — exit 0, zero diagnostic bytes**.

Evidence: `13_V006_FINAL_OFFLINE_TYPECHECK.txt`.

## TDD evidence

v0.0.6 preserves RED/GREEN evidence for:

- PrincipalStore creation/selection;
- ContextSessionStore lifecycle;
- Context/domain-session lineage;
- shipped `/agents` route;
- final integrated UI/core state.

## Network-limited checks

Public AI Board probe:

```bash
curl -fsS -D - --max-time 12 https://aiboard.evemisslab.com/api/schema
```

Result: DNS resolution failed before HTTP (`curl` exit 6).

Evidence: `10_V006_LIVE_AI_BOARD_PROBE.txt`.

Dependency installation:

```bash
timeout 25s npm install --no-audit --no-fund
```

Result: explicit timeout (`exit 124`).

Evidence: `11_V006_NPM_INSTALL.txt`.

Therefore this snapshot does **not** claim a network-installed Vitest run, live public-provider reachability, or Vite production build in this container.

## Identity/session invariants verified

- `agent:local-demo` remains the backward-compatible default Principal.
- Principal active selection persists through StorageAdapter.
- one active ContextSession per Principal;
- different Principals may retain independent active ContextSessions;
- `contextSessionId` is distinct from domain `sessionId`;
- GameSession and BoardPost preserve optional context lineage;
- shipped `/agents` route is present;
- old core behavior remains green.

## Snapshot integrity

After all source/docs/evidence files are frozen:

```bash
python validation/verify_snapshot.py
```

The verifier checks:

- `SNAPSHOT.json` version is `0.0.6`;
- every path in `CHECKSUMS.sha256` exists and matches SHA-256;
- every snapshot file other than `CHECKSUMS.sha256` is included in the manifest.

## Required deployment verification

On a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
