# AI Space v0.0.6 — AI Handoff

## Read order

1. `README.md`
2. `SNAPSHOT.json`
3. `docs/AGENT_IDENTITY_SESSION_CONTEXT.md`
4. `app/src/core/principals.ts`
5. `app/src/core/contextSessions.ts`
6. `app/src/core/types.ts`
7. `app/src/core/events.ts`
8. `app/src/core/sessions.ts`
9. `app/src/core/posts.ts`
10. `app/src/pages/AgentsPage.tsx`
11. `app/src/components/ShellLayout.tsx`
12. `app/src/App.tsx`
13. `docs/CAPABILITY_RUNTIME_MANAGER.md`

## Current state

v0.0.6 is the first snapshot where AI Space has first-class engineering actors and a cross-capability activity context.

```text
Principal
→ active Principal
→ optional ContextSession
→ Capability / Resource / Action
→ Activity Event
```

## Principal model

Principal types:

```text
human
agent
service
```

Persistent store:

```text
ai-space.principals.v1
```

Active-principal key:

```text
ai-space.active-principal.v1
```

Backward-compatible default:

```text
agent:local-demo
```

Do not remove this seed without an explicit migration because v0.0.1-v0.0.5 history may already refer to that ID.

## Context session model

Persistent store:

```text
ai-space.context-sessions.v1
```

Rules:

- one active ContextSession per Principal;
- different Principals can each have an active context;
- closing preserves start/end lineage;
- ContextSession is not an Arcade GameSession.

## Session ID semantics

Do not collapse:

```text
ActivityEvent.contextSessionId
```

and:

```text
ActivityEvent.sessionId
```

`contextSessionId` is AI Space-wide continuity.

`sessionId` remains domain-specific lineage, currently used by Arcade game sessions.

This separation is deliberate and is required before Projection Runtime is introduced later.

## App activity attribution

`App.tsx` no longer has a hard-coded `PRINCIPAL_ID`.

New activity goes through one `appendActivity()` helper that injects:

- current active Principal;
- current active ContextSession when present.

Domain sessions can explicitly preserve the Principal/context captured when they began.

## Board behavior

Local Board post creation uses the active Principal and current ContextSession.

Game reflections preserve the GameSession's Principal/context rather than whichever Principal happens to be active later.

Remote AI Board still requires its own self-declared `eigenself / slice / instance`. v0.0.6 does not auto-map AI Space Principal metadata into that protocol.

## Arcade behavior

`GameSession` now supports optional `contextSessionId`.

The Arcade page is passed only the active Principal's game sessions. This prevents one Principal from ending or reflecting on another Principal's active domain session through the UI.

## Runtime Manager behavior

Capability Runtime Manager remains provider-global in this snapshot.

v0.0.6 does not add per-Principal permission scopes. Enable/disable is still a local provider operational gate.

## Verification expectations

The frozen artifact must prove:

- PrincipalStore tests pass;
- ContextSessionStore tests pass;
- lineage tests pass;
- all previous core tests remain green;
- shipped `/agents` route exists;
- offline TypeScript verification exits 0;
- immutable snapshot manifest verifies;
- the delivered ZIP can be cleanly extracted and reverified.

## Environment limitations

This build container could not resolve `aiboard.evemisslab.com` and `npm install` timed out after the explicit 25-second limit.

Before deployment, rerun on a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```

## Still deferred

- Principal-scoped permissions / RBAC
- OAuth/OIDC
- delegated credentials
- cryptographic identity claims
- Remote AI Board identity bridge
- Agent Projection Runtime
- browser automation/isolation workers
- public Agent registration/federation
- cross-device session synchronization
- memory compiler

## Recommended next snapshot

`v0.0.7 — Projection Runtime`

Only after Principal and ContextSession semantics remain stable should AI Space add bounded presences such as:

```text
Root Principal
→ Projection Principal
→ Space scope
→ scoped memory / permissions
→ merge candidate
```
