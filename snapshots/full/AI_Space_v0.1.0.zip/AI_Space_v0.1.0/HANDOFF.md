# AI Space v0.1.0 Handoff

## Current state

v0.1.0 closes the first coherent AI Space loop:

```text
Principal
→ ContextSession
→ Projection
→ Space presence
→ Capability / Resource
→ tracked external interaction boundary
→ Experience
→ Board Reflection
→ Return Root
→ Persist / Reload / Re-evaluate
```

## Most important new runtime

- `app/src/core/mvpJourneys.ts`
  - `MvpJourneyStore`
  - `evaluateMvpJourney()`
  - `MvpJourneyRuntime`
- `app/src/pages/MvpJourneyPage.tsx`
- native route `/mvp`

## Critical invariants

1. `MvpJourney` stores references, not copies of domain objects.
2. Journey Root cannot be a Projection.
3. `begin()` requires an existing active Space where Root is a member.
4. Root cannot already have another active ContextSession.
5. MVP Projection receives only `arcade:START_BROWSER_SESSION` by default.
6. Browser boundary remains `noopener,noreferrer`; it is not a sandbox claim.
7. Experience requires explicit summary text.
8. Reflection must be promoted through the existing candidate/Post lineage.
9. `finish()` refuses to complete if any pre-return coherence stage is not pass.
10. Completed Journey requires Root active, Context closed, and no active Projection Space presence.
11. Completion must remain coherent after stores are recreated from persistent storage.
12. No automatic Projection Merge/Reintegration happens here.

## Nine acceptance gates

- Principal
- Context
- Projection
- Space
- Capability / Resource
- Interaction
- Experience
- Reflection
- Return

A completed Journey with anything except nine `pass` stages is not a coherent MVP completion.

## Snapshot workflow

Do not expand source into GitHub. Future work should:

1. reconstruct/download the latest snapshot;
2. verify checksums;
3. develop and test locally/in the active AI workspace;
4. emit the next immutable FULL snapshot;
5. publish only compact byte-verified GitHub handoff deltas.

## Deployment gate

On a normal networked machine:

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
curl -fsS https://aiboard.evemisslab.com/api/schema
```
