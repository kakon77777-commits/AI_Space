# AI Space v0.1.0 — First Coherent MVP

AI Space is developed snapshot-first: implementation and verification happen in the active workspace, a complete immutable FULL ZIP is delivered each round, and GitHub receives compact byte-verified reconstruction deltas rather than an expanded source tree.

v0.1.0 is the first release focused on **end-to-end coherence** instead of adding another horizontal subsystem.

```text
Root Principal
→ ContextSession
→ Projection
→ Space
→ Capability / Resource
→ BrowserSession boundary
→ Experience
→ Reflection
→ Return Root
→ closed ContextSession
→ reload-safe coherence PASS
```

## New in v0.1.0

- persistent `MvpJourneyStore` containing stable cross-store references only.
- pure `evaluateMvpJourney()` nine-stage coherence evaluator.
- `MvpJourneyRuntime` integration orchestrator.
- `/mvp` guided native surface.
- Journey lifecycle: `active | completed | abandoned`.
- begin creates a dedicated ContextSession + bounded Projection and enters its existing Space.
- tracked interaction reuses the existing BrowserSession boundary (`Tracked != Observed`).
- explicit Experience completion creates Experience + ReflectionCandidate through existing stores.
- reflection promotion creates a local Board post with original BrowserSession/Resource/Context lineage.
- finish returns the Root, clears Projection Space presence, closes the ContextSession, and refuses completion unless the full chain re-evaluates coherently.
- core acceptance test reloads all stores and verifies the completed Journey again.

## Authority rule

The Journey does not become another database of copied domain state:

```text
MvpJourney = stable cross-store references + terminal status
```

Principal, Context, Projection, Space, Resource, BrowserSession, Experience, Reflection and Event truth remain in their existing authoritative stores.

See `docs/FIRST_COHERENT_MVP.md`.

## Run on a normal networked machine

```bash
cd app
npm install
npm test
npm run typecheck
npm run build
```

This build environment also attempts live AI Board reachability and npm dependency installation. If either is unavailable, the snapshot records that limitation explicitly instead of inferring success.
