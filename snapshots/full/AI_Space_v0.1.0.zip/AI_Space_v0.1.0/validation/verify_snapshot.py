#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "SNAPSHOT.json"
CHECKSUMS = ROOT / "CHECKSUMS.sha256"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    snapshot = json.loads(SNAPSHOT.read_text(encoding="utf-8"))
    if snapshot["version"] != "0.1.0":
        raise SystemExit("unexpected snapshot version")

    expected = {}
    for line in CHECKSUMS.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        expected[rel] = digest

    failures = []
    for rel, digest in expected.items():
        path = ROOT / rel
        if not path.exists():
            failures.append(f"missing: {rel}")
            continue
        actual = sha256(path)
        if actual != digest:
            failures.append(f"checksum mismatch: {rel}")

    actual_files = {
        str(p.relative_to(ROOT)).replace("\\", "/")
        for p in ROOT.rglob("*")
        if p.is_file() and p.name != "CHECKSUMS.sha256"
    }
    expected_files = set(expected)
    missing_from_manifest = sorted(actual_files - expected_files)
    if missing_from_manifest:
        failures.extend(f"not checksummed: {rel}" for rel in missing_from_manifest)

    if failures:
        for failure in failures:
            print(f"FAIL {failure}")
        return 1

    print(f"PASS version={snapshot['version']} files={len(expected)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
