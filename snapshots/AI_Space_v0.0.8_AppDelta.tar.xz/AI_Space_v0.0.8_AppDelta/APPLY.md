# Apply v0.0.8 AppDelta
Base: AI Space v0.0.7 plus CoreDelta.
Extract with `tar -xJf AI_Space_v0.0.8_AppDelta.tar.xz --strip-components=1 -C <project-root>`.
